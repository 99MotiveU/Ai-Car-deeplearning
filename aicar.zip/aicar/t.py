#############################################################################################
#                                                               
# Auto Drive Car                                                    <gi.py>
#
#
# FEB 2 2022
#
# SAMPLE Electronics co.                                        
# http://www.ArduinoPLUS.cc                                     
#                                                               
#############################################################################################
#
WIN_GAP_X = 300             # 제어 윈도우 X 최소 폭
WIN_GAP_Y = 100             # 제어 윈도우 Y 최소 폭
WIN_XL_ORG = 0              # 제어 윈도우 왼쪽 X 값
WIN_XR_ORG = 639            # 제어 윈도우 오른쪽 X 값
WIN_YU_ORG = 246            # 제어 윈도우 위쪽 Y 값
WIN_YD_ORG = 459            # 제어 윈도우 아래쪽 Y값
WIN_XL = WIN_XL_ORG         # [0] 제어 윈도우 왼쪽 X 값
WIN_XR = WIN_XR_ORG         # [1] 제어 윈도우 오른쪽 X 값
WIN_YU = WIN_YU_ORG         # [2] 제어 윈도우 위쪽 Y 값
WIN_YD = WIN_YD_ORG         # [3] 제어 윈도우 아래쪽 Y값
#--------------------------------------------------------------------------------------------
AUTO_LIGHT = False          # [4] 전조등 지동 점등 모드 True: 자동 False: 수동
MANUAL_LIGHT = False        # [5] 전조등 수동 점등 모드 True: 점등 False: 소등
fileId = 0                  # [6] 기본(default) 이미지파일 시작 번호
VARIABLE_MODE = False       # 마우스에 의한 주행 속도-촬영 시간 
fileNF = 'P'                # 기본(default) 이미지 파일 이름 문자 (여러 개 문자 가능 예: Project_A)
DIRECTORY_FLAG = False      # 이미지 저장용 디렉토리 상태(True:디렉토리 있음)
imageDir = 'Exercise Mode'  # 이미지 파일 저장 디렉토리 디렉토리를 지정하지 않으면 이미지가 저장되지 않는 연습모드로 실행됩니다.
defForSpeed = 60            # 기본(default) 이미지 저장 차량 전진 속도 (PWM 값)
defMotorAngle = 0.15        # 기본(default) 각도 이득(모터 PWM 좌,우 배분)
defRecTime = 500000000      # 기본(default) 이미지 저장 시간 간격 0.5초
recUnitTime = 100000000     # 가변 이미지 수집 모드에서 이미지 저장 단위 간격 0.1초
recordOn = False            # 이미지 연속 녹화 상태 / mouseCtrlState 가 True이고 마우스 왼쪽 버튼에 의하여 True가 된다.
oneShot = False             # 단일(One Shoot) 이미지 촬영
mouseCtrlState = False      # 마우스에 의한 차량 주행및 조향 제어 상태 (True:제어 가능)
REC_LOW_FORWARD_SPEED = 40  # 가변 차량속도/촬영시간 모드에서 녹화시 최저 모터 속도 (PWM 값)
recTimeList = [recUnitTime*1,recUnitTime*2,recUnitTime*3,recUnitTime*4,
               recUnitTime*5,recUnitTime*6,recUnitTime*7,recUnitTime*8,
               recUnitTime*9,recUnitTime*10,recUnitTime*11] # 가변 차량속도/촬영시간 모드에서 녹화 구간별 녹화 시간 간격
# Library Import ============================================================================
import os                   # 파일, 디렉토리 존재 유무 확인, 디렉토리 생성 라이브러리
import sys                  # 커맨드 라인 인수(이미지 저장 디렉토리, 레코딩 시작번호)처리 라이브러리 
import numpy as np          # 이미지 배열 생성(OpenCV 에서 사용) 라이브러리
import cv2 as cv            # 영상처리(OpenCV) 라이브러리 
import pickle               # python 객체 저장/읽기 라이브러리
import RPi.GPIO as GPIO     # Raspberry Pi 헤터핀 제어 라이브러리
import NEOPIXEL as nx       # NeoPixel 제어 라이브러리
# Constant ----------------------------------------------------------------------------------
RED     =   0,  0,255       # Red
GREEN   =   0,255,  0       # Green
BLUE    = 255,  0,  0       # Blue
MAGENTA = 255,  0,255       # Magenta(Pink)
CYAN    = 255,255,  0       # Cyan(Sky Blue)
YELLOW  =   0,255,255       # Yellow
WHITE   = 255,255,255       # White
GRAY    =  32, 32, 32       # Gray
BLACK   =   0,  0,  0       # Black
#--------------------------------------------------------------------------------------------
VIDEO_X = 640               # Video X Size (960x240 / 960x800 / 1600x240)
VIDEO_Y = 480               # Video Y Size
cursorColor = YELLOW        # 조향 커서 색상 (YELLOW:정지, GREEN:주행, RED:녹화)
mouseX = 400                # 마우스 X 초기 위치
mouseY = 420                # 마우스 Y 초기 위치
mL = 0                      # 왼쪽 모터의 PWM 값이며 절대 값으로 0 부터 100까지(99 아님)
mR = 0                      # 오른쪽 모터의 PWM 값이며 절대 값으로 0 부터 100까지(99 아님)
# GPIO --------------------------------------------------------------------------------------
LIGHT_SENSOR = 25           # GPIO.25  CdS 광 센서 입력
MOTOR_L_PWM = 12            # GPIO.12  왼쪽 모터 펄스 푹 변조(Pulse Width Modulation)
MOTOR_L_DIR = 5             # GPIO.5   원쪽 모터 방향 (Motor Rotation Direction)
MOTOR_R_PWM = 13            # GPIO.13  오른쪽 모터 펄스 폭 변조(Pulse Width Modulation)
MOTOR_R_DIR = 6             # GPIO.6   오른쪽 모터 방향 (Motor Rotation Direction)
# Video Window ------------------------------------------------------------------------------
cam = cv.VideoCapture(0,cv.CAP_V4L)   # 카메라 객체 생성
cam.set(3,VIDEO_X)                    # 카메라 입력 화면 X 크기
cam.set(4,VIDEO_Y)                    # 카메라 입력 화면 Y 크기
# Set up ------------------------------------------------------------------------------------
GPIO.setmode(GPIO.BCM)                # GPIO 핀 번호를 BCM 방식으로 설정 
GPIO.setwarnings(False)               # 부팅시 경고 메시지 출력(터미널 창에서)안보기로 설정
GPIO.setup(MOTOR_L_PWM,GPIO.OUT)      # 왼쪽 모터 PWM 신호 출력 핀 
GPIO.setup(MOTOR_L_DIR,GPIO.OUT)      # 왼쪽 모터 방향 신호 출력 핀
GPIO.setup(MOTOR_R_PWM,GPIO.OUT)      # 오른쪽 모터 PWM 신호 출력 핀 
GPIO.setup(MOTOR_R_DIR,GPIO.OUT)      # 오른쪽 모터 방향 신호 출력 핀
MOTOR_L = GPIO.PWM(MOTOR_L_PWM,500)   # 왼쪽 모터 PWM 주파수 500Hz
MOTOR_R = GPIO.PWM(MOTOR_R_PWM,500)   # 오른쪽 모터 PWM 주파수 500Hz
MOTOR_L.start(0)                      # 왼쪽 모터 펄스폭 변조(PWM)값 0 으로 시작
MOTOR_R.start(0)                      # 오른쪽 모터 펄스폭 변조(PWM)값 0 으로 시작
GPIO.setup(LIGHT_SENSOR, GPIO.IN, pull_up_down=GPIO.PUD_UP) # CdS 빛감지 센서 핀 방향(입력), 형태(풀업)설정
#--------------------------------------------------------------------------------------------
viewWin = np.zeros((480,800,3),np.uint8)  # 표시되는 윈도우 가로, 세로, 컬러층, 8비트
msgBoxL = cv.imread('./_IMAGE/gimL.png',cv.IMREAD_COLOR)
msgBoxR = cv.imread('./_IMAGE/gimR.png',cv.IMREAD_COLOR)
#--------------------------------------------------------------------------------------------
cv.namedWindow('Out',cv.WND_PROP_FULLSCREEN)
cv.setWindowProperty('Out', cv.WND_PROP_FULLSCREEN, cv.WINDOW_FULLSCREEN)
# Motor Run Function ------------------------------------------------------------------------
def motorRun(leftMotor, rightMotor):
    #return
    if leftMotor>100: leftMotor = 100        # 왼쪽 모터 전진 최대 PWM 값 (100: 최고속도)
    if leftMotor<-100: leftMotor = -100      # 왼쪽 모터 후진 최대 PWM 값 (100: 최고속도)

    if (leftMotor>=0): GPIO.output(MOTOR_L_DIR,GPIO.HIGH)   # 왼쪽 모터 전진
    else: GPIO.output(MOTOR_L_DIR,GPIO.LOW)  # 왼쪽 모터 후진
    #----------------------------------------------------------------------------------------
    if rightMotor>100: rightMotor = 100      # 오른쪽 모터 전진 최대 PWM 값 (100: 최고속도)
    if rightMotor<-100: rightMotor = -100    # 오른쪽 모터 후진 최대 PWM 값 (100: 최고속도)

    if  rightMotor >= 0: GPIO.output(MOTOR_R_DIR,GPIO.HIGH)   # 오른쪽 모터 전진
    else: GPIO.output(MOTOR_R_DIR,GPIO.LOW)  # 오른쪽 모터 후진
    #----------------------------------------------------------------------------------------
    MOTOR_L.ChangeDutyCycle(abs(leftMotor))  # 왼쪽 모터 PWM 값 지정
    MOTOR_R.ChangeDutyCycle(abs(rightMotor)) # 오른쪽 모터 PWM 값 지정
# Mouse Callback Function -------------------------------------------------------------------
def controlMain(event,x,y,flags,param):

    global mouseX, mouseY
    global recordOn, cursorColor
    global mouseCtrlState, oneShot

    mouseX = x; mouseY = y             # 마우스가 움직임으로 인터럽트가 발생하여 
                                       # 마우스 좌표값 X, Y를 전역변수 mouseX, mouseY에 저장
    if event == cv.EVENT_LBUTTONDOWN:  # 마우스 왼쪽 버튼 이벤트 발생
        if mouseCtrlState == False:    # 마우스에 의한 차량 제어 
            mouseCtrlState = True      # 마우스 왼쪽 클릭에서 마우스 조정 주행상태 수동 조작에 의하여 False 가 된다.
            cursorColor = GREEN        # 조향 커서키, 모터PWM 막대 그래프 색상
        else:
            if DIRECTORY_FLAG:         # 이미지 저장용 디렉토리 상태(True:디렉토리 있음)
                recordOn = True        # 이미지 레코딩 가능
                cursorColor = RED      # 조향 커서키, 모터 PWM 막대 그래프 색상

    if event == cv.EVENT_RBUTTONDOWN:  # 마우스 오른쪽 버튼 이벤트 발생
        mouseCtrlState = False         # 마우스에 의한 차량 제어 금지
        recordOn = False               # 이미지 저장 금지
        cursorColor = YELLOW           # 차량 정지 상태에서 조향 커서키, 모터PWM 막대 그래프 색상
        MOTOR_L.ChangeDutyCycle(0)     # 왼쪽 모터 정지
        MOTOR_R.ChangeDutyCycle(0)     # 오른쪽 모터 정지

    if event == cv.EVENT_MBUTTONDOWN:  # 마우스 가운데 버튼 이벤트 발생
        oneShot = True                 # 원 샷 (One shot) 촬영 가능상태

# Main Loop =================================================================================
def main():

    global WIN_XL, WIN_XR, WIN_YU, WIN_YD, AUTO_LIGHT, MANUAL_LIGHT, fileId
    global VARIABLE_MODE, viewWin, oneShot, recordOn, mL, mR, cursorColor, mouseCtrlState

    angle = 0                          # 마우스 핸들로 만들어진 조향 각도 임시 저장 변수로 사용
    preKey = ord(' ')                  # 초기 키 값으로 space 를 지정합니다.
    MENU_VIEW = True                   # True:메뉴 뷰 모드 회색 바탕위에 기본적인 키에 관한 설명
                                       # False:클리어 뷰 모드 카메라 입력 영상을 전부 볼수 있으며 이미지 파일 이름만 표시
    recordTime = defRecTime            # 고정(기본) 이미지 저장 시간 간격
    forwardSpeed = 60                  # 차량 속도 (최고 속도 = 100)
    shotPeriode = 0                    # 촬영 시간 간격 
    timeMemory = cv.getTickCount()     # 시스템 부팅 시 부터 1 mS 간격으로 카운트 업됩니다.


    #----------------------------------------------------------------------------------------
    while(cam.isOpened()):             # 카메라 활성화 되어 있므면 무한 반복

        sample_x = np.linspace(WIN_XL+5, WIN_XR-5, 40)
        sample_y = np.linspace(WIN_YU+5, WIN_YD-5, 10)

        ret, frame = cam.read()        # 카메라로부터 한장의 정지화면 데이터를 가져 옵니다.
        viewWin[0:480,0:80] = msgBoxL 
        viewWin[0:480,720:800] = msgBoxR 
        #------------------------------------------------------------------------------------
        viewWin[0:480,80:720] = frame[0:480,0:640]  # 카메라 전체 이미지 
        #------------------------------------------------------------------------------------
        roadImg = viewWin[WIN_YU:WIN_YD,80+WIN_XL:80+WIN_XR]  # frame 화면이므로 +80
        #------------------------------------------------------------------------------------
        cv.rectangle(viewWin,(80+WIN_XL,WIN_YU),(80+WIN_XR,WIN_YD),CYAN,1) # 딥러닝 영역 박스처리
        #viewWin[WIN_YD-WIN_GAP_Y:WIN_YD-WIN_GAP_Y+1,80+WIN_XL:80+WIN_XR:4]=CYAN
        #------------------------------------------------------------------------------------
        #------------------------------------------------------------------------------------
        # 마우스 위치에 따라 차량의 기준 속도(직진)와 이미지 촬영 간격 시간을 구한다.
        # Y 방향 구간 내에서 마우스 Y 위치를 10 구간으로 구한다. 
        #------------------------------------------------------------------------------------

        for y in sample_y:
            y = int(y)
            for x in sample_x:
                x = int(x)+80
                p = viewWin[y,x]
                g = int(0.299 * p[2] + 0.587 * p[1] + 0.114 * p[0])
                
                c = RED
                if g>128: c = GREEN
                 
                cv.circle(viewWin,(x,y),3,c,1)
        


        #------------------------------------------------------------------------------------
        cv.imshow('Out', viewWin)           # 이미지를 LCD에 표시합니다.
        #------------------------------------------------------------------------------------
        keyBoard = cv.waitKey(1) & 0xFF     #print(hex(keyBoard)) # 키보드의 키 값 확인  
        if keyBoard == 0x1B or keyBoard == 0x09 or keyBoard == ord('x') or keyBoard == ord('X'):
            break                           # ESC / TAB / 'x' 프로그램 종료
        # 카메라 입력 영역 조정 -----------------------------------------------------------------
        if keyBoard == ord('!'):                             # X(가로)방향 줄임
            if not fileId and (WIN_XL <= WIN_GAP_X): WIN_XL += 2; WIN_XR -= 2
        if keyBoard == ord('@'):                             # X(가로)방향 늘림
            if not fileId and (WIN_XL >= 2): WIN_XL -= 2; WIN_XR += 2
        if keyBoard == ord('#'):                             # Y-Up 내리기
            if not fileId and ((WIN_YD-WIN_YU) > (WIN_GAP_Y+4)): WIN_YU += 2
        if keyBoard == ord('$'):                             # Y-Up 올리기
            if not fileId and (WIN_YU > 152): WIN_YU -= 2
        if keyBoard == ord('%'):                             # Y-Down 올리기
            if not fileId and ((WIN_YD-WIN_YU) > (WIN_GAP_Y+4)): WIN_YD -= 2
        if keyBoard == ord('^'):                             # Y-Down 내리기
            if not fileId and (WIN_YD <= 477): WIN_YD += 2
        if keyBoard == ord(')'):                             # X, Y 원위치
            if not fileId:
                WIN_XL = WIN_XL_ORG                          # 제어 윈도우 왼쪽 X 값
                WIN_XR = WIN_XR_ORG                          # 제어 윈도우 오른쪽 X 값
                WIN_YU = WIN_YU_ORG                          # 제어 윈도우 위쪽 Y 값
                WIN_YD = WIN_YD_ORG                          # 제어 윈도우 아래쪽 Y값
        if keyBoard == ord('c') or keyBoard == ord('C'):     # 클리어 View/메뉴 View
            MENU_VIEW = not MENU_VIEW
        if keyBoard == ord('l') or keyBoard == ord('L'):     # 전조등 ON/OFF 점등 
            MANUAL_LIGHT = not MANUAL_LIGHT
        # 수동 차량 조작 ----------------------------------------------------------------------
        if keyBoard == 82:                                   # 전진 Arrow Up
            recordOn = False; mouseCtrlState = False
            if preKey == ord(' '): preKey = keyBoard; mL = 80; mR = 80; cursorColor = GREEN
            else: preKey = ord(' '); mL = 0; mR = 0; cursorColor = YELLOW
            motorRun(mL, mR)
        #------------------------------------------------------------------------------------
        if keyBoard == 84:                                   # 후진 Arrow Down
            recordOn = False; mouseCtrlState = False
            if preKey == ord(' '): preKey = keyBoard; mL = -70; mR = -70; cursorColor = GREEN
            else: preKey = ord(' '); mL = 0; mR = 0; cursorColor = YELLOW
            motorRun(mL, mR)
        #------------------------------------------------------------------------------------
        if keyBoard == 81:                                   # 좌 회전 Arrow Left
            recordOn = False; mouseCtrlState = False
            if preKey == ord(' '): preKey = keyBoard; mL = -70; mR = 70; cursorColor = GREEN
            else: preKey = ord(' '); mL = 0; mR = 0; cursorColor = YELLOW
            motorRun(mL, mR)
        #------------------------------------------------------------------------------------
        if keyBoard == 83:                                   # 우 회전 Arrow Right
            recordOn = False; mouseCtrlState = False
            if preKey == ord(' '): preKey = keyBoard; mL = 70; mR = -70; cursorColor = GREEN
            else: preKey = ord(' '); mL = 0; mR = 0; cursorColor = YELLOW
            motorRun(mL, mR)
        #------------------------------------------------------------------------------------
        if keyBoard == ord(' '):                             # Space 정지
            recordOn = False; mouseCtrlState = False; cursorColor = YELLOW
            preKey = ord(' '); mL = 0; mR = 0
            motorRun(mL, mR)
    #----------------------------------------------------------------------------------------
    nx.lamp(0,0,0)                          # 전조등 Off
    MOTOR_L.stop()                          # 왼쪽 모터 PWM(펄스 폭 변조) 정지
    MOTOR_R.stop()                          # 오른쪽 모터 PWM(펄스 폭 변조) 정지
    GPIO.cleanup()                          # GPIO 초기화
    cam.release()                           # 카메라 자원을 반납
    cv.destroyAllWindows()                  # 열려 있는 모든 윈도우를 닫기

#============================================================================================
if __name__ == '__main__':
    # OpenCV 라이브러리 버젼 표시
    print('\n')
    print('OpenCV Version: ', cv.__version__)
    print('\n')


    # Mouse Event ---------------------------------------------------------------------------
    cv.namedWindow('Out')                              # 윈도우 창을 생성합니다.
    cv.setMouseCallback('Out', controlMain, viewWin)   # 마우스 제어 설정
    #----------------------------------------------------------------------------------------
    main()                                             # 이미지 수집 프로그램 실행

#############################################################################################


