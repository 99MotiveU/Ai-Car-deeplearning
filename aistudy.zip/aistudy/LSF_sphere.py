#### Least Square Fit Sphere                         <LSF_sphere.py>
# 최소 자승법에 의한 구의 중심좌표와 반지름 구하기
#

import numpy as np
import random
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

fig = plt.figure(figsize=(10, 5))
ax = fig.add_subplot(111, projection='3d') # Axe3D Object

xd = []
yd = []
zd = []

# 반지름 100 인 구 면상의  테스트용 좌표 생성
radius = 100 
xcr = random.randrange(-50,+50)
ycr = random.randrange(-50,+50)
zcr = random.randrange(-50,+50)

for h in range(30,220,20):                    # pi Z -> XY
    p = h*np.pi/180.0
    for v in range(70,290,40):                # theta XY
        v += random.randrange(1,12)
        r = radius + random.randrange(1,12)
        t = v*np.pi/180.0
        xq  = xcr + r*np.sin(p)*np.cos(t)
        yq  = ycr + r*np.sin(p)*np.sin(t)
        zq  = zcr + r*np.cos(p)

        xd.append(xq)
        yd.append(yq)
        zd.append(zq)
  
x = np.array(xd)    # Numpy 로 변환합니다.
y = np.array(yd)
z = np.array(zd)

#----------------------------------------------------------
N = len(x)
Sx  = np.sum(x)
Sxx = np.sum(x*x)

Sy  = np.sum(y)
Syy = np.sum(y*y)

Sz  = np.sum(z)
Szz = np.sum(z*z)

Sxy = np.sum(x*y)
Syz = np.sum(y*z)
Szx = np.sum(z*x)

r    = x*x + y*y + z*z
Srr  = np.sum(r)
Srrx = np.sum(r*x)
Srry = np.sum(r*y)
Srrz = np.sum(r*z)

A = np.array([[N,  Sx,  Sy,  Sz ],
              [Sx, Sxx, Sxy, Szx],
              [Sy, Sxy, Syy, Syz],
              [Sz, Szx, Syz, Szz]])
B = np.array([Srr,  Srrx, Srry, Srrz])

X = np.linalg.solve(A,B)    # 4 x 4 선형 방정식의 해를 구합니다.

print("  ",X)

a = X[1]/2.0        # 구의 원점 X 좌표 값
b = X[2]/2.0        # 구의 원점 Y 좌표 값
c = X[3]/2.0        # 구의 원점 Z 좌표 값

R = np.sqrt(a*a+b*b+c*c+X[0]) # 구의 반지름 값

print("Xo=",a,"Yo=", b,"Zo=", c,"\nR=", R)

x0 = np.array([0,a])
y0 = np.array([0,b])
z0 = np.array([0,c])

ax.set_aspect('equal')
ax.plot(x,y,z, alpha = 0.5, marker='o')
ax.plot(x0,y0,z0, alpha = 0.5, marker='o')

ax.scatter(x,y,z,c=z,s=20, cmap=plt.cm.Greens)
plt.title("Plot Sphere 3D")
plt.savefig("LSF_Sphere.png")
plt.show()

#---------------------------------------------------
