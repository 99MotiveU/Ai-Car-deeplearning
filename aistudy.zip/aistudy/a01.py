# 파이썬 기본 : 프로그램 구조 main 프로그램에서 라이브러리 호출      <a01.py>

import PYTHON_PROG                       # 라이브러리 파일을 가져온다
                                         # 관행적으로 라이브러리 파일 이름은 대문자
                                         # '.py'는 붙이지 않는다.
print('여기서 부터 a01.py 프로그램 실행 결과 입니다.')

a = PYTHON_PROG.radius                   # 라이브러리 내의 변수값 가져오기
print(a)

b = PYTHON_PROG.myName                   # 라이브러리 내의 스트링(문자열) 가져오기
print(b)

c = PYTHON_PROG.additionTwoNumber(4, 5)  # 라이브러리 내의 함수 실행하기
print(c)

print(PYTHON_PROG.__name__)              # 라이브러리 PYTHON_PROG의 이름(__name__)가져오기
#############################################################################################
