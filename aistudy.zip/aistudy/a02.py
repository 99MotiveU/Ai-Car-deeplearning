# Pytho의 자료형                                                  <a02.py> 
# 
# python 에서 리스트 자료형은 
# 정수, 소수점수, 불리안 논리, 복소수, 스트링을 지원합니다.
#
a = 123                         # 정수(integer)
b = 3.14                        # 소수점 수
c = True                        # Bool 논리 참 값
d = False                       # Bool 논리 거짖 값
e = 3+4j                        # 복소수
f = 'c'                         # 문자
g = '베토벤'                     # 스티링(문자열)

#-------------------------------------------------------------
print('변수의 값을 프린트 합니다.')
print(a, b, c, d, e, f, g)
print()
print('변수의 유형을 프린트 합니다.')
print(type(a), type(b), type(c), type(d), type(e), type(f), type(g))

