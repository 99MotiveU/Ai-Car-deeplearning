# List 4                   <a06.py>
#
a = [2, 1, 4, 5, 3]

print(a)

print('Min:',min(a))  

print('Max:',max(a))

print('Sum:',sum(a))


  