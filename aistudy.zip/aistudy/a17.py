# String, f String                          <a17.py>

u = '그는 말했다. "너 자신을 알라"'              # 더블 따옴표를 포함한 스트링
v = "King's horse"                           # 싱글 따옴표를 포함한 스트링
w = 'My Car\nYour\tCar'                      # 특수문자 포함한 스트링
print(u)
print(v)
print(w)
a = 123; b = 3.141592; c = 'Apple'
t = f'순서는{a:5d} 원주율은{b:0.2f} 컴퓨터는 "{c}"'
print(t)

