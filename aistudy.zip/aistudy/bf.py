#
# Object Detection using Haar Cascades          <bf.py>
#
#
#--------------------------------------------------------------------------
import cv2                            # OpenCV 라이브러리
import RPi.GPIO as GPIO               # GPIO
#--------------------------------------------------------------------------
gain = 1                              # Steering Gain
#object_pattern = cv2.CascadeClassifier('/home/pi/opencv/data/haarcascades/haarcascade_lowerbody.xml')
object_pattern = cv2.CascadeClassifier('/home/pi/opencv/data/haarcascades/haarcascade_fullbody.xml')
#--------------------------------------------------------------------------
cap = cv2.VideoCapture(0,cv2.CAP_V4L)
cap.set(3,640)
cap.set(4,480)
# GPIO --------------------------------------------------------------------
MUSIC = 24                            # GPIO.24    후진 사운드
MOTOR_L_PWM = 12                      # GPIO.12    왼쪽 모터 펄스 푹 변조
MOTOR_L_DIR = 5                       # GPIO.5     원쪽 모터 방향
MOTOR_R_PWM = 13                      # GPIO.13    오른쪽 모터 펄스 폭 변조
MOTOR_R_DIR = 6                       # GPIO.6     오른쪽 모터 방향
GPIO.setmode(GPIO.BCM)                # GPIO 핀 번호를 BCM 방식으로 설정 
GPIO.setwarnings(False)               # 경고 메시지 출력 안보기로 설정
GPIO.setup(MOTOR_L_PWM,GPIO.OUT)      #
GPIO.setup(MOTOR_L_DIR,GPIO.OUT)      #
GPIO.setup(MOTOR_R_PWM,GPIO.OUT)      #
GPIO.setup(MOTOR_R_DIR,GPIO.OUT)      #
MOTOR_L = GPIO.PWM(MOTOR_L_PWM,500)   # PWM 주파수 500Hz
MOTOR_R = GPIO.PWM(MOTOR_R_PWM,500)   # PWM 주파수 500Hz
MOTOR_L.start(0)                      # 왼쪽 모터 펄스폭 변조 값 0 으로 시작
MOTOR_R.start(0)                      # 오른쪽 모터 펄스폭 변조 값 0 으로 시작
GPIO.setup(MUSIC,GPIO.OUT)            # 후진 사운드 
# Motor Run Function ------------------------------------------------------
def motorRun(leftMotor, rightMotor):

    #return
    if leftMotor>100: leftMotor = 100        # 왼쪽 모터 전진 최대 PWM 값 (100: 최고속도)
    if leftMotor<-100: leftMotor = -100      # 왼쪽 모터 후진 최대 PWM 값 (100: 최고속도)

    if (leftMotor>=0):
        GPIO.output(MOTOR_L_DIR,GPIO.HIGH)   # 왼쪽 모터 전진
    else:
        GPIO.output(MOTOR_L_DIR,GPIO.LOW)    # 왼쪽 모터 후진
    #----------------------------------------------------------------------
    if rightMotor>100: rightMotor = 100      # 오른쪽 모터 전진 최대 PWM 값 (100: 최고속도)
    if rightMotor<-100: rightMotor = -100    # 오른쪽 모터 후진 최대 PWM 값 (100: 최고속도)

    if  rightMotor >= 0:
        GPIO.output(MOTOR_R_DIR,GPIO.HIGH)   # 오른쪽 모터 전진
    else:
        GPIO.output(MOTOR_R_DIR,GPIO.LOW)    # 오른쪽 모터 후진
    #----------------------------------------------------------------------
    MOTOR_L.ChangeDutyCycle(abs(leftMotor))
    MOTOR_R.ChangeDutyCycle(abs(rightMotor))

#--------------------------------------------------------------------------
detect = False
position = 0
runSpeed = 0              
delayTime = 0
mL = 0
mR = 0
#--------------------------------------------------------------------------
while True:
    ret, frame = cap.read()          # 카메라(or MP4)에서 1 개의 이미지 프레임
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) # 컬러를 흑백으로 변환
    objectList = object_pattern.detectMultiScale(gray, # 흑백 이미지 소스
                 scaleFactor = 1.5, # 이미지 피라미드 스케일 factor
                 minNeighbors = 5,  # 인접 객체 최소 거리 픽셀
                 minSize=(20,20)    # 탐지 객체 최소 크기
               )

    for (x,y,w,h) in objectList:       # 인식된 얼굴 위치에 사각형을 그림
        detect = True
        delayTime = 5
        cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),4)
        position = int((x+w)/2-180)

        runSpeed = 0
        if 63  <= h <= 100: runSpeed = 100 
        if 100 <  h <= 150: runSpeed = 70 
        if 150 <  h <= 200: runSpeed = 40 
        if 200 <  h <= 250: runSpeed = 30 
        if 250 <  h <= 319: runSpeed = -70    # Back
        
        print('P:', position, 'H:', h, 'M:', mL, mR, 'S:', runSpeed)

    if detect:
        GPIO.output(MUSIC,GPIO.HIGH)          # Sound Play
        mL = int(+position*gain/2)+runSpeed
        mR = int(-position*gain/2)+runSpeed
    else:
        if delayTime == 0:
            GPIO.output(MUSIC,GPIO.LOW)       # Sound Stop
            mL = 0
            mR = 0

    detect = False

    if delayTime > 0: delayTime -= 1

    motorRun(mL, mR)

    cv2.putText(frame, f'{delayTime}', (260,20),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,(255,255,255))
    #cv2.line(frame,(320,0),(320,399),(255,255,255),1)
    cv2.imshow('Body Follower - [ESC] [Q] [Space]를 누르면 종료합니다.',frame)

    key = cv2.waitKey(1)
    if key == 27 or key == ord('q')or key == ord('Q') or key == ord(' '):
        break


cap.release()                        # 객체(카메라) 자원 반납
cv2.destroyAllWindows()              # 열려 있는 모든 창 닫기
GPIO.cleanup()                       # GPIO 모듈의 점유 리소스 해제

###########################################################################



