import cv2

cap = cv2.VideoCapture(0,cv2.CAP_V4L)
cap.set(cv2.CAP_PROP_FRAME_WIDTH,640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT,480)

while cap.isOpened():

    ret, image = cap.read()

    cv2.line(image,(100,50),(200,50),(255,255,255),5)
    cv2.putText(image,'INJE University',(60,200), cv2.FONT_HERSHEY_COMPLEX_SMALL, 2,(155,155,255),1)

    cv2.imshow('Canvas', image)

    key = cv2.waitKey(1)
    if key == ord('x'):
        break

cv2.destroyAllWindows()