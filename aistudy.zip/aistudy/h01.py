# Raspberry Pi 의 GPIO 핀 제어                    <h01.py>
#
# test
#
import RPi.GPIO as GPIO           # Raspberry Pi 입출력 핀 라이브러리
from time import sleep            # 
#--------------------------------------------------------------------------
# GPIO 일반 설정
GPIO.setwarnings(False)           # GPIO 관련 경고 메시지 출력 금지
GPIO.setmode(GPIO.BCM)            # BCM 핀 번호
#--------------------------------------------------------------------------
#testPin = 23          # 23 핀 - 경적 
#testPin = 24          # 24 핀 - 후진 사운드 
#testPin = 20          # 20 핀 - 우회전 노란색 깜빡이 램프
#testPin = 26          # 26 핀 - 좌회전 노란색 깜빡이 램프
testPin = 21          # 21 핀 - 빨간색 브레이크 램프

GPIO.setup(testPin, GPIO.OUT)          # 21 핀 출력으로 설정 
GPIO.output(testPin, GPIO.LOW)         # 21 핀 0V (Low Level) 출력 
#--------------------------------------------------------------------------
i = 0
while(i < 5):

    GPIO.output(testPin, GPIO.HIGH)     # 
    sleep(0.5)
    GPIO.output(testPin, GPIO.LOW)      #
    sleep(0.5)
    i = i + 1
GPIO.cleanup()                        # GPIO 모듈의 점유 리소스 해제    
#############################################################################################

