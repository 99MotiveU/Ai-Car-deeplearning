# Raspberry Pi 의 GPIO 핀 입력 설정          <h02.py>
#
# CdS 빛 감지 센서의 입력에 따라 GPIO 를 제어합니다.
#
# 커맨드 창에서 python h02.py 입력 합니다.
#
import sys
import select
import RPi.GPIO as GPIO           # Raspberry Pi 입출력 핀 라이브러리
import keyboard
#--------------------------------------------------------------------------
# GPIO 일반 설정
GPIO.setwarnings(False)           # GPIO 관련 경고 메시지 출력 금지
GPIO.setmode(GPIO.BCM)            # BCM 핀 번호
#--------------------------------------------------------------------------
GPIO.setup(21, GPIO.OUT)          # 21 핀 출력으로 설정(브레이크 등) 
GPIO.setup(25, GPIO.IN, pull_up_down=GPIO.PUD_UP) # 25 핀 Pull-Up 입력으로 설정(CdS)
#--------------------------------------------------------------------------
print('빛감지 센서(CdS)에 손가락으로 올려놓아 빛을 차단하면 빨간색 브레이크 등이 ON 됩니다.')
print()
print('[ENTER] 키를 누르면 프로그램 실행 종료 합니다.')
#--------------------------------------------------------------------------
while(True):

    if GPIO.input(25):                # High 로 입력되면 밤(어두운 상태)
        GPIO.output(21, GPIO.HIGH)    # 어두우면 브레이크 등이 켜짐(On) 
    else:                             # Low 로 입력되면 낮(밝은 상태)
        GPIO.output(21, GPIO.LOW)     # 밝으면 브레이크 등이 꺼짐(Off)

    # 리눅스 및 유닉스 기반 운영체제에서 키보드 입력 감지
    if sys.stdin in select.select([sys.stdin], [], [], 0)[0]:
        break  # 키보드 입력이 있을 경우 while 루프를 종료하여 프로그램을 빠져나옴
GPIO.cleanup()                        # GPIO 모듈의 점유 리소스 해제
#############################################################################################
