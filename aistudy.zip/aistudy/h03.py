# NEOPIXEL                                                            <h03.py>
#
# NEOPIXEL을 사용하려면 관리자 모드로 프로그램 실행하여야 합니다. sudo 모드로 실행중인지 확인합니다.
#
from time import sleep

import board
import neopixel

pixel_pin = board.D18                    # NeoPixel 이 연결된 핀 번호
num_pixels = 8                           # NeoPixel 연결된 개수
ORDER = neopixel.GRB
pixels = neopixel.NeoPixel(pixel_pin, num_pixels, brightness=1, auto_write=False, pixel_order=ORDER)
#---------------------------------------------------------------------------------------------

pixels[0] = 255, 0, 0 
pixels[1] = 182, 73, 0 
pixels[2] = 109, 146, 0 
pixels[3] = 36, 219, 0  
pixels[4] = 0, 219, 36
pixels[5] = 0, 146, 109
pixels[6] = 0, 73, 182
pixels[7] = 0, 0, 255
pixels.show()
sleep(3)

pixels.fill((255,255,255))
pixels.show()
sleep(3)

pixels.fill((0,0,0))
pixels.show()

#=============================================================================================
