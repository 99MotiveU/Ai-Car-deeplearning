# Motor Drive (PWM)                   <h07.py> 
#
from time import sleep
import RPi.GPIO as GPIO
#--------------------------------------------------------------------------
MOTOR_L_PWM = 12                      # GPIO.12    왼쪽 모터 펄스폭 변조
MOTOR_L_DIR = 5                       # GPIO.5     원쪽 모터 방향
MOTOR_R_PWM = 13                      # GPIO.13    오른쪽 모터 펄스폭 변조
MOTOR_R_DIR = 6                       # GPIO.6     오른쪽 모터 방향

GPIO.setwarnings(False)               # GPIO 관련 경고 메시지 출력 금지
GPIO.setmode(GPIO.BCM)                # BCM 핀 번호
GPIO.setup(MOTOR_L_PWM,GPIO.OUT)      # 왼쪽 모터 펄스폭
GPIO.setup(MOTOR_L_DIR,GPIO.OUT)      # 왼쪽 모터 방향
GPIO.setup(MOTOR_R_PWM,GPIO.OUT)      # 오른쪽 모터 펄스폭
GPIO.setup(MOTOR_R_DIR,GPIO.OUT)      # 오른쪽 모터 방향

MOTOR_L = GPIO.PWM(MOTOR_L_PWM,500)   # 왼쪽 모터 PWM(펄스폭 변조) 주파수 500Hz
MOTOR_R = GPIO.PWM(MOTOR_R_PWM,500)   # 오른쪽 모터 PWM(펄스폭 변조) 주파수 500Hz
MOTOR_L.start(0)                      # 왼쪽 모터 PWM(펄스폭 변조) 값 0 으로 시작
MOTOR_R.start(0)                      # 오른쪽 모터 PWM(펄스폭 변조) 값 0 으로 시작
# 전진 --------------------------------------------------------------------
GPIO.output(MOTOR_L_DIR,GPIO.HIGH)     # 왼쪽 모터 전진
GPIO.output(MOTOR_R_DIR,GPIO.HIGH)     # 오른쪽 모터 전진
MOTOR_L.ChangeDutyCycle(90)            # 왼쪽 모터 PWM 값 설정
MOTOR_R.ChangeDutyCycle(90)            # 오른쪽 모터 PWM 값 설정
sleep(0.5)
# 후진 --------------------------------------------------------------------
GPIO.output(MOTOR_L_DIR,GPIO.LOW)      # 왼쪽 모터 후진
GPIO.output(MOTOR_R_DIR,GPIO.LOW)      # 오른쪽 모터 후진
MOTOR_L.ChangeDutyCycle(90)            # 왼쪽 모터 PWM 값 설정
MOTOR_R.ChangeDutyCycle(90)            # 오른쪽 모터 PWM 값 설정
sleep(0.5)
# 우회전 --------------------------------------------------------------------
GPIO.output(MOTOR_L_DIR,GPIO.HIGH)     # 왼쪽 모터 전진
GPIO.output(MOTOR_R_DIR,GPIO.LOW)      # 오른쪽 모터 후진
MOTOR_L.ChangeDutyCycle(90)            # 왼쪽 모터 PWM 값 설정
MOTOR_R.ChangeDutyCycle(90)            # 오른쪽 모터 PWM 값 설정
sleep(0.5)
# 후진 --------------------------------------------------------------------
GPIO.output(MOTOR_L_DIR,GPIO.LOW)      # 왼쪽 모터 후진
GPIO.output(MOTOR_R_DIR,GPIO.HIGH)     # 오른쪽 모터 전진
MOTOR_L.ChangeDutyCycle(90)            # 왼쪽 모터 PWM 값 설정
MOTOR_R.ChangeDutyCycle(90)            # 오른쪽 모터 PWM 값 설정
sleep(0.5)
#-------------------------------------------------------------------------
GPIO.cleanup()                         # GPIO 모듈의 점유 리소스 해제
#==========================================================================
   
