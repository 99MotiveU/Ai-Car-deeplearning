# Motor Drive (PWM)                                  <h06.py> 
#
# Library Import ============================================================================
import numpy as np          # 이미지 배열 생성(OpenCV 에서 사용) 라이브러리
import cv2                  # 영상처리(OpenCV) 라이브러리 
import RPi.GPIO as GPIO
from time import sleep
#--------------------------------------------------------------------------
MOTOR_L_PWM = 12                      # GPIO.12    왼쪽 모터 펄스폭 변조
MOTOR_L_DIR = 5                       # GPIO.5     원쪽 모터 방향
MOTOR_R_PWM = 13                      # GPIO.13    오른쪽 모터 펄스폭 변조
MOTOR_R_DIR = 6                       # GPIO.6     오른쪽 모터 방향

GPIO.setwarnings(False)               # GPIO 관련 경고 메시지 출력 금지
GPIO.setmode(GPIO.BCM)                # BCM 핀 번호
GPIO.setup(MOTOR_L_PWM,GPIO.OUT)      # 왼쪽 모터 펄스폭
GPIO.setup(MOTOR_L_DIR,GPIO.OUT)      # 왼쪽 모터 방향
GPIO.setup(MOTOR_R_PWM,GPIO.OUT)      # 오른쪽 모터 펄스폭
GPIO.setup(MOTOR_R_DIR,GPIO.OUT)      # 오른쪽 모터 방향

MOTOR_L = GPIO.PWM(MOTOR_L_PWM,500)   # 왼쪽 모터 PWM(펄스폭 변조) 주파수 500Hz
MOTOR_R = GPIO.PWM(MOTOR_R_PWM,500)   # 오른쪽 모터 PWM(펄스폭 변조) 주파수 500Hz
MOTOR_L.start(0)                      # 왼쪽 모터 PWM(펄스폭 변조) 값 0 으로 시작
MOTOR_R.start(0)                      # 오른쪽 모터 PWM(펄스폭 변조) 값 0 으로 시작
# Video Window ------------------------------------------------------------------------------
cam = cv2.VideoCapture(0,cv2.CAP_V4L)   # 카메라 객체 생성
cam.set(3,640)                    # 카메라 입력 화면 X 크기
cam.set(4,480)                    # 카메라 입력 화면 Y 크기
#--------------------------------------------------------------------------------------------
while True:
    ret, image = cam.read()
    cv2.imshow('[SPACE] key to Stop, [ESC] key to System',image)

    keyBoard = cv2.waitKey(1)
    if keyBoard == 27 or keyBoard == ord('x') or keyBoard == ord('X') : break

    if keyBoard == ord(' '):                  # 차량 정지
        MOTOR_L.ChangeDutyCycle(0)            # 왼쪽 모터 PWM 값 설정
        MOTOR_R.ChangeDutyCycle(0)            # 오른쪽 모터 PWM 값 설정

# 수동 차량 조작 ----------------------------------------------------------------------
    if keyBoard == 82:                         # 전진 Arrow Up
        GPIO.output(MOTOR_L_DIR,GPIO.HIGH)     # 왼쪽 모터 전진
        GPIO.output(MOTOR_R_DIR,GPIO.HIGH)     # 오른쪽 모터 전진
        MOTOR_L.ChangeDutyCycle(90)            # 왼쪽 모터 PWM 값 설정
        MOTOR_R.ChangeDutyCycle(90)            # 오른쪽 모터 PWM 값 설정
#------------------------------------------------------------------------------------
    if keyBoard == 84:                         # 후진 Arrow Down
        GPIO.output(MOTOR_L_DIR,GPIO.LOW)      # 왼쪽 모터 후진
        GPIO.output(MOTOR_R_DIR,GPIO.LOW)      # 오른쪽 모터 후진
        MOTOR_L.ChangeDutyCycle(90)            # 왼쪽 모터 PWM 값 설정
        MOTOR_R.ChangeDutyCycle(90)            # 오른쪽 모터 PWM 값 설정
#------------------------------------------------------------------------------------
    if keyBoard == 81:                         # 좌 회전 Arrow Left
        GPIO.output(MOTOR_L_DIR,GPIO.LOW)      # 왼쪽 모터 후진
        GPIO.output(MOTOR_R_DIR,GPIO.HIGH)     # 오른쪽 모터 전진
        MOTOR_L.ChangeDutyCycle(90)            # 왼쪽 모터 PWM 값 설정
        MOTOR_R.ChangeDutyCycle(90)            # 오른쪽 모터 PWM 값 설정
#------------------------------------------------------------------------------------
    if keyBoard == 83:                         # 우 회전 Arrow Right
        GPIO.output(MOTOR_L_DIR,GPIO.HIGH)     # 왼쪽 모터 전진
        GPIO.output(MOTOR_R_DIR,GPIO.LOW)      # 오른쪽 모터 후진
        MOTOR_L.ChangeDutyCycle(90)            # 왼쪽 모터 PWM 값 설정
        MOTOR_R.ChangeDutyCycle(90)            # 오른쪽 모터 PWM 값 설정
#------------------------------------------------------------------------------------
GPIO.cleanup()                         # GPIO 모듈의 점유 리소스 해제
#====================================================================================

