#################################################################
#################################################################
#################################################################
#                                                               
# SE-RPiCAR                                                     
# pf21.py                                                       
#                                                               
#                                                               
# 자율 주행 자동차 
# 
# 자율 주행 모드 1: 차선 1 개를 따라 주행합니다.
# 자율 주행 모드 2: 1개 차로(차선 2개) 주행합니다. 
# 자율 주행 모드 3: 2개 차로(차선 3개) 주행시 오른쪽 차로로 주행합니다.
#
# 적색 신호등에서 정차합니다.
# 녹색 신호등에서 출발합니다.
#
# 수동 조작 모드 키
#
# ESC,TAB: 프로그램 종료                                          
#
# UP   : 전진
# Left : 좌회전                                             
# Right: 우회전                                    
# Down : 후진                                         
#                                            
# a,A  : 자율 주행 모드                                           
# v,V  : 신호등 설정 모드                            
# c,C  : 컨투어(차선) 설정 모드
#                                  
# b,B  : 컨투어(차선) 흑백 스레쉬홀드 레벨                                    
# k,K  : 컨투어(차선) 침식 k 계수
# l,L  : 컨투어(차선) 면적(길이)                                          
# p,P  : 컨투어(차선) 가로 세로 비율                          
#                                             
# u,U  : 적색 iE
# i,I  : 적색 iS
# o,O  : 적색 LS
# p,P  : 적색 LV
# t,T  : 적색 카운트 레벨
# y,Y  : 적색 밝기 레벨
#
# h,H  : 녹색 iE
# j,J  : 녹색 iS
# k,K  : 녹색 LS
# l,L  : 녹색 LV
# f,F  : 녹색 카운트 레벨
# g,G  : 녹색 밝기 레벨
#
#                                                   
# NOV 25 2019                                                   
#
# SAMPLE Electronics co.                                        
# http://www.ArduinoPLUS.cc                                     
#                                                               
#################################################################
# Library Import ================================================
import time
import numpy as np
import cv2 as cv
import RPi.GPIO as GPIO
import math
import operator
# Constant ------------------------------------------------------
title = "PiCAR"
RED     =   0,  0,255     # Red
GREEN   =   0,255,  0     # Green
BLUE    = 255,  0,  0     # Blue
PINK    = 255,  0,255     # Pink
MAGENTA = 255,255,  0     # Magenta(Sky Blue)
YELLOW  =   0,255,255     # Yellow
WHITE   = 255,255,255     # White
GRAY    = 127,127,127     # Gray
BLACK   = 0,0,0
VIDEO_X = 640             # Video X Size (960x240 / 960x800 / 1600x240)
VIDEO_Y = 480             # Video Y Size
CONT_U  = 230             # 320 = 230 + 90    위쪽 차선 인식 제외 부분  
CONT_D  = 90              # 160 = 480 - 320   아래 차선 인식 제외 부분
CONT_LR = 2               #                   좌,우 차선 인식 제외 부분
MOTOR_L_PWM = 12          # GPIO.12    왼쪽 모터 펄스 푹 변조
MOTOR_L_DIR = 5           # GPIO.5     원쪽 모터 방향
MOTOR_R_PWM = 13          # GPIO.13    오른쪽 모터 펄스 폭 변조
MOTOR_R_DIR = 6           # GPIO.6     오른쪽 모터 방향
SERVO_PAN   = 16          # GPIO.16    카메라 서보 좌/우 
SERVO_TILT  = 19          # GPIO.19    카메라 서보 상/하
SPEED_MF = 100            # 수동 조작 전진 속도 (1~100)
SPEED_MT = 80             # 수동 조작 죄/우 회전 속도 (1~100)
SPEED_MB = 50             # 수동 조작 후진 속도 (1~100)
SPEED_AF = 70             # 자율 주행 전진 속도 (1~100)
SPEED_AT = 50             # 자율 주행 좌/우 회전 속도 (1~100)
SERVO_MIN = 0.001         # 1.0 mS   서보 펄스 최소 시간
SERVO_MAX = 0.002         # 2.0 mS   서보 펄스 최대 시간
# Red 색상 검출 영역(HSV 색상 좌표계)은 2 개의 영역
# 첫번째 영역 B은 0 에서 15 이고 두번째 영역 T은 165 에서 179 까지
#
# red_UH > 180 그리고 red_LH > 180 이면
#     red_BUH = red_UH - 180 
#     red_BLH = red_LH - 180
#     red_TUH = 179
#     red_TLH = 179
#
# red_UH > 180 그리고 red_LH < 180 이면
#     red_BUH = red_UH - 180 
#     red_BLH = 0
#     red_TUH = 179
#     red_TLH = red_LH
#
# red_UH < 180 그리고 red_LH < 180 이면
#     red_BUH = 0 
#     red_BLH = 0
#     red_TUH = red_UH
#     red_TLH = red_LH
#
#
TS_DIA_MIN  = 14           # 신호등 검출 최소 반지름
TS_DIA_MAX  = 30           # 신호등 검출 최대 반지름
red_bs = 74                # 0 부터 639 까지의 Red 시작 인덱스 번호
red_be = 228               # 0 부터 639 까지의 Red 종료 인덱스 번호
grn_bs = 394               # 0 부터 639 까지의 Green 시작 인덱스 번호
grn_be = 576               # 0 부터 639 까지의 Green 종료 인덱스 번호
red_AUH = 0                # Red   HSV 각도: 최대 +30도   
red_ALH = 0                # Red   HSV 각도: 최소 -30도
red_PUH = 0                #
red_PLH = 0                #
red_NUH = 0                # 
red_NLH = 0                #
red_LS  = 50               # 0 - 255
red_LV  = 50               # 0 - 255
grn_AUH = 0                # Green HSV 각도: 최대 +90도
grn_ALH = 0                # Green HSV 각도: 최대 +30도
grn_LS  = 50               # 0 - 255
grn_LV  = 50               # 0 - 255
rTsH =  30                 # Red   신호등 판단 수평 H
rTsV = 200                 # Red   신호등 판단 수직 V
gTsH =  30                 # Green 신호등 판단 수평 H
gTsV = 200                 # Green 신호등 판단 수직 V
trafficLight = True        # 신호등 상태 기본으로 True(녹색)
kSize = 3                  # 컨투어 침식 연산에서 Kenel Size
aspRatio = 2.0             # 인식된 차선의 가로 세로 비율
autoRunF = False           # 자율 주행 모드
keyBoard = 0x00
enew = 0
eold = 0
ctrSetMode = False
GBAR_VL = -10              # 왼쪽 가이드 선 
GBAR_VR =  10              # 오른쪽 가이드선
contArea = 100             # 차선 형상 컨투어 길이
threshLevel = 135          # 차선 인식(Black/White) 판단 레벨
contourcount = 0
ctrdict = {}         # {1: 94, 2: 24, 3: 39, 4: 11, 5: 349, 6: 255}
ctrlist = []         # [5, 6, 1, 3, 2, 4]
skeylist = []
linelist = []
loadsnx = []
loadsny = []
btnForward   = np.array([52, 140, 98, 174],dtype=np.int32)
btnTurnLeft  = np.array([2, 180, 48, 214],dtype=np.int32)
btnStop      = np.array([52, 180, 98, 214],dtype=np.int32)
btnTurnRight = np.array([102, 180, 148, 214],dtype=np.int32)
btnBackward  = np.array([52, 220, 98, 254],dtype=np.int32)
servoArea    = np.array([16, 10, 136, 130],dtype=np.int32)
autoRun      = np.array([14, 144, 38, 168],dtype=np.int32)
n = 2
if n ==2:
    btnForward = btnForward/2
    btnTurnLeft = btnTurnLeft/2
    btnStop = btnStop/2
    btnTurnRight = btnTurnRight/2
    btnBackward = btnBackward/2
    servoArea = servoArea/2
    autoRun = autoRun/2
# Global Variable------------------------------------------------
servoP = (SERVO_MIN+SERVO_MAX)/2.0    # 초기 서보 Pan 펄스 시간 1.5mS
servoT = (SERVO_MIN+SERVO_MAX)/2.0    # 초기 서보 Tilt 펄스 시간 1.5mS
# Set up --------------------------------------------------------
GPIO.setmode(GPIO.BCM)                # GPIO 핀 번호를 BCM 방식으로 설정 
GPIO.setwarnings(False)               # 경고 메시지 출력 안보기로 설정
GPIO.setup(MOTOR_L_PWM,GPIO.OUT)      #
GPIO.setup(MOTOR_L_DIR,GPIO.OUT)      #
GPIO.setup(MOTOR_R_PWM,GPIO.OUT)      #
GPIO.setup(MOTOR_R_DIR,GPIO.OUT)      #
GPIO.setup(SERVO_PAN,GPIO.OUT)        #
GPIO.setup(SERVO_TILT,GPIO.OUT)       #
MOTOR_L = GPIO.PWM(MOTOR_L_PWM,500)   # PWM 주파수 500Hz
MOTOR_R = GPIO.PWM(MOTOR_R_PWM,500)   # PWM 주파수 500Hz
MOTOR_L.start(0)                      # 왼쪽 모터 펄스폭 변조 값 0 으로 시작
MOTOR_R.start(0)                      # 오른쪽 모터 펄스폭 변조 값 0 으로 시작
# Video Window --------------------------------------------------
cam = cv.VideoCapture(0,cv.CAP_V4L)   # 카메라 객체 0 번으로 등록
cam.set(3,VIDEO_X)              # Video X Size
cam.set(4,VIDEO_Y)              # Video Y Size
ret, frame = cam.read()         # Capture Frame by Frame
height, width, _ = frame.shape  # 실제 동작의 화면 세로(height), 가로(width)
print(height, width)            # 
# Button Drawing Function =======================================
def button(x1,y1,x2,y2):
    for i in range(0,9):
        cv.rectangle(img,(x1+i,y1+i),(x2-i,y2-i),(0,i*30,255),1)
    cv.rectangle(img,(x1+i,y1+i),(x2-i,y2-i),YELLOW,-1)
# Servo Function ------------------------------------------------
# Line Equation (Two Points Form)
#
#           (y2-y1)
# (y-y1) = -------- * (x-x1)
#           (x2-x1)
#
# Pan  => (15, 0.002)-(135, 0.001)
# Tilt => (10, 0.001)-(130, 0.002)
#
def servoControl():  # 서보 펄스 발생
    for i in range(1,30):
        GPIO.output(SERVO_PAN, GPIO.HIGH)
        time.sleep(servoP)
        GPIO.output(SERVO_PAN, GPIO.LOW)
        GPIO.output(SERVO_TILT, GPIO.HIGH)
        time.sleep(servoT)
        GPIO.output(SERVO_TILT, GPIO.LOW)
        time.sleep(0.01)
# Motor Run Function --------------------------------------------
# +N = Forward
#  0 = Stop
# -N = Backward
#
def motorRun(leftMotor, rightMotor):
    if (leftMotor>=0):
        GPIO.output(MOTOR_L_DIR,GPIO.HIGH)
        MOTOR_L.ChangeDutyCycle(leftMotor)
    else:
        GPIO.output(MOTOR_L_DIR,GPIO.LOW)
        MOTOR_L.ChangeDutyCycle(abs(leftMotor))
    if (rightMotor>=0):
        GPIO.output(MOTOR_R_DIR,GPIO.HIGH)
        MOTOR_R.ChangeDutyCycle(rightMotor)
    else:
        GPIO.output(MOTOR_R_DIR,GPIO.LOW)
        MOTOR_R.ChangeDutyCycle(abs(rightMotor))
# Auto Run Function --------------------------------------------
# +N = Forward
#  0 = Stop
# -N = Backward
#
def autoMotorRun(leftMotor, rightMotor):
    if autoRunF: 
        if trafficLight:
            if (leftMotor>=0):
                GPIO.output(MOTOR_L_DIR,GPIO.HIGH)
                MOTOR_L.ChangeDutyCycle(leftMotor)
            else:
                GPIO.output(MOTOR_L_DIR,GPIO.LOW)
                MOTOR_L.ChangeDutyCycle(abs(leftMotor))
            if (rightMotor>=0):
                GPIO.output(MOTOR_R_DIR,GPIO.HIGH)
                MOTOR_R.ChangeDutyCycle(rightMotor)
            else:
                GPIO.output(MOTOR_R_DIR,GPIO.LOW)
                MOTOR_R.ChangeDutyCycle(abs(rightMotor))
        else:
            MOTOR_L.ChangeDutyCycle(0)
            MOTOR_R.ChangeDutyCycle(0)
# HSV Red Color ------------------------------------------------
def redColorProc():
    global red_PUH
    global red_PLH
    global red_NUH
    global red_NLH
    global red_AUH
    global red_ALH 
    global grn_AUH
    global grn_ALH
    red_AUH = int((red_be*150/640)+135-180)
    red_ALH = int((red_bs*150/640)+135-180)
    grn_AUH = int((grn_be*150/640)+135-180)
    grn_ALH = int((grn_bs*150/640)+135-180)
    if(red_AUH>=0 and red_ALH>=0):
        red_PUH = red_AUH
        red_PLH = red_ALH
        red_NUH = 179
        red_NLH = 179
    elif(red_AUH>=0 and red_ALH<0):
        red_PUH = red_AUH
        red_PLH = 0
        red_NUH = 179
        red_NLH = red_ALH+180
    elif(red_AUH<0 and red_ALH<0):
        red_PUH = 0
        red_PLH = 0
        red_NUH = red_AUH+180
        red_NLH = red_ALH+180
# Traffic Signal Setting ----------------------------------------
def trafSigSet():    # 신호등 인식 색상 조건 설정
    global red_bs    # Red   Index Number
    global red_be
    global grn_bs    # Green Index Number
    global grn_be
    global red_AUH   # Red   HSV Angle 
    global red_ALH      
    global red_PUH         
    global red_PLH
    global red_NUH         
    global red_NLH
    global red_LS           
    global red_LV        
    global grn_AUH   # Green HSV Angle
    global grn_ALH        
    global grn_LS           
    global grn_LV         
    global rTsH                       # Red   신호등 판단 수평 H
    global rTsV                       # Red   신호등 판단 수직 V
    global gTsH                       # Green 신호등 판단 수평 H
    global gTsV                       # Green 신호등 판단 수직 V
    global trafficLight               # 신호등 상태 기본으로 True(녹색)
    while(cam.isOpened()):            # 카메라 객체 동작 확인
        ret, frame = cam.read()       # 이미지 1 프레임 읽기
        height, width, _ = frame.shape
        #--------------------------------------------------------
        imgray=cv.cvtColor(frame,cv.COLOR_BGR2GRAY)  # 컬러에서 그레이 색으로 전환
        tsbgray = imgray[0:120,:]     # 위쪽(Y:0-119) 이미지만 신호등 감지 영역 
        frame[120:,:] = BLACK         # 아래쪽(Y:120- ) 영역 검정색
        i = 0; r = 128; g = 0; b = 254;           # A 레인보우 바
        while(i<64):     
            frame[150:200,i:i+1] = b,g,r
            r += 2
            i += 1
        i = 64; r = 254; g = 0; b = 254           # B
        while(i<192):
            frame[150:200,i:i+1] = b,g,r
            b -= 2
            i += 1
        i = 192; r = 254; g = 0; b = 0;           # C
        while(i<320):
            frame[150:200,i:i+1] = b,g,r
            g += 2
            i += 1
        i = 320; r = 254; g = 254; b = 0;         # D
        while(i<448):
            frame[150:200,i:i+1] = b,g,r
            r -= 2
            i += 1
        i = 448; r = 0; g = 254; b = 0;           # E
        while(i<576):
            frame[150:200,i:i+1] = b,g,r
            b += 2
            i += 1
        i = 576; r = 0; g = 254; b = 254;         # F
        while(i<640):
            frame[150:200,i:i+1] = b,g,r
            g -= 2
            i += 1
        frame[402:404,14+0:14+256+2] = RED     # Red   히스토그램 영역 표시
        frame[402:404,370+0:370+256+2] = GREEN # Green 히스토그램 영역 표시
        frame[130:140,red_bs:red_be] = RED     # Red   Index Bar
        frame[210:220,grn_bs:grn_be] = GREEN   # Green Index Bar
        cv.rectangle(frame,(14+rTsV,400-rTsH),(14+256,400),RED,1)     # Red 
        cv.rectangle(frame,(370+gTsV,400-gTsH),(370+256,400),GREEN,1) # Green 
        redColorProc()   # Red 각도를 P, N HSV 코드로 변경한다.
        cv.putText(frame,"R.iE(U):"+str(red_be)+" R.iS(I):"+str(red_bs),
                         (14,250),cv.FONT_HERSHEY_PLAIN,1.5,WHITE)
        cv.putText(frame,"R.LS(O):"+str(red_LS),
                         (14,270),cv.FONT_HERSHEY_PLAIN,1.5,WHITE)
        cv.putText(frame,"R.LV(P):"+str(red_LV),
                         (14,290),cv.FONT_HERSHEY_PLAIN,1.5,WHITE)
        cv.putText(frame,"R.TSH(T):"+str(rTsH),
                         (14,310),cv.FONT_HERSHEY_PLAIN,1.5,WHITE)
        cv.putText(frame,"R.TSV(Y):"+str(rTsV),
                         (14,330),cv.FONT_HERSHEY_PLAIN,1.5,WHITE)
        cv.putText(frame,"R.aUH:"+str(red_AUH)+" R.aLH:"+str(red_ALH),
                         (14,430),cv.FONT_HERSHEY_PLAIN,1.5,WHITE)
        cv.putText(frame,"R.PUH:"+str(red_PUH)+" R.PLH:"+str(red_PLH),
                         (14,450),cv.FONT_HERSHEY_PLAIN,1.5,WHITE)
        cv.putText(frame,"R.NUH:"+str(red_NUH)+" R.NLH:"+str(red_NLH),
                         (14,470),cv.FONT_HERSHEY_PLAIN,1.5,WHITE)
        cv.putText(frame,"G.iE(H):"+str(grn_be)+" G.iS(J):"+str(grn_bs),
                         (370,250),cv.FONT_HERSHEY_PLAIN,1.5,WHITE)
        cv.putText(frame,"G.LS(K):"+str(grn_LS),
                         (370,270),cv.FONT_HERSHEY_PLAIN,1.5,WHITE)
        cv.putText(frame,"G.LV(L):"+str(grn_LV),
                         (370,290),cv.FONT_HERSHEY_PLAIN,1.5,WHITE)
        cv.putText(frame,"G.TSH(F):"+str(gTsH),
                         (370,310),cv.FONT_HERSHEY_PLAIN,1.5,WHITE)
        cv.putText(frame,"G.TSV(G):"+str(gTsV),
                         (370,330),cv.FONT_HERSHEY_PLAIN,1.5,WHITE)
        cv.putText(frame,"G.aUH:"+str(grn_AUH)+" G.aLH:"+str(grn_ALH),  
                         (370,430),cv.FONT_HERSHEY_PLAIN,1.5,WHITE)
        circles = cv.HoughCircles(   # 신호등 원 검출
                     tsbgray,        # 그레이 스케일 신호등 이미지 사용
                     method=cv.HOUGH_GRADIENT,  # 원 검출 방법
                     dp=1,           # The inverse ratio of resolution.
                     minDist=60,     # 검출된 원 중심점 간의 최소거리
                     param1=100,     # Canny 에지 검출을 위한 상위 스레시홀드값
                     param2=30,      # Threshold for center detection
                     minRadius=TS_DIA_MIN, # 원(신호등)의 최소 반지름
                     maxRadius=TS_DIA_MAX  # 원(신호등)의 최대 반지름
                     )
        if circles is not None:
            circles = np.uint16(np.around(circles))
            for i in circles[0,:]:
                center = (i[0], i[1]); radius = i[2]
                if(i[1]>30 and i[1]<100 and i[0]>30 and i[0]<620):
                    tsa = frame[i[1]-30:i[1]+30,i[0]-30:i[0]+30]           
                    cv.circle(frame,center,radius,(YELLOW),1)  # 검출된 원 표
                    cv.putText(frame,"X:"+str(i[0])+" Y:"+str(i[1])+
                                     " R:"+str(i[2]),(i[0]-90,i[1]+40),
                                     cv.FONT_HERSHEY_COMPLEX_SMALL,1,WHITE)
                    # BGR 색상 좌표계를 HSV 색상 좌표계로 변 
                    hsv = cv.cvtColor(tsa, cv.COLOR_BGR2HSV)
                    # 녹색 신호등 처리
                    upper_color = np.array([grn_AUH,255,255])        # Upper
                    lower_color = np.array([grn_ALH,grn_LS,grn_LV])  # Lower
                    # Threshold the HSV image to get only selected colors
                    mask = cv.inRange(hsv, lower_color, upper_color)
                    # Bitwise-AND mask and original image
                    resG = cv.bitwise_and(tsa,tsa,mask=mask)
                    histGb = cv.calcHist([resG],[0],None,[256],[0,256])
                    histGg = cv.calcHist([resG],[1],None,[256],[0,256])
                    histGr = cv.calcHist([resG],[2],None,[256],[0,256])
                    # for Red-B Color
                    upper_color = np.array([red_PUH,255,255])        # Upper
                    lower_color = np.array([red_PLH,red_LS,red_LV])  # Lower
                    # Threshold the HSV image to get only selected colors
                    maskP = cv.inRange(hsv, lower_color, upper_color)
                    # for Red-N Color
                    upper_color = np.array([red_NUH,255,255])        # Upper
                    lower_color = np.array([red_NLH,red_LS,red_LV])  # Lower
                    # Threshold the HSV image to get only selected colors
                    maskN = cv.inRange(hsv, lower_color, upper_color)
                    mask = cv.bitwise_or(maskP, maskN)
                    # Bitwise-AND mask and original image
                    resR = cv.bitwise_and(tsa,tsa,mask=mask)
                    histRb = cv.calcHist([resR],[0],None,[256],[0,256])
                    histRg = cv.calcHist([resR],[1],None,[256],[0,256])
                    histRr = cv.calcHist([resR],[2],None,[256],[0,256])
                    cv.rectangle(resR,(0,0),(59,59),RED,1)   # Red   신호 사각형 외곽선
                    cv.rectangle(resG,(0,0),(59,59),GREEN,1) # Green 신호 사각형 외곽선 
                    try:
                        sx, sy, _ = resR.shape
                        frame[10:(10+sy),10:(10+sx)] = resR
                        sx, sy, _ = resG.shape
                        frame[10:(10+sy),570:(570+sx)] = resG
                    except:
                        print("resR/G Copy Error")
                    histGb[0] = 0; histGg[0] = 0; histGr[0] = 0
                    histRb[0] = 0; histRg[0] = 0; histRr[0] = 0
                    # Green 신호등 B,G,R 성분 최대 표시 원
                    gbM = int(np.amax(histGb))        # 히스토그램 데이터중 최대값
                    gbmW =np.where(histGb==gbM)       # 최대값의 위치(배열 형)
                    gbmWV = int(gbmW[0][0])           # 최대값의 위치(스칼라 형)
                    if gbM > 0:
                        cv.circle(frame,(370+gbmWV,401-gbM),4,YELLOW,1)
                    ggM = int(np.amax(histGg))        # 히스토그램 데이터중 최대값
                    ggmW =np.where(histGg==ggM)       # 최대값의 위치(배열 형)
                    ggmWV = int(ggmW[0][0])           # 최대값의 위치(스칼라 형)
                    if ggM > 0:
                        cv.circle(frame,(370+ggmWV,401-ggM),4,YELLOW,1)
                    grM = int(np.amax(histGr))        # 히스토그램 데이터중 최대값
                    grmW =np.where(histGr==grM)       # 최대값의 위치(배열 형)
                    grmWV = int(grmW[0][0])           # 최대값의 위치(스칼라 형)
                    if grM > 0:
                        cv.circle(frame,(370+grmWV,401-grM),4,YELLOW,1)
                    # Red 신호등 B,G,R 성분 최대 표시 원
                    rbM = int(np.amax(histRb))        # 히스토그램 데이터중 최대값
                    rbmW =np.where(histRb==rbM)       # 최대값의 위치(배열 형)
                    rbmWV = int(rbmW[0][0])           # 최대값의 위치(스칼라 형)
                    if rbM > 0:
                        cv.circle(frame,(14+rbmWV,401-rbM),4,YELLOW,1)
                    rgM = int(np.amax(histRg))        # 히스토그램 데이터중 최대값
                    rgmW =np.where(histRg==rgM)       # 최대값의 위치(배열 형)
                    rgmWV = int(rgmW[0][0])           # 최대값의 위치(스칼라 형)
                    if rgM > 0:
                        cv.circle(frame,(14+rgmWV,401-rgM),4,YELLOW,1)
                    rrM = int(np.amax(histRr))        # 히스토그램 데이터중 최대값
                    rrmW =np.where(histRr==rrM)       # 최대값의 위치(배열 형)
                    rrmWV = int(rrmW[0][0])           # 최대값의 위치(스칼라 형)
                    if rrM > 0:
                        cv.circle(frame,(14+rrmWV,401-rrM),4,YELLOW,1)
                    # Green 신호등 히스토그램 
                    for i in range(0,256):       # Green 신호등에서 Blue 성분
                        k = int(histGb[i])
                        if k> 400:
                            k = 400
                        frame[401-k:400,370+i:370+i+1,0] = 0xFF # Blue 층(0)
                    for i in range(0,256):       # Green 신호등에서 Green 성분
                        k = int(histGg[i])
                        if k> 400:
                            k = 400
                        frame[401-k:400,370+i:370+i+1,1] = 0xFF # Green 층(1)
                    for i in range(0,256):       # Green 신호등에서 Red 성분
                        k = int(histGr[i])
                        if k> 400:
                            k = 400
                        frame[401-k:400,370+i:370+i+1,2] = 0xFF # Red 층(2)
                    # Red 신호등 히스토그램 
                    for i in range(0,256):       # Red 신호등에서 Blue 성분
                        k = int(histRb[i])
                        if k> 400:
                            k = 400
                        frame[401-k:400,14+i:14+i+1,0] = 0xFF # Blue 층(0)
                    for i in range(0,256):       # Red 신호등에서 Green 성분
                        k = int(histRg[i])
                        if k> 400:
                            k = 400
                        frame[401-k:400,14+i:14+i+1,1] = 0xFF # Green 층(1)
                    for i in range(0,256):       # Red 신호등에서 Red 성분
                        k = int(histRr[i])
                        if k> 400:
                            k = 400
                        frame[401-k:400,14+i:14+i+1,2] = 0xFF # Red 층(2)
                    if ggmWV > gTsV and ggM > gTsH:
                        trafficLight = True
                    if rrmWV > rTsV and rrM > rTsH:
                        trafficLight = False
        if trafficLight:
            cv.circle(frame,(320,320),15,GREEN,-1)  # 녹색 신호등 검출 결과 표시 
        else:
            cv.circle(frame,(320,370),15,RED,-1)    # 적색 신호등 검출 결과 표시
        frame = cv.pyrDown(frame)
        cv.imshow('Traffic Signal Config.',frame)   # 신호등 설정 화면 표시   
        keyBoard = cv.waitKey(1)&0xFF
        if (keyBoard == 0x56 or keyBoard == 0x76): # V Key
            cv.destroyWindow('Traffic Signal Config.')
            return
        elif keyBoard == 0x55:         # U: Red UH
            if red_be < 320:
                red_be += 2
        elif keyBoard == 0x75:         # u: Red UH
            if red_be > 64 and red_be > (red_bs+4):
                red_be -= 2
        elif keyBoard == 0x49:         # I: Red LH
            if red_bs < 320 and red_bs < (red_be-4):
                red_bs += 2
        elif keyBoard == 0x69:         # i: Red LH
            if red_bs > 64:
                red_bs -= 2
        elif keyBoard == 0x4F:         # O: Red LS
            if red_LS < 254:
                red_LS += 2
        elif keyBoard == 0x6F:         # o: Red LS
            if red_LS > 1:
                red_LS -= 2
        elif keyBoard == 0x50:         # P: Red LV
            if red_LV < 254:
                red_LV += 2
        elif keyBoard == 0x70:         # p: Red LV
            if red_LV > 1:
                red_LV -= 2
        elif keyBoard == 0x48:         # H: Green UH
            if grn_be < 576:
                grn_be += 2
        elif keyBoard == 0x68:         # h: Green UH
            if grn_be > 320 and grn_be > (grn_bs+4):
                grn_be -= 2
        elif keyBoard == 0x4A:         # J: Green LH
            if grn_bs < 576 and grn_bs < (grn_be-4):
                grn_bs += 2
        elif keyBoard == 0x6A:         # j: Green LH
            if grn_bs > 320:
                grn_bs -= 2
        elif keyBoard == 0x4B:         # K: Green LS
            if grn_LS < 254:
                grn_LS += 2
        elif keyBoard == 0x6B:         # k: Green LS
            if grn_LS > 1:
                grn_LS -= 2
        elif keyBoard == 0x4C:         # L: Green LV
            if grn_LV < 254:
                grn_LV += 2
        elif keyBoard == 0x6C:         # l: Green LV
            if grn_LV > 1:
                grn_LV -= 2
#----------------------------------------------------------------
        elif keyBoard == 0x54:         # T:  rTsS +
            if rTsH < 253:
                rTsH += 2
        elif keyBoard == 0x74:         # t:  rTsS -
            if rTsH > 1:
                rTsH -= 2
        elif keyBoard == 0x59:         # Y:  rTsE +
            if rTsV < 253:
                rTsV += 2
        elif keyBoard == 0x79:         # y:  rTsE -
            if rTsV > 1:
                rTsV -= 2
        elif keyBoard == 0x46:         # F:  gTsS +
            if gTsH < 253:
                gTsH += 2
        elif keyBoard == 0x66:         # f:  gTsS -
            if gTsH > 1:
                gTsH -= 2
        elif keyBoard == 0x47:         # G:  gTsE +
            if gTsV < 253:
                gTsV += 2
        elif keyBoard == 0x67:         # g:  gTsE -
            if gTsV > 1:
                gTsV -= 2
# Traffic Signal Detect ----------------------------------------
def trafficSignalDetect(imgray):
    global trafficLight
    tsbgray = imgray[0:120,:]
    circles = cv.HoughCircles(
                 tsbgray,        # 그레이 스케일 신호등 이미지 사용
                 method=cv.HOUGH_GRADIENT,  # 원 검출 방법
                 dp=1,           # The inverse ratio of resolution.
                 minDist=60,     # 검출된 원 중심점 간의 최소거리
                 param1=100,     # Canny 에지 검출을 위한 상위 스레시홀드값
                 param2=30,      # Threshold for center detection
                 minRadius=TS_DIA_MIN, # 원(신호등)의 최소 반지름
                 maxRadius=TS_DIA_MAX  # 원(신호등)의 최대 반지름
                 )
    if circles is not None:
        circles = np.uint16(np.around(circles))
        #print(circles)
        for i in circles[0,:]:
            center = (i[0], i[1]); radius = i[2]
            if(i[1]>30 and i[1]<100 and i[0]>30 and i[0]<620):
                tsa = frame[i[1]-30:i[1]+30,i[0]-30:i[0]+30]
                cv.circle(frame,center,radius,(YELLOW),1)  # circle outline
                cv.putText(frame,"X:"+str(i[0])+" Y:"+str(i[1])+
                                 " R:"+str(i[2]),(i[0]-90,i[1]+40),
                                 cv.FONT_HERSHEY_COMPLEX_SMALL,1,WHITE)
                # Convert BGR to HSV ==================================
                hsv = cv.cvtColor(tsa, cv.COLOR_BGR2HSV)
                # for Green Color
                upper_color = np.array([grn_AUH,255,255])        # Upper
                lower_color = np.array([grn_ALH,grn_LS,grn_LV])  # Lower
                # Threshold the HSV image to get only selected colors
                mask = cv.inRange(hsv, lower_color, upper_color)
                # Bitwise-AND mask and original image
                resG = cv.bitwise_and(tsa,tsa,mask=mask)
                histGg = cv.calcHist([resG],[1],None,[256],[0,256])
                histGr = cv.calcHist([resG],[2],None,[256],[0,256])
                # for Red-P Color
                upper_color = np.array([red_PUH,255,255])        # Upper
                lower_color = np.array([red_PLH,red_LS,red_LV])  # Lower
                # Threshold the HSV image to get only selected colors
                maskP = cv.inRange(hsv, lower_color, upper_color)
                # for Red-N Color
                upper_color = np.array([red_NUH,255,255])        # Upper
                lower_color = np.array([red_NLH,red_LS,red_LV])  # Lower
                # Threshold the HSV image to get only selected colors
                maskN = cv.inRange(hsv, lower_color, upper_color)
                mask = cv.bitwise_or(maskP, maskN)
                # Bitwise-AND mask and original image
                resR = cv.bitwise_and(tsa,tsa,mask=mask)
                histRr = cv.calcHist([resR],[2],None,[256],[0,256])
                histRg = cv.calcHist([resR],[1],None,[256],[0,256])
                cv.rectangle(resR,(0,0),(59,59),RED,1)   # Red   신호 사각형 외곽선
                cv.rectangle(resG,(0,0),(59,59),GREEN,1) # Green 신호 사각형 외곽선 
                try:    
                    frame[10:(10+60),10:(10+60)] = resR
                    frame[10:(10+60),570:(570+60)] = resG
                except:
                    print("resR/G copy Error")
                histGg[0] = 0
                histRr[0] = 0
                # Green 신호등 최대 분포값 위치 개수
                ggM = int(np.amax(histGg))        # 히스토그램 데이터중 최대값
                ggmW =np.where(histGg==ggM)       # 최대값의 위치(배열 형)
                ggmWV = int(ggmW[0][0])           # 최대값의 위치(스칼라 형)
                # Red   신호등 최대 분포값 위치 개수
                rrM = int(np.amax(histRr))        # 히스토그램 데이터중 최대값
                rrmW =np.where(histRr==rrM)       # 최대값의 위치(배열 형)
                rrmWV = int(rrmW[0][0])           # 최대값의 위치(스칼라 형)
                if ggmWV > gTsV and ggM > gTsH:
                    trafficLight = True
                    img[290:330,30:120] = GREEN
                if rrmWV > rTsV and rrM > rTsH:
                    trafficLight = False
                    img[290:330,30:120] = RED
# Mouse Callback Function ---------------------------------------
def controlMain(event,x,y,flags,param):
    global servoP
    global servoT
    global autoRunF
    global trafficLight
    print("X=",x,"Y=",y)
    if event == cv.EVENT_RBUTTONDOWN:             # 마우스 오른쪽 버튼 비상 정지 
        motorRun(0,0)
        autoRunF = False
        trafficLight = True
        cv.circle(img,(25,156),12,(0x7F,0xFF,0),-1)  # 자율 주행 
    if event == cv.EVENT_LBUTTONDOWN:
        # ------------------------------ 카메라 Pan/Tilt 제어 
        if servoArea[0] <x< servoArea[2] and servoArea[1] <y< servoArea[3]:
            servoP = (SERVO_MIN-SERVO_MAX)*(x-servoArea[0]) \
                      / (servoArea[2]-servoArea[0])+SERVO_MAX
            servoT = (SERVO_MAX-SERVO_MIN)*(y-servoArea[1]) \
                      / (servoArea[3]-servoArea[1])+SERVO_MIN
            servoControl()
        # ----------------------------- 수동 조정 DC 모터 제어
        elif btnForward[0] <x< btnForward[2] and \
             btnForward[1] <y< btnForward[3]:            # 전진
            motorRun(SPEED_MF,SPEED_MF)
            servoControl()
        elif btnTurnLeft[0] <x< btnTurnLeft[2] and \
             btnTurnLeft[1] <y< btnTurnLeft[3]:          # 좌회전 
            motorRun(-SPEED_MF,SPEED_MT)
            servoControl()
        elif (btnStop[0] <x< btnStop[2] and btnStop[1] <y< btnStop[3]) or \
            (80<x<390 and 10<y<230):                     # 정지 
            autoRunF = False
            trafficLight = True
            cv.circle(img,(25,156),12,(0x7F,0xFF,0),-1)  #
            motorRun(0,0)
            servoT = (SERVO_MIN+SERVO_MAX)/2.0
            servoP = (SERVO_MIN+SERVO_MAX)/2.0
            servoControl()
        elif btnTurnRight[0] <x< btnTurnRight[2] and \
             btnTurnRight[1] <y< btnTurnRight[3]:        # 우회전
            motorRun(SPEED_MF,-SPEED_MT)
            servoControl()
        elif btnBackward[0] <x< btnBackward[2] and \
             btnBackward[1] <y< btnBackward[3]:          # 후진 
            motorRun(-SPEED_MB,-SPEED_MB)
            servoControl()
        elif autoRun[0] <x< autoRun[2] and autoRun[1] <y< autoRun[3]:   # 자율 주행 모드 
            autoRunF = True
            trafficLight = True
            cv.circle(img,(25,156),6,(RED),-1)
# ---------------------------------------------------------------
def box_line(vx, vy, x1, y1):
    if (vx==0) and (vy!=0):
        xs=x1; ys=height-CONT_D; xe=x1; ye=CONT_U;
    elif (vx!=0)and(vy==0):
        xs=0; ys=y1; xe=width-1; ye=y1;
    elif (vx==0)and(vy==0):
        xs=x1; ys=height-CONT_D; xe=x1; ye=CONT_U;
    else:
        if abs(vx)<abs(vy):
            xs = 0; ys = (xs-x1)*vy/vx+y1                    # Vx != 0
            if ys>(height-CONT_D):
                ys=(height-CONT_D); xs=(ys-y1)*vx/vy+x1
            elif ys<CONT_U:
                ys=CONT_U; xs=(ys-y1)*vx/vy+x1
            # ----------------------------
            xe = (width-1); ye = (xe-x1)*vy/vx+y1            # vx != 0
            if ye>(height-CONT_D):
                ye=(height-CONT_D); xe=(ye-y1)*vx/vy+x1
            elif ye<CONT_U:
                ye=CONT_U; xe=(ye-y1)*vx/vy+x1
        else:
            ys = CONT_U; xs = (ys-y1)*vx/vy+x1               # vy != 0
            if xs>(width-1):
                xs=(width-1); ys=(xs-x1)*vy/vx+y1
            elif xs<0:
                xs=0; ys=(xs-x1)*vy/vx+y1
            #------------------------------
            ye = (height-CONT_D); xe = (ye-y1)*vx/vy+x1      # vy != 0
            if xe>(width-1):
                xe=(width-1); ye=(xe-x1)*vy/vx+y1
            elif xe<0:
                xe=0; ye=(xe-x1)*vy/vx+y1
        if ye>ys:
            xt = xe; xe = xs; xs = xt
            yt = ye; ye = ys; ys = yt
    return (xs, ys, xe, ye)    
# Control Window ------------------------------------------------
img = np.zeros((480,150,3),np.uint8)           
cv.namedWindow(title)
for i in range(0,273):          # 배경 색
    cv.line(img,(0,i),(149,i),(255-(i*0.8),255-(i*0.8)),1)
for i in range(0, 60):          # Pan/Tilt
    cv.circle(img,(75,70),i,(255-(i*2.5),255-(i*2.5),255-(i*2.5)),2)
button(52,139,97,174)           # 직진 버튼
button(2,179,47,214)            # 좌회전 버튼
button(52,179,97,214)           # 정지 버튼
button(102,179,147,214)         # 우회전 버튼
button(52,219,97,254)           # 후진 버튼
cv.circle(img,(25,156),12,(0x7F,0xFF,0),-1)  # 자율 주행 버튼
cv.putText(img,'Raspberry Pi RC CAR',(8,268),cv.FONT_HERSHEY_SIMPLEX,0.4,WHITE)
cv.putText(img,'C: Contour',(8,430),cv.FONT_HERSHEY_SIMPLEX,0.6,WHITE)
cv.putText(img,'V: Traffic',(8,450),cv.FONT_HERSHEY_SIMPLEX,0.6,WHITE)
cv.putText(img,'ESC: Exit',(8,470),cv.FONT_HERSHEY_SIMPLEX,0.6,WHITE)
# Mouse Event ---------------------------------------------------
cv.setMouseCallback(title,controlMain)
# Servo Reset ---------------------------------------------------
servoControl()
redColorProc()
# Main Loop =====================================================
while(cam.isOpened()):
    eold=enew; enew=cv.getTickCount()
    vx0 = vy0 = x0 = y0 = 0
    vx2 = vy2 = x2 = y2 = 0
    ret, frame = cam.read()     # Capture Frame by Frame
    height, width, _ = frame.shape
    #------------------------------------------------------------
    imgray=cv.cvtColor(frame,cv.COLOR_BGR2GRAY)
    trafficSignalDetect(imgray)
    imgray = cv.bitwise_not(imgray)
    ret,thresh=cv.threshold(imgray,threshLevel,255, cv.THRESH_BINARY)
    thresh[0:CONT_U,:] = 0xFF
    thresh[(height-CONT_D):height,:] = 0xFF
    thresh[:,0:CONT_LR] = 0xFF
    thresh[:,(width-CONT_LR):width] = 0xFF
    k = cv.getStructuringElement(cv.MORPH_RECT,(kSize,kSize))   # 구조화 커널
    dilate = cv.dilate(thresh, k)
    contours,hierarchy=cv.findContours(dilate,cv.RETR_TREE,cv.CHAIN_APPROX_NONE)
    cv.drawContours(frame, contours,-1,(0,0,255),1)        # (0)  All Draw Contour
    contourcount = len(contours)       # 컨투어가 없어도 프레임이 컨투어 이므로 최소 1
    for i in range(1,contourcount):    # 프레임 컨투어 0 번은 제외하고 1번 부터 
        ctrdict[i] = cv.contourArea(contours[i]) # 컨투어 딕셔너리에 번호(i)와 컨투어면적
    # 컨투어(검출된 차선) 길이(면적) 크기순(내림차순)으로 정열한다. 
    skeylist = sorted(ctrdict, key=ctrdict.__getitem__, reverse=True)
    loaddata = [[0.0, 0.0, 0.0, 0.0],[0.0, 0.0, 0.0, 0.0],[0.0, 0.0, 0.0, 0.0]]
    j = 0
    i = 0    # skeylist 에 저장된 컨투어 번호를 가져올 인덱스로 사용한다.
    while j < (contourcount-1):
        k = skeylist[j]
        m = len(contours[k])                  # 컨투어 길이 (Length / Area)
        if m > contArea:                      # 컨투어 길이가 기준보다 커야 한다.
            rect=cv.minAreaRect(contours[k])
            box=cv.boxPoints(rect)
            box=np.intp(box)
            cv.drawContours(frame,[box],0,(255,255,0),1)  # 컨투어 근접 사각형 표시
            ww = math.sqrt((box[0][0]-box[1][0])**2 + (box[0][1]-box[1][1])**2)
            hh = math.sqrt((box[1][0]-box[2][0])**2 + (box[1][1]-box[2][1])**2)
            if ww!=0 or hh!=0:                # 컨투어 가로와 세로의 크기가 둘다 0 이면 제외   
                if(ww>hh):
                    apratio = ww/hh
                else:
                    apratio = hh/ww
                if apratio > aspRatio:        # 컨투어 가로/세로 비율 검사
                    vx0, vy0, x0, y0 = cv.fitLine(contours[k],cv.DIST_L2,0,0.01,0.01)
                    loaddata[i][0] = float(vx0)    # 컨투어 직선 기울기 dX
                    loaddata[i][1] = float(vy0)    # 컨투어 직선 기울기 dY
                    loaddata[i][2] = float(x0)     # 컨투어 중점 좌표   X
                    loaddata[i][3] = float(y0)     # 컨투어 중점 좌표   Y
                    xs, ys, xe, ye = box_line(vx0, vy0, x0, y0) # 박스에 걸리는 확장 직선
                    cv.line(frame,(int(xs),int(ys)),(int(xe),int(ye)),GREEN,1)    
                    cv.circle(frame,(int(xs),int(ys)),9,RED,-1)       # 차선 시점
                    cv.circle(frame,(int(xe),int(ye)),6,MAGENTA,-1)   # 차선 종점
                    #cv.putText(frame,"L:"+str(m),(x0,y0),cv.FONT_HERSHEY_COMPLEX_SMALL,1,GREEN)
                    ap = int(apratio * 10); ap = ap/10
                    #cv.putText(frame,"R:"+str(ap),(x0,y0+18),cv.FONT_HERSHEY_COMPLEX_SMALL,1,GREEN)
                    i += 1
                    if i > 2:                      # 컨투어(차선) 3개 까지 
                        break  
            else:
                print("Contour Aspect Ratio ERROR!")
        j += 1
    cv.putText(frame,str(i),(308,210),cv.FONT_HERSHEY_COMPLEX_SMALL,2,WHITE) # Track
    # 검출된 차선이 2 개 또는 3 개일 때 컨투어의 X 좌표 기준으로 정열 
    loaddata = sorted(loaddata, key=operator.itemgetter(2), reverse=True)
    vx1 = loaddata[0][0]; vy1 = loaddata[0][1]
    x1  = loaddata[0][2]; y1  = loaddata[0][3]
    vx2 = loaddata[1][0]; vy2 = loaddata[1][1]
    x2  = loaddata[1][2]; y2  = loaddata[1][3]
    if i > 1:                               # 컨투어(차선)가 2 개 또는 3개 
        xs1, ys1, xe1, ye1 = box_line(vx1, vy1, x1, y1)
        xs2, ys2, xe2, ye2 = box_line(vx2, vy2, x2, y2)
        if ((xs1-xs2)*(ys1-ys2)*(xe1-xe2)*(ye1-ye2) < 0.0):
            xt = xe1; xe1 = xs1; xs1 = xt
            yt = ye1; ye1 = ys1; ys1 = yt
        xs = (xs1+xs2)/2; ys = (ys1+ys2)/2
        xe = (xe1+xe2)/2; ye = (ye1+ye2)/2
        xs, ys, xe, ye = box_line((xe-xs), (ye-ys), xs, ys)
    elif i == 1:                            # 컨투어(차선)가 1 개 
        xs, ys, xe, ye = box_line(vx1, vy1, x1, y1)
    else:
        xs = ys = xe = ye = 0
    cv.line(frame,(int(xs),int(ys)),(int(xe),int(ye)),PINK,3)    
    cv.circle(frame,(int(xs),int(ys)),9,RED,-1)         # 시점 원
    cv.circle(frame,(int(xe),int(ye)),6,MAGENTA,-1)     # 종점 원
    #------------------------------------------------------------
    xs = xs-(width/2); xe = xe-(width/2)   # 스크린 중앙을 0 으로 변경
    #-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
    # 차선에 의하여 만들어진 가이드 라인을 기준으로 모터 동작 결정 
    if (((xe<GBAR_VL) and (xs<GBAR_VL)) or \
        ((xe<GBAR_VL) and (xs>GBAR_VR))):
        frame[90:210,20:30]=YELLOW            # 좌회전 표시
        autoMotorRun(-SPEED_AT/2,SPEED_AT)
    elif (((xe>GBAR_VR) and (xs>GBAR_VR)) or \
          ((xe>GBAR_VR) and (xs<GBAR_VL))):  
        frame[90:210,610:620]=YELLOW          # 우회전 표시 
        autoMotorRun(SPEED_AT,-SPEED_AT/2)
    else:
        autoMotorRun(SPEED_AF,SPEED_AF)       # 직진 
    #-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
    ctrdict.clear()
    cv.line(frame,(CONT_LR,CONT_U),(width-CONT_LR,CONT_U),(WHITE),1)
    cv.line(frame,(CONT_LR,height-CONT_D),(width-CONT_LR,height-CONT_D),(WHITE),1)
    if ctrSetMode:
        cntareaBW = thresh[CONT_U+10:CONT_U+10+140, 80:560]  # 140:380,80:560
        cntareaBW = cv.cvtColor(cntareaBW,cv.COLOR_GRAY2BGR)
        cntareaCOLOR = frame[CONT_U+10:CONT_U+10+140, 80:560]  # 140:380,80:560
        cntMerged = np.vstack((cntareaBW,cntareaCOLOR))
        cv.putText(cntMerged," B:"+str(threshLevel)+"  K:"+str(kSize)+
                             "  L:"+str(contArea)+"  P:"+str(aspRatio),
                             (90,20),cv.FONT_HERSHEY_COMPLEX_SMALL,1,BLUE)
        cv.imshow("CONTOUR Config.", cntMerged)
    else:
        cv.line(frame,(int(width/2+GBAR_VL),CONT_U),
                (int(width/2+GBAR_VL),height-CONT_D),(YELLOW),1)
        cv.line(frame,(int(width/2+GBAR_VR),CONT_U),
                (int(width/2+GBAR_VR),height-CONT_D),(YELLOW),1)
        merged = np.hstack((img,frame))
        merged = cv.pyrDown(merged)
        cv.imshow(title,merged)
    #------------------------------------------------------------
    keyBoard = cv.waitKey(1) & 0xFF ##    print(hex(keyBoard)) # 키보드의 키 값 확인  
    if keyBoard == 0x1B or keyBoard == 0x09:    # ESC/TAB 프로그램 종료
        break
    elif keyBoard == 0x63 or keyBoard == 0x43:  # "c" or "C" 컨투어 설정 모드 
        if ctrSetMode:
            ctrSetMode = False
            cv.destroyWindow("CONTOUR Config.")
        else:
            ctrSetMode = True 
    elif keyBoard == 0x62:         # "b" 차선 화이트/블랙 스레쉬 레벨 
        if threshLevel > 5:
            threshLevel -= 2
    elif keyBoard == 0x42:         # "B"
        if threshLevel < 250:
            threshLevel += 2
    elif keyBoard == 0x6B:         # "k" K Size
        if kSize > 1:
            kSize -= 1
    elif keyBoard == 0x4B:         # "K"
        if kSize < 10:
            kSize += 1
    elif keyBoard == 0x6C:         # "l" 컨투어 길이/면적
        if contArea > 5:
            contArea -= 2
    elif keyBoard == 0x4C:         # "L"
        if contArea < 250:
            contArea += 2
    elif keyBoard == 0x70:         # "p" 컨투어 가로 세로 비율 
        if aspRatio > 0.0:
            aspRatio -= 0.5
    elif keyBoard == 0x50:         # "P"
        if aspRatio < 10.0:
            aspRatio += 0.5
    elif keyBoard == 0x76 or keyBoard == 0x56:  # "v" or "V" 신호등 설정 모드
        trafSigSet()
    elif keyBoard == 0x61 or keyBoard == 0x41:  # "a" or "A" 자율 주행 모드 
        autoRunF = True
        trafficLight = True
        cv.circle(img,(25,156),6,(RED),-1)
    elif keyBoard == 0x20 or keyBoard == 0x0D:  # Space/Enter 차량 정지 
        autoRunF = False
        trafficLight = True
        cv.circle(img,(25,156),12,(0x7F,0xFF,0),-1)  # Auto Run
        motorRun(0,0)
        servoT = (SERVO_MIN+SERVO_MAX)/2.0
        servoP = (SERVO_MIN+SERVO_MAX)/2.0
        servoControl()
    elif keyBoard == 0x52:  # Up (R) Key
        print("Up")
        motorRun(SPEED_MF,SPEED_MF)
        servoControl()
    elif keyBoard == 0x54:  # Down (T) Key
        print("Down")
        motorRun(-SPEED_MB,-SPEED_MB)
        servoControl()
    elif keyBoard == 0x51:  # Left  Key (Q)
        motorRun(-SPEED_MF,SPEED_MT)
        servoControl()
    elif keyBoard == 0x53:  # Right Key (S)
        motorRun(SPEED_MF,-SPEED_MT)
        servoControl()
loopTime = (enew-eold)/cv.getTickFrequency() # 메인 프로그램 1 프레임 동작 시간 계산 
print(loopTime, 1/loopTime)
MOTOR_L.stop()                              # 왼쪽 모터 PWM(펄스 폭 변조) 정지
MOTOR_R.stop()                              # 오른쪽 모터 PWM(펄스 폭 변조) 정지
GPIO.cleanup()                              # GPIO 초기화
cam.release()                               # 카메라 자원을 반납
cv.destroyAllWindows()                      # 열려 있는 모든 윈도우를 닫기
#################################################################
#################################################################
#################################################################
