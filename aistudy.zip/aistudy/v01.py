# OpenCV - Camera Test                    <v01.py>

import cv2

cap = cv2.VideoCapture(0,cv2.CAP_V4L)     # 카메라 객체 생성
cap.set(cv2.CAP_PROP_FRAME_WIDTH,640)     # 영상 가로 픽셀 수  320, 800, 1280
cap.set(cv2.CAP_PROP_FRAME_HEIGHT,480)    # 영상 세로 픽셀 수  240, 600, 1024
fps = int(cap.get(cv2.CAP_PROP_FPS))      # 1 초당 가져올 수 있는 영상 개수

print(f'1 초에 {fps} 장의 이미지를 표시합니다.')

while cap.isOpened():                     # 카메라 객체가 열려 있으면 무한 반복 실행

    ret, image = cap.read()               # 카메라 객체(cap)로 부터 1 개 이미지를 가져온다 
    cv2.imshow('Press any key to Exit', image)   # 이미지 표시창 열고 영상 표시
    if cv2.waitKey(1) > 0:                # 1 milli Sec 대기하고 Key 값 가져옴
        break                             # 어떤 키라도 눌러져 있으면 종료

cv2.destroyAllWindows()                   # 열려 있는 모든 창 닫기
##########################################################################

