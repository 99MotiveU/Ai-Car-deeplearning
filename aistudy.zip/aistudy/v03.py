#### create canvas                         <v03.py>

import cv2 as cv
import numpy as np

height, width = 60, 240

# 1층의 레이어(Black/White)를 만들고 1 개 색상 값을 지정하여 흑백 이미지 생성
imga = np.full((height, width, 1), 128, np.uint8)         # B/W: Gray
# 3층의 레이어(Color)를 만들고 3개 색상 값(Blue, Green, Red)을 지정하여 컬러 이미지 생성
imgb = np.full((height, width, 3), (0,0,255), np.uint8)   # Color: Red
# 3 개 층의 레이어(Color)를 만들고 0,0,0 을 채워 넣는다.
imgc = np.zeros((height, width, 3), np.uint8)             # Color: Black
# 3 개 층의 레이어(Color)를 만들고 초기화하지 않는다.
imgd = np.empty((height,width,3), np.uint8)               # Un initialized
# 3 개 층의 레이어(Color)를 만들고 Random 값의 색상을 만든다.
a = np.random.rand(height,width,3) # Color Random
b = a * 255                        # 0~0.999 to 0~255
imge = b.astype(np.uint8)          # Change Data Type float -> uint8

cv.imshow('A(Gray)', imga)
cv.imshow('B(Red)', imgb)
cv.imshow('C(Zero)', imgc)
cv.imshow('D(UnInit)', imgd)
cv.imshow('E(Random)', imge)

cv.waitKey(0)                    # 어떤 키든 눌러질 때까지 대기
cv.destroyAllWindows()
##########################################################################
