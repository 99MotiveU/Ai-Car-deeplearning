# Image Copy                                   <v04.py>

import numpy as np
import cv2 as cv

image = np.zeros((480,600,3), np.uint8) # Height(Y)-480, Width(X)-600 세로, 가로

#image[:230] = 255,0,0                  # Y 시점 생략, X 시점 생략, X 종점 생략 
#image[0:230] = 255,0,0                 # X 시점 생략, X 종점 생략
#image[0:230,:] = 255,0,0               # X 시점 생략, X 종점 생략 
#image[:230,:600] = 255,0,0             # Y 시점 생략, X 시점 생략
#image[0:230,:600] = 255,0,0            # Y 시점 생략 
image[0:230,0:600] = 255,0,0            # 전부 지정

#image[:,400:600] = 0,255,0             # Y 시점 생략, Y종점 생략 
#image[:480,400:600] = 0,255,0          # Y 시점 생략 
image[0:480,400:600] = 0,255,0          # 전부 지정 

cv.imshow('Press [SPACE] Key',image)
cv.waitKey(0)

logo = cv.imread('jac.jpg',cv.IMREAD_COLOR)
y,x,c = logo.shape                      # 이미지의 Y크기, 크기, 컬러층수
print('Y:',y,'X:',x,'C:',c)

image[7:7+y, 230:230+x] = logo          # 이미지 디스플레이

cv.imshow('Press [SPACE] Key',image)
cv.waitKey(0)

image[240:240+70,50:50+190] = image[30:30+70,210:210+190]
cv.imshow('Press [SPACE] Key',image)              # 이미지 부분 복사
cv.waitKey(0)
cv.destroyAllWindows()
##########################################################################
