# Line, Arrow Line, Circle, Rectangle             <v05.py>

import numpy as np
import cv2 as cv

# Create a black image
img = np.zeros((350,640,3), np.uint8)          # 세로, 가로 순으로 크기지정

# Draw a diagonal blue line with thickness of 3 px
cv.line(img,(10,90),(200,180),(0,255,0),1)     # 직선, 선두께 1
cv.line(img,(90,50),(200,200),(255,0,0),5)     # 직선, 선두께 5

cv.arrowedLine(img,(300,120),(520,250),(0,255,255),thickness=1, tipLength=0.2)
cv.arrowedLine(img,(550,120),(280,220),(255,255,255),thickness=2, tipLength=0.1)

cv.circle(img,(227,80), 63, (0,255,255))       # 원
cv.circle(img,(300,120), 63, (255,255,0),9)    # 원 폭 9
cv.circle(img,(447,80), 63, (0,0,255), -1)     # 채워진 원

cv.rectangle(img,(23,200),(94,333),(255,255,255))       # 사각형
cv.rectangle(img,(333,222),(400,320),(255,255,255),5)   # 사각형 선두께 5
cv.rectangle(img,(123,252),(300,333),(127,127,127),-1)  # 채워진 사각형
cv.rectangle(img,(0,0),(639,349),(255,0,255),1)         # 윈도우 크기 사각형

cv.imshow('Press Any Key to Exit',img)
cv.waitKey(0)                                  # 어떤 키이던지 눌러질 때까지 대기
cv.destroyAllWindows()
##########################################################################
