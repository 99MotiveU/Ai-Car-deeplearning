# Ellipse                                     <v06.py>
#
import numpy as np
import cv2
#--------------------------------------------------------------------------------------------
RED     =   0,  0,255                 # Red
GREEN   =   0,255,  0                 # Green
BLUE    = 255,  0,  0                 # Blue
MAGENTA = 255,  0,255                 # Magenta(Pink)
CYAN    = 255,255,  0                 # CYAN(Sky Blue)
YELLOW  =   0,255,255                 # Yellow
WHITE   = 255,255,255                 # White
BLACK   =   0,  0,  0                 # Black
GRAY    =  86, 86, 86                 # Gray
#--------------------------------------------------------------------------------------------
img = np.zeros((400,640,3), np.uint8)          # 세로, 가로 순으로 크기지정
font = cv2.FONT_HERSHEY_COMPLEX_SMALL

# 각도는 360 분법을 사용합니다.
#cv2.ellipse(이미지,(X좌표,Y좌표),(X방향길이,Y방향길이),타원 기울어짐 각도,시작각도,종점각도,(색상),선두께,선 타입)
def screen():
    img[:,:] = 100,35,35
    cv2.putText(img,'0/360',(560,200), font, 1,WHITE,1,cv2.LINE_AA)
    cv2.putText(img,'180',(10,200), font, 1,WHITE,1,cv2.LINE_AA)
    cv2.putText(img,'90',(300,380), font, 1,WHITE,1,cv2.LINE_AA)
    cv2.putText(img,'270',(300,50), font, 1,WHITE,1,cv2.LINE_AA)

screen()
cv2.ellipse(img,(320,200),(150,150),0,0,360,GREEN,1,cv2.LINE_AA)
text = 'cv2.ellipse(img,(300,200),(150,150), 0 , 0 , 360 ,GREEN,1,cv2.LINE_AA)'
cv2.putText(img,text,(10,20), font, 0.7,WHITE,1,cv2.LINE_AA)
cv2.imshow('Ellipse - Press Any Key',img); cv2.waitKey(0)  

screen()
cv2.ellipse(img,(320,200),(160,160),0,0,150,MAGENTA,1,cv2.LINE_AA)
text = 'cv2.ellipse(img,(300,200),(160,160), 0 , 0 , 150 ,MAGENTA,1,cv2.LINE_AA)'
cv2.putText(img,text,(10,20), font, 0.7,WHITE,1,cv2.LINE_AA)
cv2.imshow('Ellipse - Press Any Key',img); cv2.waitKey(0)     

screen()
cv2.ellipse(img,(320,200),(240,170),0,110,340,CYAN,1,cv2.LINE_AA)
text = 'cv2.ellipse(img,(300,200),(240,170), 0 , 110 , 340 ,CYAN,1,cv2.LINE_AA)'
cv2.putText(img,text,(10,20), font, 0.7,WHITE,1,cv2.LINE_AA)
cv2.imshow('Ellipse - Press Any Key',img); cv2.waitKey(0)

screen()
cv2.ellipse(img,(320,200),(260,160),40,80,310,RED,1,cv2.LINE_AA)     # 기울어진 타원 
text = 'cv2.ellipse(img,(300,200),(260,160), 40 , 80 , 310 ,RED,1,cv2.LINE_AA)'
cv2.putText(img,text,(10,20), font, 0.7,WHITE,1,cv2.LINE_AA)
cv2.imshow('Ellipse - Press Any Key',img); cv2.waitKey(0)

screen()
cv2.ellipse(img,(320,200),(200,140),0,0,270,YELLOW,-1,cv2.LINE_AA)   # 타원 내부 채우기
text = 'cv2.ellipse(img,(300,200),(200,150), 0 , 0 , 270 ,YELLOW,-1,cv2.LINE_AA)'
cv2.putText(img,text,(10,20), font, 0.7,WHITE,1,cv2.LINE_AA)
cv2.imshow('Ellipse - Press Any Key',img); cv2.waitKey(0)     

cv2.destroyAllWindows()
##########################################################################
