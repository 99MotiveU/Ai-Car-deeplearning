# Mouse as a Paint-Brush                     <v09.py>

import numpy as np
import cv2

img = np.zeros((480,520,3), np.uint8)   # 빈 원도우 생성

# 마우스 이벤트가 발생 했을때 처리 되는 함수
def mouse_control(event,x,y,flags,param):

    if event == cv2.EVENT_LBUTTONDOWN:          # 마우스 왼쪽 버튼 다운
        cv2.circle(img,(x,y),50,(0,255,255),1)

    if event == cv2.EVENT_RBUTTONDOWN:          # 마우스 오른쪽 버튼 다운
        cv2.rectangle(img,(x-25,y-25),(x+25,y+25),(255,0,255),1)

    if event == cv2.EVENT_MBUTTONDOWN:          # 마우스 가운데 버튼 다운
        cv2.circle(img,(x,y),20,(255,255,0),-1)

    if event == cv2.EVENT_MOUSEMOVE:            # 마우스 이동 감지
        print(x, y)

cv2.namedWindow('MOUSE')                    # 마우스가 커서가 동작하는 윈도우 지정
cv2.setMouseCallback('MOUSE',mouse_control) # 윈도우 image와 처리함수 mouse_control

#------------------------------------------------------------------
while(1):

    cv2.imshow('MOUSE',img)             # MOUSE 윈도우 표시
    k = cv2.waitKey(1) & 0xFF 
    if k == 27 or k == ord(' '):        # ESC or [SPACE]를 누르면 실행 종료
        break

cv2.destroyAllWindows()
##########################################################################
