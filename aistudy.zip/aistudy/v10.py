# Full Screen        <v10.py>
# 화면 전체 사용하기 No Title Bar, no Menu Bar
#
import cv2
import numpy as np

cap = cv2.VideoCapture(0,cv2.CAP_V4L)

cap.set(3,800)     # LCD 가로 방향 800
cap.set(4,640)     # LCD 세로 방향 480

#-------------------------------------------------------------------------
cv2.namedWindow('LCD',cv2.WND_PROP_FULLSCREEN)
cv2.setWindowProperty('LCD', cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
#-------------------------------------------------------------------------
while True:
    _, frame = cap.read()

    '''
    여기에 프로그램을 코딩합니다.
    '''
    cv2.imshow('LCD',frame)
    keyBoard = cv2.waitKey(1)
    if keyBoard == ord(' ') or keyBoard == 27: break
    
cv2.destroyAllWindows()                   # 열려 있는 모든 창 닫기

##########################################################################
