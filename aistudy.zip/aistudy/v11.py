# Adding Text to Images:                           <v11.py>
#

import numpy as np
import cv2

# Create a black image
img = np.zeros((480,900,3), np.uint8)  # Height, Width

text = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
size = 1.5

font = cv2.FONT_HERSHEY_SIMPLEX
cv2.putText(img,text,(10,50), font, size,(255,255,255),1,cv2.LINE_AA)
font = cv2.FONT_HERSHEY_PLAIN
cv2.putText(img,text,(10,100), font, size,(255,255,255),1,cv2.LINE_AA)
font = cv2.FONT_HERSHEY_DUPLEX
cv2.putText(img,text,(10,150), font, size,(255,255,255),1,cv2.LINE_AA)
font = cv2.FONT_HERSHEY_COMPLEX
cv2.putText(img,text,(10,200), font, size,(255,255,255),1,cv2.LINE_AA)
font = cv2.FONT_HERSHEY_TRIPLEX
cv2.putText(img,text,(10,250), font, size,(255,255,255),1,cv2.LINE_AA)
font = cv2.FONT_HERSHEY_COMPLEX_SMALL
cv2.putText(img,text,(10,300), font, size,(255,255,255),1,cv2.LINE_AA)
font = cv2.FONT_HERSHEY_SCRIPT_SIMPLEX
cv2.putText(img,text,(10,350), font, size,(255,255,255),1,cv2.LINE_AA)
font = cv2.FONT_HERSHEY_SCRIPT_COMPLEX
cv2.putText(img,text,(10,400), font, size,(255,255,255),1,cv2.LINE_AA)
font = cv2.FONT_ITALIC
cv2.putText(img,text,(10,450), font, size,(255,255,255),1,cv2.LINE_AA)

cv2.imshow('Press Any Key to EXIT',img)
cv2.waitKey(0)
cv2.destroyAllWindows()
##########################################################################
