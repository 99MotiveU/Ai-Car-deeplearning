##### Hough Circle Transform                    <v12.py>
# 원(Circle) 인식
#
import cv2                                      # 영상처리 라이브러리 OpenCV
import numpy as np                              # 행열 처리 라이브러리

cam = cv2.VideoCapture(0,cv2.CAP_V4L)           # 카메라 객체 생성

while True:
    ret, src = cam.read()                       # 카메라에서 영상을 가져온다

    gray = cv2.cvtColor(src, cv2.COLOR_BGR2GRAY)  # 컬러 영상을 흑백 영상으로 변환한다.
    gray = cv2.medianBlur(gray, 5)                # 블러 필터처리
    circles = cv2.HoughCircles(
                 gray,               # 원 검출 대상 흑백 이미지
                 method=cv2.HOUGH_GRADIENT,  # 휴-그라디언드 법으로 원 검출
                 dp=1,               # The inverse ratio of resolution.
                 minDist=60,         # 여러개의 원이 검출되었을 때 원과 원의 최소 거리 
                 param1=100,         # Upper threshold for Canny edge detector.
                 param2=30,          # Threshold for center detection.
                 minRadius=10,       # 원의 최소 지름
                 maxRadius=90        # 원의 최대 지름
                 )
    if circles is not None:          # 원이 검출됨
        circles = np.uint16(np.around(circles))
        print(circles)
        for i in circles[0,:]:       # 검출된 여러개의 원 객체
            print(i)
            center = (i[0], i[1]); radius = i[2]
            cv2.circle(src,center,radius,(128,128,128),3)  # 원의 외곽선
            cv2.circle(src,center,5,(0, 255, 0),-1)        # 원의 중심점을 표시
    cv2.imshow("Hough Circle Transform - Press ESC or [SPACE] to EXIT", src)  # 결과 이미지 표시
    
    k = cv2.waitKey(1)
    if k == 27 or k == ord(' '):      #  ESC 키 또는 [SPACE]가 입력되면 프로그램 종료
        break
cv2.destroyAllWindows()               # 열려있는 모든 창을 닫는다.
cam.release()
##########################################################################
