# and gate
# 퍼셉트론 AND Gate
def and_gate(x1, x2):
    # 입력값 x1에 대한 가중치 w1, x2에 대한 가중치 w2
    w1, w2 = 0.6, 0.6

    # bias 편향값
    b = -0.7

    # 연산 결과
    s = x1*w1 + x2*w2 + b

    # 결과가 0보다 작거나 같으면 0, 0보다 크면 1을 반환합니다.
    #return 0 if result <= 0 else 1
    if s>0:
        r = 1
    else:
        r = 0
    return r, s
    
    
# 입력값 목록을 튜플 리스트로 만듭니다.
input_list = [(0, 0), (0, 1), (1, 0), (1, 1)]


# 반복문을 순회하면서 입력값을 가져옵니다.
print("퍼셉트론 AND Gate")
for x1, x2 in input_list:
    # and gate의 결과를 저장하고
    r, s = and_gate(x1, x2)

    # 출력합니다.
    print(f"입력값: {x1} {x2} - 결과: {r} {s}")
    
