####  Least Square fit Line                   <LSF_RLineJ.py>
#
# 직선의 기울기와 절편을 계산합니다.
#
import numpy as np
import cv2 as cv
#----------------------------------------------------------
RED     =   0,  0,255     # Red
GREEN   =   0,255,  0     # Green
BLUE    = 255,  0,  0     # Blue
PINK    = 255,  0,255     # Pink
MAGENTA = 255,255,  0     # Magenta(Sky Blue)
YELLOW  =   0,255,255     # Yellow
WHITE   = 255,255,255     # White
BLACK   =   0,  0,  0     # Black
GRAY    =  86, 86, 86     # Gray

WINDOW_SIZE_X = 600
WINDOW_SIZE_Y = 400

angle = 0.0
bias = 0.0
count = 0
cMax = 200
newAreaP = 0.0                   # Positive Step Square Area
newAreaN = 0.0                   # Negative Step Square Area
step = 0.01                     # Learn Rate

Xt = []   # Data Set Y
Yt = []   # Data Set Y

#----------------------------------------------------------
img = np.zeros((WINDOW_SIZE_Y,WINDOW_SIZE_X,3), np.uint8)     # 빈 원도우 생성

#----------------------------------------------------------
cv.line(img,(0,int(WINDOW_SIZE_Y/2)),(WINDOW_SIZE_X-1,int(WINDOW_SIZE_Y/2)),GRAY,1)
cv.line(img,(int(WINDOW_SIZE_X/2),0),(int(WINDOW_SIZE_X/2),WINDOW_SIZE_Y-1),GRAY,1)

#----------------------------------------------------------
# 마우스 이벤트가 발생 했을때 처리 되는 함수
def mouse_control(event,x,y,flags,param):
    global dataX, dataY

    if event == cv.EVENT_LBUTTONDOWN:      # 마우스 왼쪽 버튼 다운
        cv.circle(img,(x,y),5,PINK,1)      # 입력한 점좌표 표시
        Xt.append(x-int(WINDOW_SIZE_X/2))
        Yt.append(int(WINDOW_SIZE_Y/2)-y)
#----------------------------------------------------------
def drawLine(x1, y1, x2, y2, c):
    cv.line(img,(x1+int(WINDOW_SIZE_X/2),int(WINDOW_SIZE_Y/2)-y1),(x2+int(WINDOW_SIZE_X/2),int(WINDOW_SIZE_Y/2)-y2),c,1)

#----------------------------------------------------------
def meanSquare(x, y, w, b):
    ms = 0.0
    for i in range(0, len(x)):
        ms += abs(y[i]-(w*x[i]+b))
    ms = ms/len(x)

    v = 0.0
    for i in range(0, len(x)):
        v += abs(abs(y[i]-(w*x[i]+b)) - ms)

    return v

#----------------------------------------------------------
def diffSum(x, y, w, b):
    '''
    데이터 셋으로 구성된 직선의 X의 Y 값에서
    주어진 기울기 w 와 절편 b 로 이루어진 직선의
    X의 y을 뺀 모든 값을 합산한다. 
    
    '''
    d = 0.0
    for i in range(0, len(x)):
        d += y[i]-(w*x[i]+b)
    return d
#----------------------------------------------------------
cv.namedWindow('Line')                     # 마우스가 커서가 동작하는 윈도우 지정
cv.setMouseCallback('Line',mouse_control)  # 윈도우 image와 처리함수 mouse_control

#----------------------------------------------------------
while(True):
    cv.imshow('Line',img)                  # 윈도우 표시
    if cv.waitKey(1) == ord(' '):          # Press Any Key
        break

#==========================================================
bias = min(Yt)-abs(min(Yt))-abs(max(Yt))-abs(min(Xt))-abs(max(Xt))
count = 0

#----------------------------------------------------------
while True:
    '''
    데이터 셋을 대표할수 있는 직선의 기울기를 구합니다.
    '''
    newAreaP = meanSquare(Xt, Yt, angle+step, bias)
    newAreaN = meanSquare(Xt, Yt, angle-step, bias)
    
    print('C:', count, 'A:', angle, ':', 'aP',newAreaP, 'aN', newAreaN)

    if newAreaP > newAreaN:
        angle -= step
    elif newAreaP < newAreaN:
        angle += step
    else:
        break
        
    count += 1

    if count > cMax:
        break
#----------------------------------------------------------
count = 0
bias = min(Yt)         # 데이터 셋 중에서 가장 작은 Y 값을 절편의 초기 값으로 지정합니다.
bStep = 0.1            # 절편 조정(update) 값

while True:

    v = diffSum(Xt, Yt, angle, bias)
    print(f'C:{count:4d} B={bias:4.2f} V={v:4.5f}')
    count += 1

    if  v > 0:                             # 차이 값을 모두 합산하여 
        bias += bStep                      # - 값이면 bias(절편) 조정(update)을 멈춥니다.
    else:
        break

#----------------------------------------------------------
X1 = -1*int(WINDOW_SIZE_X / 2); Y1 = int(angle*X1)
X2 = int(WINDOW_SIZE_X / 2); Y2 = int(angle*X2)
drawLine(X1, Y1, X2, Y2, YELLOW)           # 절편을 0 으로 하여 노란색 선으로 직선을 그립니다.

X1 = -1*int(WINDOW_SIZE_X / 2); Y1 = int(angle*X1+bias)
X2 = int(WINDOW_SIZE_X / 2); Y2 = int(angle*X2+bias)
drawLine(X1, Y1, X2, Y2, GREEN)            # 절편을 반영하여 녹색(Green) 선으로 직선을 그립니다.

cv.imshow('Line',img)                      # 윈도우 표시 
cv.waitKey(0)                              # 아무 키나 누르면 시스템으로 돌아 갑니다.
cv.destroyAllWindows()

print()
print('Angle=', angle)
print('Bias=', bias)
print('X:',Xt)                   # Print X Data Set 
print('Y:',Yt)                   # Print Y Data Set

###########################################################
###########################################################
###########################################################
###########################################################
###########################################################
