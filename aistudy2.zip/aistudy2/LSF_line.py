####  Least Square Fit Line                   <LSF_line.py>
#
# 최소 자승법에 의한 직선의 기울기와 절편을 계산합니다.
# 1. 마우스로 2 개 이상의 위치를 지정 하세요
# 2. [SPACE] 를 누르세요.
# 3. 아무키나 누르면 종료합니다.

import numpy as np
import cv2

from scipy import optimize

img = np.zeros((400,700,3), np.uint8)     # 빈 원도우 생성

COLOR_MIN = (0, 255, 0)
COLOR_RST = (0, 0, 255)

#----------------------------------------------------------
dataX = []
dataY = []

# 마우스 이벤트가 발생 했을때 처리 되는 함수
def mouse_control(event,x,y,flags,param):
    global dataX, dataY

    if event == cv2.EVENT_LBUTTONDOWN:      # 마우스 왼쪽 버튼 다운
        cv2.circle(img,(x,y),5,COLOR_MIN,1,cv2.LINE_AA) # 입력한 점좌표 표시
        dataX.append(x)
        dataY.append(y)

#----------------------------------------------------------
cv2.namedWindow('Line')                     # 마우스가 커서가 동작하는 윈도우 지정
cv2.setMouseCallback('Line',mouse_control)  # 윈도우 image와 처리함수 mouse_control

while(True):

    cv2.imshow('Line',img)                  # 윈도우 표시

    if cv2.waitKey(1) == ord(' '):          # ESC 키를 누르면 실행 종료
        break

#----------------------------------------------------------
x = np.array(dataX)
y = np.array(dataY)

A = np.vstack([x, np.ones(len(x))]).T

m, c = np.linalg.lstsq(A, y, rcond=None)[0]

X1 = 0
Y1 = int(m*X1 + c)

X2 = 699
Y2 = int(m*X2 + c)

cv2.line(img,(X1,Y1),(X2,Y2),COLOR_RST,1,cv2.LINE_AA)
cv2.imshow('Line',img)                      # 윈도우 표시 

cv2.waitKey(0)

cv2.destroyAllWindows()

#----------------------------------------------------------

