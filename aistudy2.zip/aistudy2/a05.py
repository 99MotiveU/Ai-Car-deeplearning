# List  3                                               <a05.py> 
# 
#
# 2 차원 배열 리스트 ---------------------------------------------------------------------
#     이름    성적    
v = [['홍길동',73], 
     ['마영달',96],
     ['땡칠이',34],
     ['김지영',65],
     ['배영만',54]]

print("<13> 2 차원 배열 리스트 만들기")
print(v)
print()
# 13. 2 차원 배열 리스트 에서 요소 가져오기 ------------------------------------------------------
b = v[2][1]                   # 땡칠이의 점수를 가져 옵니다.
print("<14> 2 차원 배열 리스트 에서 요소 가져오기: b = v[2][1]")
print(v)
print(b)
print()
# 14. 2 차원 배열 리스트에서 순서 정열 하기 ------------------------------------------------------
from operator import itemgetter
s = sorted(v,key=itemgetter(1), reverse=True)  # reverse = True 지정하면 오름 차순(큰 수 부터)
print("<15> 2 차원 배열 리스트에서 순서 정열 하기: s = sorted(v,key=itemgetter(1), reverse=True)")  #    
print(v)
print(s)
print()
# 15. 최고점자 이름 및 성적
p = s[0]              
print("<16>최고점자 이름 및 성적: p = s[0]")            # 
print(s)
print(p)
print()

# 16. 성적 최하위자 점수 가져오기
print("<17> 성적 최하위자 점수 가져오기: p = s[-1][1]")
p = s[-1][1]                               # 성적 최하위자의 순서를 모르므로 -1 인덱스 번호 지정
print(s)
print(p)
print()

# 17. 이름 가나다 순서 배열
s = sorted(v,key=itemgetter(0), reverse=False)  # reverse = True 지정하면 오름 차순(큰 수 부터)
print("<18> 이름 가나다 순서 배열: s = sorted(v,key=itemgetter(0), reverse=False)") 
print(v)
print(s)

#############################################################################################
