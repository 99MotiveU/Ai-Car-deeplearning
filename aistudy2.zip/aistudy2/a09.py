# 딕셔너리 데이터의 소팅(순서 정열)                          <a09.py>
#
# 딕셔너리 데이터는 키(key) 값, 요소(item) 값이 성격이 다른 객체가 사용 가능하므로
# 딕셔너리의 소팅(순서 정열)은 의미가 없습니다. 
# item 이 소팅이 가능한 데이터이면 item 기준으로 소팅 가능합니다.  
# item 기준으로 소팅하면 키와 요소는 튜플데이터로 묶여 리스트 데이터로 만들어집니다.  
# 키 값으로 소팅하면 소팅된 키 값 리스트를 만들 수 있습니다.
#
print("딕셔너리 데이터 생성")
a = {'A': 3.14, 'B': 2.1, 'C': 0.3, 'D': 7.8}
print(a)
print()

print("value를 기준으로 정렬 reverse=False: 오름차순, reverse=True: 내림차순")
sorted_dict = sorted(a.items(), key=lambda x: x[1], reverse=True)
print(sorted_dict)
print("소팅된 첫번째 키의 항목: sorted_dict[0][1]")
print(sorted_dict[0][1])
print()

print("키 값만 소팅하여 리스트 생성: sorted(a.keys(), reverse=True)")
sorted_dict = sorted(a.keys(), reverse=True)
print(sorted_dict)
print()

print("첫 번째 key 가져오기: sorted_dict[0][0]")
first_key = sorted_dict[0][0]
print(first_key)
print()

print("첫 번째 key의 요소(item) 가져오기: a[first_key]")
t = a[first_key]
print(t)

#############################################################################################
