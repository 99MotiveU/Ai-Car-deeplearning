# 파이썬 기본 : pickle 데이터 저장                      <a15.py>
#
# pickle 라이브러리는 파이썬에서 다루는 객체를 그대로 저장/복원이 가능합니다.
# FIFO (First In First Out) 로 동작합니다.
#
import pickle                   # python 객채 압축/복원 라이브러리 pickle

radius = 100                    # 정수 100 객체 생성
myName = "자율주행"              # 문자열 객체 생성
state  = True                   # Bool 객체

w = [radius, myName, state]     # 저장할 데이터를 리스트 데이터로 만듭니다.
c = (255, 0, 255)               # PINK 색상 튜플 데이터
p = 3.141592                    # 소수점 수 

fileName = 'data.pickle'
with open(fileName, 'wb') as f:
    pickle.dump(w, f)           # [1] 리스트    - 첫번째 쓰기
    pickle.dump(c, f)           # [2] 튜플      - 두번째 쓰기
    pickle.dump(p, f)           # [3] 소수점 수  - 세번째 쓰기
    print('pickle 파일을 저장 했습니다.')
#############################################################################################
