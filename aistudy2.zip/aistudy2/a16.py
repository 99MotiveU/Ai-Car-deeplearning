# 파이썬 기본 8: pickle 데이터 읽기                    <a16.py>
# pickle 은 python 에서 정의되는 객체를 저장하고 복원합니다.
#
# pickle 라이브러리는 파이썬에서 다루는 객체를 그대로 저장/복원이 가능합니다.
# FIFO (First In First Out) 로 동작합니다.

import pickle                    # python 객채 압축/복원 라이브러리 pickle

t = 'data.pickle'                # 가져올 pickle 파일 이름

with open(t, 'rb') as f:
    d = pickle.load(f)            # [1] pickle 저장 시 첫번째 데이터
    a = d[0]; b = d[1]; c = d[2]  # 리스트형 데이터
    print(a, b, c)                

    a, b, c = pickle.load(f)      # [2] pickle 저장 시 두번째 데이터
    print(a, b, c)                # 튜플형 데이터

    v = pickle.load(f)            # [3] pickle 저장 시 세번째 데이터
    print(v)                      # 소수점 수

#############################################################################################
