import matplotlib.pyplot as plt
import matplotlib.patches as patches

class Point:
    # 인스턴스 생성시에 두개의 인수 x와 y를 가짐
    def __init__(self, x, y):
        # 인스턴스 속성 x 에 첫 번째 인수를 할당
        self.x = x
        # 인스턴스 속성 y 에 두 번째 인수를 할당
        self.y = y

    def draw(self):
        # (x, y)에 점을 그림
        plt.plot(self.x, self.y, marker='o', markersize=10, c='k')

p1 = Point(2, 3)
p2 = Point(-1, -2)

'''
p1.draw()
p2.draw()
plt.xlim(-4, 4)
plt.ylim(-4, 4)
plt.gca().set_aspect('equal', adjustable='box')
plt.show()
'''


# Point 의 자식 클래스 Circle 정의 1
class Circle(Point):
    # Circle은 인스턴스 생성시에 인수 x, y, r을 가짐
    def __init__(self, x, y, r):
        # x 와 y 는 부모 클래스의 속성으로 설정
        super().__init__(x, y)
        # r 은 Circle의 속성으로 설정
        self.r = r

    def draw(self):
        # 원 그리기
        c = patches.Circle(xy=(self.x, self.y), radius=self.r, fc='b', ec = 'k')
        ax.add_patch(c)

c = Circle(1, 0, 2)

ax = plt.subplot()
p1.draw()
p2.draw()
c.draw()
plt.xlim(-4, 4)
plt.ylim(-4, 4)
plt.gca().set_aspect('equal', adjustable='box')
plt.show()
