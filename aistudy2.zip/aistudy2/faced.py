# Face Detection using Haar Cascades          <v02.py>
#
import cv2                        # OpenCV 라이브러리

#cap = cv2.VideoCapture(0,cv2.CAP_V4L); cap.set(3,640); cap.set(4,480)
cap = cv2.VideoCapture('wyw2.mp4')
#cap = cv2.VideoCapture('dugaja.mp4')

face_pattern = cv2.CascadeClassifier(
    '/home/pi/opencv/data/haarcascades/haarcascade_frontalface_default.xml')

while True:
    ret, frame = cap.read()          # 카메라(or MP4)에서 1 개의 이미지 프레임
    if ret:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) # 컬러를 흑백으로 변환
        faceList = face_pattern.detectMultiScale(gray, # 흑백 이미지 소스
                      scaleFactor = 1.5, # 이미지 피라미드 스케일 factor
                      minNeighbors = 5,  # 인접 객체 최소 거리 픽셀
                      minSize=(20,20)    # 탐지 객체 최소 크기
                   )

        for (x,y,w,h) in faceList:       # 인식된 얼굴 위치에 사각형을 그림
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)

        cv2.imshow('Face Detect - Press ESC or [SPACE] to Exit',frame)

        k = cv2.waitKey(1) 
        if  k == 27 or k == ord(' '):
            break
    else:
        break
cap.release()                        # 객체(카메라) 자원 반납
cv2.destroyAllWindows()              # 열려 있는 모든 창 닫기
##########################################################################
