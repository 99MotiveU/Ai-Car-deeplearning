# NEOPIXEL 2                                                            <h04.py>
#
# NEOPIXEL을 사용하려면 관리자 모드로 프로그램 실행하여야 합니다. 
#
# sudo python h04.py
#
# 원을 768 등분(256 x 3)으로 정의 합니다.
#
G = 16      # 기준 값의 증분 값(큰 수로하면 회전 속도가 빠르게 됩니다.)
D = 64      # 네오픽쎌 간의 색상 각(작으면 픽쎌간 색상이 근접하게 됩니다.)
T = 0.1     # 초단위 점등 시간 간격(작게 하면 색상 변화 속도가 빠르게 됩니다.)

from time import sleep
import board
import neopixel

pixel_pin = board.D18                    # NeoPixel 이 연결된 핀 번호(Raspberry Pi GPIO#)
num_pixels = 8                           # NeoPixel 연결된 개수
ORDER = neopixel.RGB
pixels = neopixel.NeoPixel(
         pixel_pin, num_pixels, brightness=1, auto_write=False, pixel_order=ORDER)
#---------------------------------------------------------------------------------------------
def wheel(i):         # 크기에 관계없이 모든 양의 정수를 허용한다. 

    k=0; m=0; t=0;
    color_r = 0; color_g = 0; color_b = 0 

    i = i % 0x300       # 0x2FF  보다 큰 수가 올수도 있으므로 0 으로 조정
    k = i & 0x300       # 상위 2 비트만 관심 있으므로 하위 8 비트를 0 으로 한다.  (0x000~0x5FF)
    m = i & 0x0FF       # 하위 8 비트만 관심 있으므로 상위 2 비트를 0 으로 한다. (0x0~0xFF)

    if(k == 0x000):
        color_r = 0xFF-m        # Red Decrement
        color_g = m             # Green Increment
        color_b = 0x00          # Blue Off
                    
    if(k == 0x100):
        color_r = 0             # Red Off
        color_g = 0xFF-m        # Green Decrement
        color_b = m             # Blue Increment

    if(k == 0x200):
        color_r = m             # Red Increment
        color_g = 0             # Green Off
        color_b = 0xFF-m        # Blue Decrement
        
    return(color_r, color_g, color_b)
#--------------------------------------------------------------------------------------------
def rainbow(a, b):
    '''
    rainbow(step, length) 함수는 파노라마 색상 연출합니다.

    입력값  a: 기준 색상 각도
           b: Cell 간의 색상 각도
    '''
    pixels[0] = wheel(a+b*0)
    pixels[1] = wheel(a+b*1)
    pixels[2] = wheel(a+b*2)
    pixels[3] = wheel(a+b*3)
    pixels[4] = wheel(a+b*4)
    pixels[5] = wheel(a+b*5)
    pixels[6] = wheel(a+b*6)
    pixels[7] = wheel(a+b*7)

    pixels.show()
#=============================================================================================
print('Ctrl+C 를 입력하면 프로그램 실행 종료 합니다.')
i = 0
while True:
    rainbow(i, D)            # 기준 각과 픽쎌간 차이각
    sleep(T)                 # 시간 지연
    i += G                   # 기준 각 증분
    i %= 0x300               # 768 라운딩
##############################################################################################
