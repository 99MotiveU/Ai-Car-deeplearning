# HUE 원 만들기                                                              <hueCir.py>
# 알파채널이 포함되며 256 x 256  크기의  HUE 원을 만듭니다.
#
#                                                               
# Library Import ============================================================================
import numpy as np          # 이미지 배열 생성(OpenCV 에서 사용) 라이브러리
import cv2                  # 영상처리(OpenCV) 라이브러리 
from math import sin, cos, pi
#--------------------------------------------------------------------------------------------
HUE_CIR = np.zeros((256,256,4),np.uint8)  # HUE Circle 가로, 세로, 컬러층(알파층 포함), 8비트
#--------------------------------------------------------------------------------------------
def hsv_to_bgr(hue, saturation, value):
    hsv_color = np.uint8([[[hue, saturation, value]]])
    bgr_color = cv2.cvtColor(hsv_color, cv2.COLOR_HSV2BGR)
    blue, green, red = bgr_color[0][0]
    return blue, green, red
#--------------------------------------------------------------------------------------------
def hueCircle():                        # HUE 원을 만듭니다.
    yc = 128; xc = 128

    HUE_ANGLE = 0.0
    while HUE_ANGLE < 180:
        for i in range(256):
            B, G, R = hsv_to_bgr(HUE_ANGLE,i,255)
            y = -i*sin(2*HUE_ANGLE*pi/180.0); x = i*cos(2*HUE_ANGLE*pi/180.0)
            y = int(y/2); x = int(x/2)
            HUE_CIR[yc+y:yc+y+1,xc+x:xc+x+1] = B, G, R, 255
        HUE_ANGLE = HUE_ANGLE + 0.2
    #cv2.circle(HUE_CIR,(xc,yc),128,BLACK,1,cv2.LINE_AA)
    cv2.imwrite('hcir.png', HUE_CIR)               # 이미지를 저장
#--------------------------------------------------------------------------------------------
hueCircle()
#--------------------------------------------------------------------------------------------
