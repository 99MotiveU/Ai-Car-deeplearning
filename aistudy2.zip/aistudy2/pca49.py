#### Raspberry Pi CAR 자율주행 자동차:                             <pca49.py>
#
# 1. 카메라로 부터 1 개의 프레임 영상을 가져온다.
# 2. 컬러 영상을 흑백 영상으로 변환한다.
# 3. 흑백 영상을 반전(흑->백, 백->흑).
# 4. OTSU 스레쉬 영상처리로 그레이 영상을 2진 흑백 영상으로 변환한다.
# 5. Dilate 연산으로 노이즈 제거한다.
# 6. 컨투어를 찾아서 최소 면적 조건 보다 크고 최대 면적 보다 작은 컨투어 집합을 만든다.
# 7. 컨투어 면적 정보(차선의 외곽 둘레길이)만 가져와 크기 순으로 나열(소팅) 한다. 
#---------------------------------------------------------------------------
import cv2 as cv                      # Open CV 라이브러리 
import numpy as np                    # NumPy 라이브러리
import operator as op                 # operator 라이브러리
import math                           # Math 라이브러리
import RPi.GPIO as GPIO               # GPIO 라이브러리
#---------------------------------------------------------------------------
K_SIZE = 5                            # 컨투어 침식 연산에서 Kernel 크기 
minContArea = 500                     # 컨투어의 최소 면적
maxContArea = 99999                   # 컨투어의 최대 면적
ASPECT_RATIO = 2.0                    # 근접 사각형의 가로 세로 비율
AREA_RATIO = 0.15                     # 컨투어 면적과 근접 사각형 면적의 비율
#---------------------------------------------------------------------------
BLUE   = 255,0,0                      # 파란색
GREEN  = 0,255,0                      # 녹색
RED    = 0,0,255                      # 적색
YELLOW = 0,255,255                    # 노란색
PINK   = 255,0,255                    # 핑크색
CYAN   = 255,255,0                    # 하늘색
WHITE  = 255,255,255                  # 하얀색
#---------------------------------------------------------------------------
TWU   = 220                           # @ Track Window Upper Line
TWD   = 389                           # @ Track Window Down Line
TWL   = 1                             # @ Track Wondow Left Line
TWR   = 638                           # @ Track Window Right Line
FL2   = 220                           # @ Field Left Line 2
FL1   = 300                           # @ Field Left Line 1
FC0   = 320                           # @ Field Center Line 0
FR1   = 340                           # @ Field Right Line 1
FR2   = 420                           # @ Field Right Line 2
FD1   = 250                           # @ Field Under Line 1
FD2   = 300                           # @ Field Under Line 2
#---------------------------------------------------------------------------
threshLevel = 0                      # @ 차선(Black/White) 판단 레벨, 0 이면 OTSU
#---------------------------------------------------------------------------
red_AUH = 8                           # @ Red   HSV 각도: 최대 +30도   
red_ALH = -27                         # @ Red   HSV 각도: 최소 -30도
red_PUH = 8                           # @
red_PLH = 0                           # @
red_NUH = 179                         # @
red_NLH = 153                         # @
red_LS  = 50                          # @ 0 - 255
red_LV  = 50                          # @ 0 - 255
grn_AUH = 90                          # @ Green HSV 각도: 최대 +90도
grn_ALH = 47                          # @ Green HSV 각도: 최대 +30도
grn_LS  = 50                          # @ 0 - 255
grn_LV  = 50                          # @ 0 - 255
rTsH =  30                            # @ Red   신호등 판단 수평 H
rTsV = 200                            # @ Red   신호등 판단 수직 V
gTsH =  30                            # @ Green 신호등 판단 수평 H
gTsV = 200                            # @ Green 신호등 판단 수직 V
#---------------------------------------------------------------------------
TS_DIA_MIN  = 14                      # @ 신호등 검출 최소 반지름
TS_DIA_MAX  = 25                      # @ 신호등 검출 최대 반지름
trafficReset = 0                      # @ 적색 신호등 인식시 0 으로 리셋한다
#---------------------------------------------------------------------------
MOTOR_L_PWM = 12                      # GPIO.12    왼쪽 모터 펄스 폭 변조
MOTOR_L_DIR = 5                       # GPIO.5     원쪽 모터 방향
MOTOR_R_PWM = 13                      # GPIO.13    오른쪽 모터 펄스 폭 변조
MOTOR_R_DIR = 6                       # GPIO.6     오른쪽 모터 방향
SERVO_PAN   = 16                      # GPIO.16    카메라 서보 좌/우 
SERVO_TILT  = 19                      # GPIO.19    카메라 서보 상/하
# Set up -------------------------------------------------------------------
GPIO.setmode(GPIO.BCM)                # GPIO 핀 번호를 BCM 방식으로 설정 
GPIO.setwarnings(False)               # 경고 메시지 출력 안보기로 설정
GPIO.setup(MOTOR_L_PWM,GPIO.OUT)      #
GPIO.setup(MOTOR_L_DIR,GPIO.OUT)      #
GPIO.setup(MOTOR_R_PWM,GPIO.OUT)      #
GPIO.setup(MOTOR_R_DIR,GPIO.OUT)      #
GPIO.setup(SERVO_PAN,GPIO.OUT)        #
GPIO.setup(SERVO_TILT,GPIO.OUT)       #
MOTOR_L = GPIO.PWM(MOTOR_L_PWM,500)   # PWM 주파수 500Hz
MOTOR_R = GPIO.PWM(MOTOR_R_PWM,500)   # PWM 주파수 500Hz
MOTOR_L.start(0)                      # 왼쪽 모터 펄스폭 변조 값 0 으로 시작
MOTOR_R.start(0)                      # 오른쪽 모터 펄스폭 변조 값 0 으로 시작
#---------------------------------------------------------------------------
cam=cv.VideoCapture(0,cv.CAP_V4L)     # 카메라 객체 설정
cam.set(3,640)                        # 화면 X Size (width)
cam.set(4,480)                        # 화면 Y Size (height)
# Motor Run Function -------------------------------------------------------
def motorRun(leftMotor, rightMotor, mode):
# +N = Forward
#  0 = Stop
# -N = Backward
    frame[170-leftMotor:170,20:30]=YELLOW          # 우회전 표시 
    frame[170-rightMotor:170,610:620]=YELLOW       # 좌회전 표시 
    cv.rectangle(frame,(20,70),(30,170),GREEN,1)   
    cv.rectangle(frame,(610,70),(620,170),GREEN,1) 
    cv.putText(frame,mode,(300,30),cv.FONT_HERSHEY_PLAIN,2,WHITE)

#    return

    if (leftMotor>=0):
        GPIO.output(MOTOR_L_DIR,GPIO.HIGH)
        MOTOR_L.ChangeDutyCycle(leftMotor)
    else:
        GPIO.output(MOTOR_L_DIR,GPIO.LOW)
        MOTOR_L.ChangeDutyCycle(abs(leftMotor))
    if (rightMotor>=0):
        GPIO.output(MOTOR_R_DIR,GPIO.HIGH)
        MOTOR_R.ChangeDutyCycle(rightMotor)
    else:
        GPIO.output(MOTOR_R_DIR,GPIO.LOW)
        MOTOR_R.ChangeDutyCycle(abs(rightMotor))
# Traffic Signal Detect ----------------------------------------------------
def trafficSignalDetect(imgray):
    global trafficLight
    tsbgray = imgray[0:120,:]
    circles = cv.HoughCircles(
                 tsbgray,        # 그레이 스케일 신호등 이미지 사용
                 method=cv.HOUGH_GRADIENT,  # 원 검출 방법
                 dp=1,           # The inverse ratio of resolution.
                 minDist=60,     # 검출된 원 중심점 간의 최소거리
                 param1=100,     # Canny 에지 검출을 위한 상위 스레시홀드값
                 param2=30,      # Threshold for center detection
                 minRadius=TS_DIA_MIN, # 원(신호등)의 최소 반지름
                 maxRadius=TS_DIA_MAX  # 원(신호등)의 최대 반지름
                 )
    if circles is not None:
        circles = np.uint16(np.around(circles))
        #print(circles)
        for i in circles[0,:]:
            center = (i[0], i[1]); radius = i[2]
            if(i[1]>30 and i[1]<100 and i[0]>30 and i[0]<620):
                tsa = frame[i[1]-TS_DIA_MIN:i[1]+TS_DIA_MIN,i[0]-TS_DIA_MIN:i[0]+TS_DIA_MIN]
                cv.circle(frame,center,radius,(YELLOW),1)  # circle outline
                cv.putText(frame,"X:"+str(i[0])+" Y:"+str(i[1])+
                                 " R:"+str(i[2]),(i[0]-90,i[1]+40),
                                 cv.FONT_HERSHEY_COMPLEX_SMALL,1,WHITE)
                # BGR 색상 좌표계를 HSV 색상 좌표계로 변환
                hsv = cv.cvtColor(tsa, cv.COLOR_BGR2HSV)
                # 녹색(Green) 신호
                upper_color = np.array([grn_AUH,255,255])        # Upper
                lower_color = np.array([grn_ALH,grn_LS,grn_LV])  # Lower
                # 녹색(Green) 영역 마스크 이미지 생성
                mask = cv.inRange(hsv, lower_color, upper_color)
                # 녹색(Green) 마스크와 신호등과의 비트(Bitwise) AND 연산
                resG = cv.bitwise_and(tsa,tsa,mask=mask)
                histGg = cv.calcHist([resG],[1],None,[256],[0,256]) # 녹색 신호등의 녹색 성분
                #histGr = cv.calcHist([resG],[2],None,[256],[0,256]) # 녹색 신호등의 적색 성분
                # 적색(Red) 양각(P) 신호
                upper_color = np.array([red_PUH,255,255])        # Upper
                lower_color = np.array([red_PLH,red_LS,red_LV])  # Lower
                # 적색(Red) 양각(P) 영역 마스크 이미지 생성
                maskP = cv.inRange(hsv, lower_color, upper_color)
                # 적색(Red) 음각(N) 신호
                upper_color = np.array([red_NUH,255,255])        # Upper
                lower_color = np.array([red_NLH,red_LS,red_LV])  # Lower
                # 적색(Red) 음각(N) 영역 마스크 이미지 생성
                maskN = cv.inRange(hsv, lower_color, upper_color)
                # 적색(Red) 양각(P) 마스크와 음각(N) 마스크의 합성
                mask = cv.bitwise_or(maskP, maskN)
                # 적색(Red) 마스크와 신호등과의 비트(Bitwise) AND 연산
                resR = cv.bitwise_and(tsa,tsa,mask=mask)
                
                histRr = cv.calcHist([resR],[2],None,[256],[0,256]) # 적색 신호등의 적색 성분
                #histRg = cv.calcHist([resR],[1],None,[256],[0,256]) # 적색 신호등의 녹색 성분
                
                cv.rectangle(resR,(0,0),(TS_DIA_MIN*2-1,TS_DIA_MIN*2-1),RED,1)   # Red   신호 사각형 외곽선
                cv.rectangle(resG,(0,0),(TS_DIA_MIN*2-1,TS_DIA_MIN*2-1),GREEN,1) # Green 신호 사각형 외곽선 
                try:    
                    frame[10:(10+TS_DIA_MIN*2),10:(10+TS_DIA_MIN*2)] = resR
                    frame[10:(10+TS_DIA_MIN*2),570:(570+TS_DIA_MIN*2)] = resG
                except:
                    print("resR/G copy Error")
                histGg[0] = 0; histRr[0] = 0      # BLACK 개수를 0 으로
                # Green 신호등 최대 분포값 위치 개수
                ggM = int(np.amax(histGg))        # 히스토그램 데이터중 최대값
                ggmW =np.where(histGg==ggM)       # 최대값의 위치(배열 형)
                ggmWV = int(ggmW[0][0])           # 최대값의 위치(스칼라 형)
                # Red   신호등 최대 분포값 위치 개수
                rrM = int(np.amax(histRr))        # 히스토그램 데이터중 최대값
                rrmW =np.where(histRr==rrM)       # 최대값의 위치(배열 형)
                rrmWV = int(rrmW[0][0])           # 최대값의 위치(스칼라 형)
                if ggmWV > gTsV and ggM > gTsH:
                    trafficLight = True
                    frame[150:190,300:340] = GREEN
                if rrmWV > rTsV and rrM > rTsH:
                    trafficLight = False
                    frame[150:190,300:340] = RED
#---------------------------------------------------------------------------
def boxLine(p0x,p0y,p1x,p1y,p2x,p2y,p3x,p3y):
# 직사각형의 4개의 꼭지점 좌표값을 입력으로 하고 사각형의 길이 방향으로
# 직선을 만들어 Window 에 걸치는 좌표점을 반환한다.  

    xs=0; ys=0; xe=0; ye=0; dvx=0; dvy=0; xc=0; yc=0; rf=False
    
    pcx=int((p0x+p2x)/2); pcy=int((p0y+p2y)/2)   # 사각형의 중점을 구한다.
    rf=True
    
    if ((p1x-p0x)**2 + (p1y-p0y)**2) >= ((p2x-p1x)**2 + (p2y-p1y)**2):
        dvx=p1x-p0x; dvy=p1y-p0y
    else:
        dvx=p2x-p1x; dvy=p2y-p1y
    #-----------------------------------------------------------------------
    if (dvx==0) and (dvy!=0):
        xs=pcx; ys=TWD; xe=pcx; ye=TWU;
    elif (dvx!=0) and (dvy==0):
        xs=TWL; ys=pcy; xe=TWR; ye=pcy;
    elif (dvx==0) and (dvy==0):
        rf = False
    else:
        xs=TWL; ys=(xs-pcx)*dvy/dvx+pcy
        if ys<TWU:
            ys=TWU; xs=(ys-pcy)*dvx/dvy+pcx
            if xs>TWR or xs<TWL:
                rf = False
        elif ys>TWD:
            ys=TWD; xs=(ys-pcy)*dvx/dvy+pcx
            if xs>TWR or xs<TWL:
                rf = False

        xe=TWR; ye=(xe-pcx)*dvy/dvx+pcy
        if ye<TWU:
            ye=TWU; xe=(ye-pcy)*dvx/dvy+pcx
            if xe>TWR or xe<TWL:
                rf = False
        elif ye>TWD:
            ye=TWD; xe=(ye-pcy)*dvx/dvy+pcx
            if xe>TWR or xe<TWL:
                rf = False
    #-----------------------------------------------------------------------
    if ye<ys:
        xt = xe; xe = xs; xs = xt
        yt = ye; ye = ys; ys = yt
        
    xc = (xs+xe)/2; yc = (ys+ye)/2

    return (int(xs), int(ys), int(xe), int(ye), int(xc), int(yc))    
#---------------------------------------------------------------------------
def getLane(imgLane):
    # 그레이 영상을 2 진화
    if threshLevel == 0: # OTSU
        _,imThresh = cv.threshold(imgLane,-1,255,cv.THRESH_BINARY | cv.THRESH_OTSU)
        cv.putText(frame,'OTSU',(280,30),cv.FONT_HERSHEY_PLAIN,2,WHITE)
    else:
        _,imThresh = cv.threshold(imgLane,threshLevel,255, cv.THRESH_BINARY)
        cv.putText(frame,str(threshLevel),(280,30),cv.FONT_HERSHEY_PLAIN,2,WHITE)
    #-----------------------------------------------------------------------
    imThresh[0:TWU,:] = 0xFF
    imThresh[TWD:480,:] = 0xFF
    imThresh[:,0:TWL] = 0xFF
    imThresh[:,TWR:640] = 0xFF
    #-----------------------------------------------------------------------
    # Dilate(확산) 연산으로 노이즈 제거 
    kernelSize = cv.getStructuringElement(cv.MORPH_RECT,(K_SIZE,K_SIZE)) # 구조화 커널
    imDThresh = cv.dilate(imThresh,kernelSize)
    #cv.imshow('<3> DThresh',imDThresh)    # 침식 연산 후 영상 디스프레이
    #-----------------------------------------------------------------------
    print('===============================================================')
    # 컨투어 검출
    contoursThresh,_ = cv.findContours(imDThresh,cv.RETR_TREE,cv.CHAIN_APPROX_SIMPLE)
    # imDThresh: 입력 이미지
    # RETR_TREE: 모든 라인의 모든 계층 정보를 트리 구조로 제공
    # CHAIN_APPROX_NONE: 근사 계산하지 않고 모든 좌표 제공
    # CHAIN_APPROX_SIMPLE: 주요 외곽점 정보만 제공
    cv.drawContours(frame,contoursThresh,-1,RED,1)
    # frame: 그림(컨투어)을 그릴 타겟 영상
    # contoursThresh: 그림 그릴 컨투어 배열
    # -1: 모든 컨투어 그림 (-1이 아니면 컨투어 지정 인덱스가 된다)
    # RED: 컨투어 그림의 색을 빨간색으로 그린다.
    # 1: 컨투어 그림의 선폭
    cCounts = len(contoursThresh) # 검출된 컨투어의 수, 프레임도 컨투어 이므로 최소 1
    print('검출된 컨투어 개수(프레임 포함) =',cCounts)
    ctrDictA = {}               # 사전형 변수 설정
    for i in range(0,cCounts):  # 검출된 컨투어의 외곽 길이 정보를 가져와  
                                # 번호 i 와 같이 사전형 데이터 형식으로 저장 
        t = cv.contourArea(contoursThresh[i]) # 컨투어 면적
        if minContArea < t < maxContArea: # 차선으로 판단할 최소면적과 최대면적 검사
            ctrDictA[i] = t     # 차선 번호(i)와 면적 정보가 동시에 저장된다.
    # 컨투어의 길이(면적) 크기 순(내림차순)으로 정렬한다.
    print('최소, 최대 조건을 통과한 컨투어 집합 =',ctrDictA)
    sKeyList = sorted(ctrDictA,key=ctrDictA.__getitem__,reverse=True)
    print('컨투어 면적 크기순(내림 차순)으로 컨투어 번호 나열  =',sKeyList)

    # 컨투어에 근접한 사각형에서 4 개의 꼭지점 정보, 중심점 정보 를 저장할 리스트 변수생성
    #         Xs Ys Xe Ye Xc Yc  Xs Ys Xe Ye Xc Yc  Xs Ys Xe Ye Xc Yc  
    track = [[0, 0, 0, 0, 0, 0],[0, 0, 0, 0, 0, 0],[0, 0, 0, 0, 0, 0]]
    #
    i = 0 # 나열된 컨투어를 0번 부터 지시하는 인덱스로 사용
    for cl in sKeyList:    # 내림 차순으로 정열된 컨투어 번호를 가져온다
        print('---------------------------------------------------------------')
        rect = cv.minAreaRect(contoursThresh[cl])      # 차선(컨투어)의 최소 근접 사각 형
        box = cv.boxPoints(rect)
        box = np.int0(box) # 최소 근접 사각형의 4 점 좌표 

        xxx = int((box[2][0]+box[0][0])/2)
        yyy = int((box[2][1]+box[0][1])/2)
        print('컨투어',cl,'의 근접 사각형 4 개 좌표')
        print(box)         # Y 값이 가장 큰 좌표값이 첫번째(0)이며 반시계 방향으로 1,2,3
        #                  0  X      1  X             0  Y      1  Y
        b01 = math.sqrt((box[0][0]-box[1][0])**2 + (box[0][1]-box[1][1])**2)
        b12 = math.sqrt((box[1][0]-box[2][0])**2 + (box[1][1]-box[2][1])**2)
        #                  1  X      2  X             1  Y      2  Y
        if b01 > b12:                # 컨투어가 왼쪽으로 기울어져 있을 때
            a = b01/b12              # 컨투어 가로 세로 비율
        else:                        # 컨투어가 오른쪽으로 기울어져 있을 때
            a = b12/b01              # 컨투어 가로 세로 비율 
        
        p = b01*b12                  # 컨투어 근접 사각형의 면적
        print('컨투어',cl,'의 근접 사각형의 면적 =',p)
        print('컨투어',cl,'의 원시 컨투어 면적   =',ctrDictA[cl])
        q = ctrDictA[cl]/p           # 컨투어 근접사각형의 면적과 컨투어의 면적 비율 
        print('컨투어',cl,'의 근접 사각형과 원시 컨투어 면적 비율 q =',q)

        t = round(a,1)
        cv.putText(frame,str(t),(xxx,yyy-35),cv.FONT_HERSHEY_PLAIN,1,CYAN)
        t = round(q,1)
        cv.putText(frame,str(t),(xxx,yyy-20),cv.FONT_HERSHEY_PLAIN,1,CYAN)

        if a > ASPECT_RATIO and q > AREA_RATIO:
            print('컨투어',cl,'은 가로 세로 비율 조건(a)과 근접 사각형과 원시 컨투어 면적 비율(q) 조건을 만족하여 차선으로 인정한다.')
            cv.drawContours(frame,[box],0,CYAN,1)  # 최소 근접 사각형 드로잉

            xu, yu, xd, yd, xc, yc = boxLine(box[0][0],box[0][1],box[1][0],box[1][1],\
                                             box[2][0],box[2][1],box[3][0],box[3][1])    
            track[i][0] = xu; track[i][1] = yu; track[i][2] = xd; track[i][3] = yd
            track[i][4] = xc; track[i][5] = yc
            cv.line(frame,(xu,yu),(xd,yd),WHITE,1)   #
            cv.circle(frame,(xu,yu),4,GREEN,-1)   
            cv.circle(frame,(xd,yd),9,PINK,-1)   

            cv.putText(frame,str(xu),(xu,yu+15),cv.FONT_HERSHEY_PLAIN,1,CYAN)
            cv.putText(frame,str(yu),(xu,yu+30),cv.FONT_HERSHEY_PLAIN,1,CYAN)
            cv.putText(frame,str(xd),(xd,yd-30),cv.FONT_HERSHEY_PLAIN,1,CYAN)
            cv.putText(frame,str(yd),(xd,yd-15),cv.FONT_HERSHEY_PLAIN,1,CYAN)

            cv.putText(frame,str(xc),(xc,yc+15),cv.FONT_HERSHEY_PLAIN,1,YELLOW)
            cv.putText(frame,str(yc),(xc,yc+30),cv.FONT_HERSHEY_PLAIN,1,YELLOW)
            
            i += 1
            if i > 2:                              # 차선이 3개 선택되었으면 종료
                break
    line = sorted(track, key=op.itemgetter(4))     # 차선 중심 X 좌표 값으로 소팅(오름차순) 
    print('***************************************************************')
    print('인식된 차선 개수 =',i)

    lsx = 0; lsy = 0; lex = 0; ley = 0
    csx = 0; csy = 0; cex = 0; cey = 0
    cux = 0; cuy = 0; cdx = 0; cdy = 0
    if i >= 2:     # 3개 또는 2개 차선이 인식되면 오른쪽 2개 차선의 중앙이 주행 기준선
        cux = int((line[2][0]+line[1][0])/2); cuy = int((line[2][1]+line[1][1])/2)
        cdx = int((line[2][2]+line[1][2])/2); cdy = int((line[2][3]+line[1][3])/2)

    elif i == 1:  # 1개 차선 인식
        cux = line[2][0]; cuy = line[2][1]
        cdx = line[2][2]; cdy = line[2][3]

    cux,cuy,cdx,cdy,_,_ = boxLine(cux,cuy,cux,cuy,cdx,cdy,cdx,cdy)

    if i >= 1:     # 1개 이상의 차선이 인식되어야 주행 기준선과 각도 표시한다.
        cv.line(frame,(cux,cuy),(cdx,cdy),YELLOW,2)   # 주행 기준선 표시
        cv.circle(frame,(cux,cuy),4,GREEN,-1)   
        cv.circle(frame,(cdx,cdy),9,PINK,-1)   
        cv.putText(frame,str(cux),(cux,cuy),cv.FONT_HERSHEY_PLAIN,1,YELLOW)
        cv.putText(frame,str(cdx),(cdx,cdy-10),cv.FONT_HERSHEY_PLAIN,1,YELLOW)

    cv.rectangle(frame,(TWL,TWU),(TWR,TWD),GREEN,1)
    cv.line(frame,(FL1,TWU),(FL1,TWD),GREEN,1)   # 
    cv.line(frame,(FR1,TWU),(FR1,TWD),GREEN,1)   # 
    cv.line(frame,(FL2,TWU),(FL2,TWD),GREEN,1)   # 
    cv.line(frame,(FR2,TWU),(FR2,TWD),GREEN,1)   # 

    cv.line(frame,(TWL,FD2),(TWR,FD2),GREEN,1)   # 

    cv.putText(frame,str(FL1),(FL1-15,TWU-10),cv.FONT_HERSHEY_PLAIN,1,GREEN)
    cv.putText(frame,str(FL2),(FL2-15,TWU-10),cv.FONT_HERSHEY_PLAIN,1,GREEN)
    cv.putText(frame,str(FR1),(FR1-15,TWU-10),cv.FONT_HERSHEY_PLAIN,1,GREEN)
    cv.putText(frame,str(FR2),(FR2-15,TWU-10),cv.FONT_HERSHEY_PLAIN,1,GREEN)

    return(cux, cuy, cdx, cdy)
#---------------------------------------------------------------------------
# Start
#---------------------------------------------------------------------------
while cam.isOpened():
    _,frameO = cam.read()                    # 1개 프레임 카메라 화면 읽기
    frame = frameO[0:400,0:640]
    #-----------------------------------------------------------------------
    imGray = cv.cvtColor(frame,cv.COLOR_BGR2GRAY)  # 컬러 영상을 그레이 영상으로 변환
#    tsGreen, tsRed = trafficSignalDetect(imGray)
    trafficSignalDetect(imGray)
                
    #cv.imshow('<1> Gray',imGray)                   # 그레이 영상 디스프레이
#    imGray = cv.bitwise_not(imGray)                # 그레이 영상을 반전
    #cv.imshow('<2> GrayNot',imGray)                # 그레이 반전 영상 디스프레이
    #-----------------------------------------------------------------------
    cux, cuy, cdx, cdy = getLane(imGray)       # 기준 차선 정보를 가져온다.

    if trafficReset<10:                        # 적색 신호등 검사
        MOTOR_L.ChangeDutyCycle(0)             #  
        MOTOR_R.ChangeDutyCycle(0)             #
    else:
        if FL1<cux<FR1 and FL1<cdx<FR1:        # Case A        
            motorRun(90, 90, 'A')
        elif FL2<cux<FL1 and FR1<cdx<FR2:      # Case B
            motorRun(70, 20, 'B')
        elif FR1<cux<FR2 and FL2<cdx<FL1:      # Case C
            motorRun(20, 70, 'C')
        elif cux>FR1 and cdx>FL1:              # Case D - XD 와 XU 전부 오른쪽
            motorRun(70, 20, 'D')              # 우회전 
        elif cux<FL1 and cdx<FR1:              # Case E - XD 와 XU 전부 왼쪽
            motorRun(20, 70, 'E')              # 좌회전
        elif cux<FL2 and FD2<cuy<cdy:          # Case F
            motorRun(-90, 90, 'F')             # 제자리 좌회전
        elif cux>FR2 and FD2<cuy<cdy:          # Case G
            motorRun(90, -90, 'G')             # 제자리 우회전
        else:
            motorRun(40, 40, 'Z')              # 기타 범위 - 직전

#    frame = cv.resize(frame, None, fx=0.743, fy=0.57, interpolation=cv.INTER_AREA)    
    cv.imshow('PiCAR',frame)
    #-----------------------------------------------------------------------
    keyBoard = cv.waitKey(1)&0xFF
    if keyBoard == 0x1B:                    # ESC 키 입력 시 프로그램 종료
        break
#---------------------------------------------------------------------------
MOTOR_L.stop()                              # 왼쪽 모터 PWM(펄스 폭 변조) 정지
MOTOR_R.stop()                              # 오른쪽 모터 PWM(펄스 폭 변조) 정지
GPIO.cleanup()                              # GPIO 초기화
cam.release()                               # 카메라 자원을 반납
cv.destroyAllWindows()                      # 열려 있는 모든 윈도우를 닫기
############################################################################
