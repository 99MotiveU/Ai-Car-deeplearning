# 단순한 선형 회귀 예제 (텐서플로우2) https://byunghyun23.tistory.com/42
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf

# x(입력), y(결과) 데이터
x_train = np.array([1, 2, 3, 4, 5])
y_train = np.array([2, 4, 6, 8, 10])

# keras의 다차원 계층 모델인 Sequential를 레이어를 만든다.
model = tf.keras.models.Sequential()
# 입력이 1차원이고 출력이 1차원임을 뜻함 - Dense는 레이어의 종류
model.add(tf.keras.layers.Dense(5, input_dim=1, activation='linear'))
model.add(tf.keras.layers.Dense(3))
model.add(tf.keras.layers.Dense(1))

# 모델 구조 확인
model.summary()

# Optimizer - Stochastic gradient descent - 확률적 경사 하강법
sgd = tf.keras.optimizers.Adam(learning_rate=0.01)

# cost/loss funcion
# loss를 mean_squared_error 방식을 사용한다는 의미로 mse 라고 써도 인식한다.
model.compile(loss='mean_squared_error', optimizer=sgd)

#fit the line
# 텐서 플로우 1과 다르게 세션을 만들어서 돌릴 필요가 없다.
# 간단하게 만들어서 학습을 시작한다.
hist = model.fit(x_train, y_train, batch_size=1, epochs=500, verbose=1)

# 훈련 과정 시각화 (손실)
plt.plot(hist.history['loss'])
plt.title('loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.show()

# 모델 시각화
line_x = np.arange(min(x_train), max(x_train), 0.01)
line_y = model.predict(line_x)
plt.plot(line_x, line_y, 'r-')
plt.plot(x_train, y_train, 'bo')
plt.title('Model')
plt.xlabel('input (%)')
plt.ylabel('predict (%)')
plt.legend(['predict', 'train'], loc='upper left')
plt.show()

# 손실 함수 계산
loss = model.evaluate(x_train, y_train, batch_size=1, verbose=2)
print('loss : ', loss)

# 모델 테스트
for i in range(1, 8):
    print('input : ', i, ', output : ', model.predict(np.array([i])), sep='')  # 입력 i에 대한 예측 값 출력

print('input : ', 99, ', output : ', model.predict(np.array([99])), sep='')

