#############################################################################################
# Linear Regression by TensolFlow                                                <rt.py>
#
# 
#
# 마우스로 N 개의 점을 입력한다.
# Epoch 수를 100, 200, 500, 1000 중 하나를 선택하면 Deep Learning 시작한다.
# 학습한 결과에 의한 선형 방정식을 그래픽 디스프레이한다.
# 
# LSQ: 최소자승법에 의한 회귀직선은 힌색(WHITE) 선으로 그려진다.
# 
# 아래 링크를 참고하여 재구성한 프로그램입니다.
# https://byunghyun23.tistory.com/42
#
# 2024-09-01
#
# SAMPLE Electronics co.                                        
# http://www.ArduinoPLUS.com
#                                                               
import numpy as np          # 이미지 배열 생성(OpenCV 에서 사용) 라이브러리
import cv2                  # 영상처리(OpenCV) 라이브러리 
import tensorflow as tf
# Constant ----------------------------------------------------------------------------------
RED     =   0,  0,255       # Red
GREEN   =   0,255,  0       # Green
BLUE    = 255,  0,  0       # Blue
MAGENTA = 255,  0,255       # Magenta(Pink)
CYAN    = 255,255,  0       # Cyan(Sky Blue)
YELLOW  =   0,255,255       # Yellow
WHITE   = 255,255,255       # White
BLACK   =   0,  0,  0       # Black
GRAY    =  128, 128, 128       # Gray
MELON   =   0,180,255       # Melon
#--------------------------------------------------------------------------------------------
mouseX = 0                  # 마우스 X좌표
mouseY = 0                  # 마우스 Y좌표
mouseButtenLeft = False     # 마우스 왼쪽 버튼
mouseButtenToggle = False   # 마우스 오른쪽 버튼
selectedObject = None       # 객체 선택
SET_MODE = True
SCREEN_SIZE_X = 640
SCREEN_SIZE_Y = 480

EPOCH_100_X = 360
EPOCH_100_Y = 30
EPOCH_200_X = 440
EPOCH_200_Y = 30
EPOCH_500_X = 520
EPOCH_500_Y = 30
EPOCH_1000_X = 600
EPOCH_1000_Y = 30

LSQ_X = 50
LSQ_Y = 30

#--------------------------------------------------------------------------------------------
viewWin = np.zeros((SCREEN_SIZE_Y,SCREEN_SIZE_X,3),np.uint8)  # 표시되는 윈도우 가로, 세로, 컬러층, 8비트
#--------------------------------------------------------------------------------------------
#cv2.namedWindow('Out',cv2.WND_PROP_FULLSCREEN)
#cv2.setWindowProperty('Out', cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
#--------------------------------------------------------------------------------------------
# 수학적 좌표값을 스크린 좌표값으로 변경 ----------------------------------------------------------
# X 스크린 영역의 중앙을 0 으로 설정한다. x = 0 을 기준으로 오른 쪽이 + 왼쪽이 - 
def convX(x):
    return(int(SCREEN_SIZE_X/2+x))
# Y 스크린 영역의 중앙을 0 으로 설정한다. y = 0 을 기준으로 위 쪽이 + 아래쪽이 - 
def convY(y):
    return(int(SCREEN_SIZE_Y/2-y))

# 스크린 좌표값을 수학적 좌표값으로 변환  # mouseX-400, 240-mouseY  
def conSCX(x):
    return(x-int(SCREEN_SIZE_X/2))

def conSCY(y):
    return(int(SCREEN_SIZE_Y/2-y))

# Mouse Callback Function -------------------------------------------------------------------
def controlMain(event,x,y,flags,param):
    '''
    마우스 이벤트 발생시 처리되는 함수 입니다.
    3 개의 마우스 버튼 Up/Down 이벤트와 X,Y 이동 이벤트를 처리합니다.
    '''
    global mouseX, mouseY, mouseButtenLeft, mouseButtenToggle, selectedObject, SET_MODE
    
    mouseX = x; mouseY = y                # 마우스 좌표값 X, Y를 전역변수 mouseX, mouseY에 저장

    if event == cv2.EVENT_LBUTTONDOWN:    # print('L-Down') # 마우스 왼쪽 버튼 이벤트 발생
        if SET_MODE:
            mouseButtenLeft = True

    if event == cv2.EVENT_RBUTTONDOWN:    # print('R-Down') # 마우스 오른쪽 버튼 이벤트 발생
        mouseButtenToggle = False
        selectedObject = None
        SET_MODE = True

def epochButton():

    cv2.rectangle(viewWin,(EPOCH_100_X-30 ,EPOCH_100_Y-20 ),(EPOCH_100_X+30 ,EPOCH_100_Y+20),GRAY,-1)     # 
    cv2.rectangle(viewWin,(EPOCH_200_X-30 ,EPOCH_200_Y-20 ),(EPOCH_200_X+30 ,EPOCH_200_Y+20),GRAY,-1)     # 
    cv2.rectangle(viewWin,(EPOCH_500_X-30 ,EPOCH_500_Y-20 ),(EPOCH_500_X+30 ,EPOCH_500_Y+20),GRAY,-1)     # 
    cv2.rectangle(viewWin,(EPOCH_1000_X-30 ,EPOCH_1000_Y-20 ),(EPOCH_1000_X+30 ,EPOCH_1000_Y+20),GRAY,-1)     # 

    cv2.rectangle(viewWin,(LSQ_X-30 ,LSQ_Y-20 ),(LSQ_X+30 ,LSQ_Y+20),GRAY,-1)     # 

    cv2.putText(viewWin,'100',(EPOCH_100_X-20 ,EPOCH_100_Y+8),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,CYAN)
    cv2.putText(viewWin,'200',(EPOCH_200_X-20 ,EPOCH_200_Y+8),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,RED)
    cv2.putText(viewWin,'500',(EPOCH_500_X-20 ,EPOCH_500_Y+8),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,BLUE)
    cv2.putText(viewWin,'1000',(EPOCH_1000_X-28 ,EPOCH_1000_Y+8),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,MAGENTA)

    cv2.putText(viewWin,'LSQ',(LSQ_X-20 ,LSQ_Y+8),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,WHITE)


#@tf.function(input_signature=[tf.TensorSpec(shape=[None, 4], dtype=tf.float32)])
def lineRegT(train_x, train_y, EPN):
    # keras의 다차원 계층 모델인 Sequential를 레이어를 만든다.
    model = tf.keras.models.Sequential()
    # 입력이 1차원이고 출력이 1차원임을 뜻함 - Dense는 레이어의 종류
    model.add(tf.keras.layers.Dense(5, input_dim=1, activation='linear'))
    model.add(tf.keras.layers.Dense(3))
    model.add(tf.keras.layers.Dense(1))

    # 모델 구조 확인
    model.summary()

    # Optimizer - Stochastic gradient descent - 확률적 경사 하강법
    sgd = tf.keras.optimizers.Adam(learning_rate=0.01)

    # cost/loss funcion
    # loss를 mean_squared_error 방식을 사용한다는 의미로 mse 라고 써도 인식한다.
    model.compile(loss='mean_squared_error', optimizer=sgd)

    #fit the line
    # 학습을 시작한다.
    hist = model.fit(train_x, train_y, batch_size=1, epochs=EPN, verbose=1)

    return(model)



# Main Loop =================================================================================
def main():

    global mouseButtenLeft, mouseButtenToggle, selectedObject
    global SET_MODE
    
    weightX, weightY = 150, 100
    biasX, biasY = 0, -50
    dataList = []                       # 추가되는 데이터(점) 좌표
    train_x = np.array([])
    train_y = np.array([])

    regLine = []

    #-----------------------------------------------------------------------------------------
    while True:

        viewWin[:,:] = BLACK              # 스크린 클리어

        cv2.line(viewWin,(convX(-400),convY(0)),(convX(399),convY(0)),YELLOW,1) # X-Axis
        cv2.line(viewWin,(convX(0),convY(-240)),(convX(0),convY(239)),YELLOW,1) # Y-Axis
        epochButton()


        if mouseButtenLeft:

            if (mouseX>(EPOCH_100_X-30)) and (mouseY>(EPOCH_100_Y-20)) and(mouseX<(EPOCH_100_X+30)) and (mouseY<(EPOCH_100_Y+20)):   # 
                #cv2.rectangle(viewWin,(EPOCH_100_X-30 ,EPOCH_100_Y-20 ),(EPOCH_100_X+30 ,EPOCH_100_Y+20),WHITE,2)     # 
                #cv2.imshow('Linear Regression TensorFlow', viewWin)           # 이미지를 LCD에 표시
                print('Epoch - 100 Start.')
                model = lineRegT(train_x, train_y, 100)
                x1, x2 = -300, +300
                Y = model.predict(np.array([x1]))
                y1 = int(Y[0][0])
                Y = model.predict(np.array([x2]))
                y2 = int(Y[0][0])
                regLine.append([x1,y1,x2,y2,CYAN])
                print('Epoch - 100 End.')

            elif (mouseX>(EPOCH_200_X-30)) and (mouseY>(EPOCH_200_Y-20)) and(mouseX<(EPOCH_200_X+30)) and (mouseY<(EPOCH_200_Y+20)):   # 
                print('Epoch - 200 Start.')
                model = lineRegT(train_x, train_y, 200)
                x1, x2 = -300, +300
                Y = model.predict(np.array([x1]))
                y1 = int(Y[0][0])
                Y = model.predict(np.array([x2]))
                y2 = int(Y[0][0])
                regLine.append([x1,y1,x2,y2,RED])
                print('Epoch - 200 End.')

            elif (mouseX>(EPOCH_500_X-30)) and (mouseY>(EPOCH_500_Y-20)) and(mouseX<(EPOCH_500_X+30)) and (mouseY<(EPOCH_500_Y+20)):   # 
                print('Epoch - 500 Start.')
                model = lineRegT(train_x, train_y, 500)
                x1, x2 = -300, +300
                Y = model.predict(np.array([x1]))
                y1 = int(Y[0][0])
                Y = model.predict(np.array([x2]))
                y2 = int(Y[0][0])
                regLine.append([x1,y1,x2,y2,BLUE])
                print('Epoch - 500 End.')
            elif (mouseX>(EPOCH_1000_X-30)) and (mouseY>(EPOCH_1000_Y-20)) and(mouseX<(EPOCH_1000_X+30)) and (mouseY<(EPOCH_1000_Y+20)):   # 
                print('Epoch - 1000 Start.')
                model = lineRegT(train_x, train_y, 1000)
                x1, x2 = -300, +300
                Y = model.predict(np.array([x1]))
                y1 = int(Y[0][0])
                Y = model.predict(np.array([x2]))
                y2 = int(Y[0][0])
                regLine.append([x1,y1,x2,y2,MAGENTA])
                print('Epoch - 1000 End.')

            elif (mouseX>(LSQ_X-30)) and (mouseY>(LSQ_Y-20)) and(mouseX<(LSQ_X+30)) and (mouseY<(LSQ_Y+20)):   # 

                A = np.vstack([train_x, np.ones(len(train_x))]).T
                w, b = np.linalg.lstsq(A, train_y, rcond=None)[0]

                x1, x2 = -300, +300
                y1 = int(w*x1 + b); y2 = int(w*x2 + b)
                regLine.append([x1,y1,x2,y2,WHITE])

            else:

                dataList.append([len(dataList), 0, conSCX(mouseX), conSCY(mouseY)])  # 마우스로 입력한 점 좌표를 리스트에 추가
                train_x = np.append(train_x,conSCX(mouseX))
                train_y = np.append(train_y,conSCY(mouseY))

            mouseButtenLeft = False

        #for point in dataList:
        #    cv2.circle(viewWin,(convX(point[2]),convY(point[3])),10,GREEN,-1,cv2.LINE_AA)

        
        for i in range(len(train_x)):
            cv2.circle(viewWin,(convX(train_x[i]),convY(train_y[i])),10,GREEN,-1,cv2.LINE_AA)

        for i in range(len(regLine)):
            cv2.line(viewWin,(convX(regLine[i][0]),convY(regLine[i][1])),(convX(regLine[i][2]),convY(regLine[i][3])),regLine[i][4],1,cv2.LINE_AA) # X-Axis

        cv2.imshow('Linear Regression TensorFlow', viewWin)           # 이미지를 LCD에 표시
        keyBoard = cv2.waitKey(1) & 0xFF     # 키보드 입력
        if keyBoard == 0x1B or keyBoard == 0x09 or keyBoard == ord(' ') or keyBoard == ord('x') or keyBoard == ord('X'):
            break                            # ESC / TAB / 'x' 프로그램 종료

# Mouse Event -------------------------------------------------------------------------------
cv2.namedWindow('Linear Regression TensorFlow')                               # 윈도우 창을 생성
cv2.setMouseCallback('Linear Regression TensorFlow', controlMain, viewWin)    # 마우스 제어 설정
#--------------------------------------------------------------------------------------------
main()                                               # 신호등 메인 프로그램 실행
#############################################################################################

'''


x = np.array(dataX)
y = np.array(dataY)

A = np.vstack([x, np.ones(len(x))]).T

m, c = np.linalg.lstsq(A, y, rcond=None)[0]

X1 = 0
Y1 = int(m*X1 + c)

X2 = 699
Y2 = int(m*X2 + c)

cv2.line(img,(X1,Y1),(X2,Y2),COLOR_RST,1,cv2.LINE_AA)
'''

