#############################################################################################
# Loss Function                                                                   <lf.py>
#
# 손실함수의 그래픽 처리
#
# W 와 b 위치를 마우스로 변경할수 있도록한다.
# 마우스로 N 개의 점을 입력한다.
# 점 Ni 에서 직선과 y 길이를 한 변으로 하는 정사각형을 그린다.
# 
#
# 2024-08-29
#
# SAMPLE Electronics co.                                        
# http://www.ArduinoPLUS.com
#                                                               
import numpy as np          # 이미지 배열 생성(OpenCV 에서 사용) 라이브러리
import cv2                  # 영상처리(OpenCV) 라이브러리 
# Constant ----------------------------------------------------------------------------------
RED     =   0,  0,255       # Red
GREEN   =   0,255,  0       # Green
BLUE    = 255,  0,  0       # Blue
MAGENTA = 255,  0,255       # Magenta(Pink)
CYAN    = 255,255,  0       # Cyan(Sky Blue)
YELLOW  =   0,255,255       # Yellow
WHITE   = 255,255,255       # White
BLACK   =   0,  0,  0       # Black
GRAY    =  96, 96, 96       # Gray
MELON   =   0,180,255       # Melon
#--------------------------------------------------------------------------------------------
mouseX = 0                  # 마우스 X좌표
mouseY = 0                  # 마우스 Y좌표
mouseButtenLeft = False     # 마우스 왼쪽 버튼
mouseButtenToggle = False   # 마우스 오른쪽 버튼
selectedObject = None       # 객체 선택
SET_MODE = True
#--------------------------------------------------------------------------------------------
viewWin = np.zeros((480,800,3),np.uint8)  # 표시되는 윈도우 가로, 세로, 컬러층, 8비트
#--------------------------------------------------------------------------------------------
cv2.namedWindow('Out',cv2.WND_PROP_FULLSCREEN)
cv2.setWindowProperty('Out', cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
#--------------------------------------------------------------------------------------------
# 수학적 좌표값을 스크린 좌표값으로 변경 ----------------------------------------------------------
# X 스크린 영역의 중앙을 0 으로 설정한다. x = 0 을 기준으로 오른 쪽이 + 왼쪽이 - 
def convX(x):
    return(400+x)
# Y 스크린 영역의 중앙을 0 으로 설정한다. y = 0 을 기준으로 위 쪽이 + 아래쪽이 - 
def convY(y):
    return(240-y)
# Mouse Callback Function -------------------------------------------------------------------
def controlMain(event,x,y,flags,param):
    '''
    마우스 이벤트 발생시 처리되는 함수 입니다.
    3 개의 마우스 버튼 Up/Down 이벤트와 X,Y 이동 이벤트를 처리합니다.
    '''
    global mouseX, mouseY, mouseButtenLeft, mouseButtenToggle, selectedObject, SET_MODE
    
    mouseX = x; mouseY = y                # 마우스 좌표값 X, Y를 전역변수 mouseX, mouseY에 저장

    if event == cv2.EVENT_LBUTTONDOWN:    # print('L-Down') # 마우스 왼쪽 버튼 이벤트 발생
        if SET_MODE:
            mouseButtenLeft = True

    if event == cv2.EVENT_RBUTTONDOWN:    # print('R-Down') # 마우스 오른쪽 버튼 이벤트 발생
        mouseButtenToggle = False
        selectedObject = None
        SET_MODE = True

# Main Loop =================================================================================
def main():

    global mouseButtenLeft, mouseButtenToggle, selectedObject
    global SET_MODE
    
    weightX, weightY = 150, 100
    biasX, biasY = 0, -50
    objectList = []                       # 추가되는 데이터(점) 좌표
    #-----------------------------------------------------------------------------------------
    while True:

        viewWin[:,:] = BLACK              # 스크린 클리어

        cv2.line(viewWin,(convX(-480),convY(0)),(convX(479),convY(0)),YELLOW,1) # X-Axis
        cv2.line(viewWin,(convX(0),convY(-240)),(convX(0),convY(239)),YELLOW,1) # Y-Axis

        if mouseButtenLeft:
            #print(mouseX, mouseY)
            objectList.append([len(objectList), 0, mouseX-400, 240-mouseY])  # 마우스로 입력한 점 좌표를 리스트에 추가
            mouseButtenLeft = False

        for point in objectList:
            cv2.circle(viewWin,(convX(point[2]),convY(point[3])),10,GREEN,-1,cv2.LINE_AA)

        cv2.imshow('Out', viewWin)           # 이미지를 LCD에 표시
        keyBoard = cv2.waitKey(1) & 0xFF     # 키보드 입력
        if keyBoard == 0x1B or keyBoard == 0x09 or keyBoard == ord(' ') or keyBoard == ord('x') or keyBoard == ord('X'):
            break                            # ESC / TAB / 'x' 프로그램 종료

    while True:

        viewWin[:,:] = BLACK                 # 스크린 클리어

        cv2.line(viewWin,(convX(-480),convY(0)),(convX(479),convY(0)),YELLOW,1) # X-Axis
        cv2.line(viewWin,(convX(0),convY(-240)),(convX(0),convY(239)),YELLOW,1) # Y-Axis

        cv2.circle(viewWin,(convX(weightX),convY(weightY)),10,RED,-1,cv2.LINE_AA)
        cv2.circle(viewWin,(convX(biasX),convY(biasY)),10,BLUE,-1,cv2.LINE_AA)

        for point in objectList:
            cv2.circle(viewWin,(convX(point[2]),convY(point[3])),10,GREEN,-1,cv2.LINE_AA)
        
        a = (weightY-biasY)/weightX
        y1 = -400*a+biasY  # x1 = -400
        y2 = 399*a+biasY   # x2 = +399

        cv2.line(viewWin,(convX(-400),convY(int(y1))),(convX(399),convY(int(y2))),WHITE,1) # X-Axis

        squareSum = 0        
        for point in objectList:
            mx = point[2]
            my = point[3]
            d = int(a*mx+biasY) - point[3]
            cv2.rectangle(viewWin,(convX(mx) ,convY(my) ),(convX(mx+d) ,convY(my+d) ),MAGENTA,1)     # 
            squareSum += d**2

        cv2.putText(viewWin,f'{squareSum}',(10,40),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,WHITE)

        wD = (weightX-(mouseX-400))**2+(weightY-(240-mouseY))**2
        bD = (biasX-(mouseX-400))**2+(biasY-(240-mouseY))**2
        #------------------------------------------------------------------------------------
        if mouseButtenLeft:
            mouseButtenToggle = not mouseButtenToggle
            mouseButtenLeft = False                                     # 원 슈트(One Shoot)

        if mouseButtenToggle:
            if wD<bD:                           # Weight
                weightY = 240-mouseY
            else:                               # bias
                biasY = 240-mouseY
            # mouseX-400, 240-mouseY  # 스크린 좌표값을 수학적 좌표값으로 변환

        cv2.imshow('Out', viewWin)           # 이미지를 LCD에 표시
        keyBoard = cv2.waitKey(10) & 0xFF     # 키보드 입력
        if keyBoard == 0x1B or keyBoard == 0x09 or keyBoard == ord(' ') or keyBoard == ord('x') or keyBoard == ord('X'):
            break                            # ESC / TAB / 'x' 프로그램 종료
# Mouse Event -------------------------------------------------------------------------------
cv2.namedWindow('Out')                               # 윈도우 창을 생성
cv2.setMouseCallback('Out', controlMain, viewWin)    # 마우스 제어 설정
#--------------------------------------------------------------------------------------------
main()                                               # 신호등 메인 프로그램 실행
#############################################################################################

