import tensorflow as tf
import numpy as np

hello_constant = tf.constant('Hello World!')
print(hello_constant)


x = tf.constant(9)
y = tf.constant(2)
z = x/y
w = z-1

print([x])
print([y])
print([z])
print(w)


X = np.arange(-5,5,0.25)
Y = np.arange(-5,5,0.25)
X, Y = np.meshgrid(X,Y)
R = np.sqrt(X**2 + Y**2)
Z = np.sin(R)

import matplotlib.pyplot as plt
fig = plt.figure(figsize=(5,5))
plt.contourf(X,Y,Z, cmap='coolwarm')
plt.grid()
plt.axis('equal')
plt.show()

