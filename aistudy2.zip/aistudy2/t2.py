import tensorflow as tf
import numpy as np

x = tf.Variable(10, dtype=tf.int32)
y = tf.Variable(2, dtype=tf.int32)
z = x+y
print(z)

# Square / Pow

# Constant
x = tf.constant(4.0)
z = tf.math.square(x)
print(z)

# Variable
x = tf.Variable(4.0)
z = tf.math.square(x)
print(z)

# power
# Constant
x = tf.constant(4.0)
z = tf.math.pow(x,3)
print(z)

# Variable
x = tf.Variable(4.0)
z = tf.math.pow(x,3)
print(z)


print('Squared Diff')

# Constant
x = tf.constant(4.0)
y = tf.constant(1.0)
z = tf.math.squared_difference(x,y)
print(z)

# Variable
x = tf.Variable(4.0)
y = tf.Variable(1.0)
z = tf.math.squared_difference(x,y)
print(z)



# reduction
# constant
x = tf.constant([1,2,3,4,5,6,7,8,9,10])
y = tf.math.reduce_min(x)
z = tf.math.reduce_max(x)
print([y.numpy(), z.numpy()])

x = tf.Variable([1,2,3,4,5,6,7,8,9,10])
y = tf.math.reduce_min(x)
z = tf.math.reduce_max(x)
print([y.numpy(), z.numpy()])


# constant
x = tf.constant([1,2,3,4,5,6,7,8,9,10], dtype=tf.float64)
y = tf.math.reduce_sum(x)
z = tf.math.reduce_mean(x)
print([y.numpy(), z.numpy()])

x = tf.Variable([1.0,2,3,4,5,6,7,8,9,10])
y = tf.math.reduce_sum(x)
z = tf.math.reduce_mean(x)
print([y.numpy(), z.numpy()])




