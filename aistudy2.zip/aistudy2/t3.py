import tensorflow as tf
import keras

print(tf.__version__)
print(keras.__version__)


from keras import layers

model = keras.Sequential()
model.add(layers.Dense(16))
model.add(layers.Dense(8))
model.add(layers.Dense(2))

x = tf.ones((1,4))
y=model(x)
print(y.numpy())


