#############################################################################################
# HSV 색상 좌표계                                                             <hsvscope.py>
#
# HSV 색상 좌표계를 이해하기 쉽도록 합니다.
#
# 이미지에서 원하는 색상의 이미지를 구하기 위하여  2 개의 Hue 값, Saturation, Value 값을 
# 설정하여 마스크 이미지를 만들고 원래의 이미지와  Bitwise AND 연산하여 추출한 이미지를 디스프레이 합니다.
#
# Hue 값의 범위: 0~179
# Saturation 값의 범위: 0~255
# Value 값의 범위: 0~255
#
# 마우스 왼쪽 버튼을 누르면 객체 값 설정 모드가 되며 가장 가까운 객체가 선택됩니다.
#
# Hue Lead Angle 객체
# Hue Tail Angle 객체
# Saturation 객체
# Value 객체
# 
# 마우스를 천천히 이동하면 객체 위치가 변경됩니다.
# 4 개의 HSV 파라메터에 따라 마스크 가 만들어지며 
# 마우스 오른쪽 버튼을 한번 더 누르거나 오른쪽 마우스 버튼을 누르면 객체 선택 모드가 해지 됩니다.
#
# 2023-12-03
#
# SAMPLE Electronics co.                                        
# http://www.ArduinoPLUS.cc                                     
#                                                               
# Library Import ============================================================================
import numpy as np          # 이미지 배열 생성(OpenCV 에서 사용) 라이브러리
import cv2                  # 영상처리(OpenCV) 라이브러리 
from math import sin, cos, atan2, sqrt, pi
from operator import itemgetter
# Constant ----------------------------------------------------------------------------------
RED     =   0,  0,255       # Red
GREEN   =   0,255,  0       # Green
BLUE    = 255,  0,  0       # Blue
PINK    = 255,  0,255       # Pink
MAGENTA = 255,255,  0       # Magenta(Sky Blue)
YELLOW  =   0,255,255       # Yellow
WHITE   = 255,255,255       # White
GRAY    =  32, 32, 32       # Gray
BLACK   =   0,  0,  0       # Black
#--------------------------------------------------------------------------------------------
outCirDia = 135             # Lead 객체와 Tail 객체를 연결하는 외곽 원 반지름
centerX = 400               # HSV 기준원 중심 X좌표
centerY = 340               # HSV 기준원 중심 Y좌표
mouseX = centerX            # 마우스 X좌표
mouseY = centerY            # 마우스 Y좌표
mouseButtenLeft = False     # 마우스 왼쪽 버튼
mouseButtenToggle = False   # 마우스 오른쪽 버튼
SIZE_EQU = True             # 디스프레이 모드
#--------------------------------------------------------------------------------------------
viewWin = np.zeros((480,800,3),np.uint8)  # 표시되는 윈도우 가로, 세로, 컬러층, 8비트
cir = cv2.imread('cirh256.png',cv2.IMREAD_COLOR)      # Hue 원 이미지 읽기
y, x, _ = cir.shape                                   # 이미지의 크기
cirHueImgSizeY = int(y/2); cirHueImgSizeX = int(x/2)  # 이미지 세로 크기, 가로 크기 
camera = cv2.VideoCapture(0,cv2.CAP_V4L)              # 카메라 객체 생성
camera.set(3,640)                                     # 카메라 영상 X 크기
camera.set(4,480)                                     # 카메라 영상 Y 크기
#--------------------------------------------------------------------------------------------
cv2.namedWindow('Out',cv2.WND_PROP_FULLSCREEN)
cv2.setWindowProperty('Out', cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
# Mouse Callback Function -------------------------------------------------------------------
def controlMain(event,x,y,flags,param):
    '''
    마우스 이벤트 발생시 처리되는 함수 입니다.
    3 개의 마우스 버튼 Up/Down 이벤트와 X,Y 이동 이벤트를 처리합니다.
    '''
    global mouseX, mouseY, mouseButtenLeft, mouseButtenToggle
    
    mouseX = x; mouseY = y              # 마우스 좌표값 X, Y를 전역변수 mouseX, mouseY에 저장

    if event == cv2.EVENT_LBUTTONDOWN:  # print('L-Down') # 마우스 왼쪽 버튼 이벤트 발생
        mouseButtenLeft = True
    if event == cv2.EVENT_RBUTTONDOWN:  # print('R-Down') # 마우스 오른쪽 버튼 이벤트 발생
        mouseButtenToggle = False
    '''
    if event == cv2.EVENT_LBUTTONUP:    # print('L-Up') # 마우스 왼쪽 버튼 이벤트 발생
    if event == cv2.EVENT_RBUTTONUP:    # print('R-Up') # 마우스 오른쪽 버튼 이벤트 발생
    if event == cv2.EVENT_MBUTTONDOWN:  # print('C-Down') # 마우스 가운데 버튼 이벤트 발생
    if event == cv2.EVENT_MBUTTONUP:    # print('C-Up') # 마우스 가운데 버튼 이벤트 발생
    '''
#--------------------------------------------------------------------------------------------
def angle360(centerX,centerY,mouseX,mouseY):
    '''
    좌표 값을 받아 360 분법의 각도 값을 구하고 정수형으로 반환합니다.
    '''
    d = -(180/pi)*atan2(mouseY-centerY,mouseX-centerX)
    if d<0: d = 360+d
    return (int(d))
#--------------------------------------------------------------------------------------------
def valueBox(hue, width=50):
    '''
    hue 값을 받아 256 그레이드의 value 값이 표현되는 박스 이미지를 만듭니다.
    saturation 값은 255 으로 고정입니다.
    반환되는 박스 이미지의 크기는 width 값을 지정하지 않으면 가로는 50 pixel 이며 
    세로는 256 pixel 고정 입니다.
    hue 값의 범위는 0-179 입니다.
    '''
    hue %= 180                       # 휴값 최대 
    value_steps = 256                # 밸류값 최대 (사각형 Height)
    saturation = 255                 # 채도값 최대
    # HSV 이미지 생성
    hsv_image = np.zeros((value_steps, width, 3), dtype=np.uint8)
    hsv_image[..., 0] = hue          # hue 값 입력 (0 번층)
    hsv_image[..., 1] = saturation   # saturation 값 설정 (1 번층) 
    hsv_image[..., 2] = np.tile(np.arange(255, -1, -1).reshape(-1, 1), (1, width)) # value 값 설정  (2 번층)
    bgr_image = cv2.cvtColor(hsv_image, cv2.COLOR_HSV2BGR)
    return(bgr_image)
# Main Loop =================================================================================
def main():

    global mouseButtenLeft, mouseButtenToggle, SIZE_EQU

    # Red -----------------------------------------------------------------------------------
    lineLeadAngRED = 40 # (60-1)                     # 시작(Lead) 라인 각도(/360)
    lineLeadREDX = 0                            # 시작(Lead) 라인과 외곽 원 교차 X 좌표
    lineLeadREDY = 0                            # 시작(Lead) 라인과 외곽 원 교차 Y 좌표
    lineTailAngRED = 300 #(240+1)                    # 종료(Tail) 라인 각도(/360)
    lineTailREDX = 0                            # 종료(Tail) 라인과 외곽 원 교차 X 좌표
    lineTailREDY = 0                            # 종료(Tail) 라인과 외곽 원 교차 Y 좌표
    saturationHalfRED = 50                      # Saturation 반지름 값 (/128)

    HSV_hueLeadRED = int(lineLeadAngRED/2)      # HSV 색상 좌표계에서 시작(Lead) 라인 각도(/180)
    HSV_hueTailRED = int(lineTailAngRED/2)      # HSV 색상 좌표계에서 종료(Tail) 라인 각도(/180)
    HSV_saturationRED = saturationHalfRED*2     # HSV 색상 좌표계에서 Saturation(/256)
    HSV_valueRED = 50                           # HSV 색상 좌표계에서 Value(/256)

    # Green ---------------------------------------------------------------------------------
    lineLeadAngGREEN = 200 #(240-1)                  # 시작(Lead) 라인 각도(/360)
    lineLeadGREENX = 0                          # 시작(Lead) 라인과 외곽 원 교차 X 좌표
    lineLeadGREENY = 0                          # 시작(Lead) 라인과 외곽 원 교차 Y 좌표
    lineTailAngGREEN = 90 #(60+1)                   # 종료(Tail) 라인 각도(/360)
    lineTailGREENX = 0                          # 종료(Tail) 라인과 외곽 원 교차 X 좌표
    lineTailGREENY = 0                          # 종료(Tail) 라인과 외곽 원 교차 Y 좌표
    saturationHalfGREEN = 50                    # Saturation 반지름 값 (/128)

    HSV_hueLeadGREEN = int(lineLeadAngGREEN/2)  # HSV 색상 좌표계에서 시작(Lead) 라인 각도(/180)
    HSV_hueTailGREEN = int(lineTailAngGREEN/2)  # HSV 색상 좌표계에서 종료(Tail) 라인 각도(/180)
    HSV_saturationGREEN = saturationHalfGREEN*2 # HSV 색상 좌표계에서 Saturation(/256)
    HSV_valueGREEN = 50                         # HSV 색상 좌표계에서 Value(/256)

    GARO_RED = 100                              # 0~255 이며 작은수에서 가로가 크게 된다.
    SERO_RED = 50                               # 0~255 이며 큰 수에서 세로가 높아 진다.
    GARO_GREEN = 100                            # 0~255 이며 작은수에서 가로가 크게 된다.
    SERO_GREEN = 50                             # 0~255 이며 큰 수에서 세로가 높아 진다.

    CIRCLE_X = 400                              # 신호등 원 최대/최소 크기 설정용 X 좌표
    CIRCLE_Y = 60                               # 신호등 원 최대/최소 크기 설정용 Y 좌표

    MAX_RADIUS = 38                             # 신호등의 최대 반지름(상수값)
    MIN_RADIUS = 8                              # 신호등의 작은 반지름(상수값)
    
    maxRadius = 9                               # 원 검출 조건(최대 반지름)
    minRadius = 8                               # 원 검출 조건(최소 반지름)


    # Object 리스트에 4 개의 객체 이름과 마우스와의 거리 정보(루트 연산 안한 값)가 들어 갑니다. 
    objectList = [['hueLeadRED',0],['hueTailRED',0],['saturationRED',0],['valueRED',0],
                  ['hueLeadGREEN',0],['hueTailGREEN',0],['saturationGREEN',0],['valueGREEN',0],
                  ['BOX_RED',0],['BOX_GREEN',0],['CIRCLE_MAX',0],['CIRCLE_MIN',0]]

    selectedObject = None     # 마우스 왼쪽 버튼에 의하여 선택된 객체

    while True:

        viewWin[:] = BLACK
        # HUE 원을 중앙에 배치
        viewWin[centerY-cirHueImgSizeY:centerY+cirHueImgSizeY,centerX-cirHueImgSizeX:centerX+cirHueImgSizeX] = cir

        _, frame = camera.read()    # 카메라 영상 입력

        # BGR 색상 좌표계를 HSV 색상 좌표계로 변환  
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Red -------------------------------------------------------------------------------
        # RED Lead Angle 객체 좌표 - 반지름 135 인 원과 Lead Angle 라인 교차 좌표값
        lineLeadREDX = centerX+int(135*cos(lineLeadAngRED*pi/180.0))
        lineLeadREDY = centerY-int(135*sin(lineLeadAngRED*pi/180.0)) 
        # RED Tail Angle 객체 좌표 - 반지름 135 인 원과 Tail Angle 라인 교차 좌표값
        lineTailREDX = centerX+int(135*cos(lineTailAngRED*pi/180.0))
        lineTailREDY = centerY-int(135*sin(lineTailAngRED*pi/180.0))
        # RED SaturationHalf 을 반지름으로 원과 Lead각, Tail각 교차 좌표값
        lineLeadSatREDX = centerX+int(saturationHalfRED*cos(lineLeadAngRED*pi/180.0))
        lineLeadSatREDY = centerY-int(saturationHalfRED*sin(lineLeadAngRED*pi/180.0)) 
        lineTailSatREDX = centerX+int(saturationHalfRED*cos(lineTailAngRED*pi/180.0))
        lineTailSatREDY = centerY-int(saturationHalfRED*sin(lineTailAngRED*pi/180.0))
        # RED Saturation 객체 좌표
        if lineLeadAngRED >= lineTailAngRED:
            a = ((lineLeadAngRED+lineTailAngRED)/2)%360
        else:
            a = ((lineLeadAngRED+lineTailAngRED)/2+180)%360
        saturationREDX = centerX+int(saturationHalfRED*cos(a*pi/180.0))
        saturationREDY = centerY-int(saturationHalfRED*sin(a*pi/180.0)) 
        # RED Value 객체 좌표
        valueREDX = 765
        valueREDY = 210+256-HSV_valueRED

        # Green -----------------------------------------------------------------------------
        # GREEN Lead Angle 객체 좌표 - 반지름 135 인 원과 Lead Angle 라인 교차 좌표값
        lineLeadGREENX = centerX+int(135*cos(lineLeadAngGREEN*pi/180.0))
        lineLeadGREENY = centerY-int(135*sin(lineLeadAngGREEN*pi/180.0)) 
        # GREEN Tail Angle 객체 좌표 - 반지름 135 인 원과 Tail Angle 라인 교차 좌표값
        lineTailGREENX = centerX+int(135*cos(lineTailAngGREEN*pi/180.0))
        lineTailGREENY = centerY-int(135*sin(lineTailAngGREEN*pi/180.0))
        # GREEN SaturationHalf 을 반지름으로 원과 Lead각, Tail각 교차 좌표값
        lineLeadSatGREENX = centerX+int(saturationHalfGREEN*cos(lineLeadAngGREEN*pi/180.0))
        lineLeadSatGREENY = centerY-int(saturationHalfGREEN*sin(lineLeadAngGREEN*pi/180.0)) 
        lineTailSatGREENX = centerX+int(saturationHalfGREEN*cos(lineTailAngGREEN*pi/180.0))
        lineTailSatGREENY = centerY-int(saturationHalfGREEN*sin(lineTailAngGREEN*pi/180.0))
        # GREEN Saturation 객체 좌표
        if lineLeadAngGREEN >= lineTailAngGREEN:
            a = ((lineLeadAngGREEN+lineTailAngGREEN)/2)%360
        else:
            a = ((lineLeadAngGREEN+lineTailAngGREEN)/2+180)%360
        saturationGREENX = centerX+int(saturationHalfGREEN*cos(a*pi/180.0))
        saturationGREENY = centerY-int(saturationHalfGREEN*sin(a*pi/180.0)) 
        # GREEN Value 객체 좌표
        valueGREENX = 35
        valueGREENY = 210+256-HSV_valueGREEN

        objectList[0][1] = (lineLeadREDX-mouseX)*(lineLeadREDX-mouseX)+(lineLeadREDY-mouseY)*(lineLeadREDY-mouseY)
        objectList[1][1] = (lineTailREDX-mouseX)*(lineTailREDX-mouseX)+(lineTailREDY-mouseY)*(lineTailREDY-mouseY)
        objectList[2][1] = (saturationREDX-mouseX)*(saturationREDX-mouseX)+(saturationREDY-mouseY)*(saturationREDY-mouseY)
        objectList[3][1] = (valueREDX-mouseX)*(valueREDX-mouseX)+(valueREDY-mouseY)*(valueREDY-mouseY)
        objectList[4][1] = (lineLeadGREENX-mouseX)*(lineLeadGREENX-mouseX)+(lineLeadGREENY-mouseY)*(lineLeadGREENY-mouseY)
        objectList[5][1] = (lineTailGREENX-mouseX)*(lineTailGREENX-mouseX)+(lineTailGREENY-mouseY)*(lineTailGREENY-mouseY)
        objectList[6][1] = (saturationGREENX-mouseX)*(saturationGREENX-mouseX)+(saturationGREENY-mouseY)*(saturationGREENY-mouseY)
        objectList[7][1] = (valueGREENX-mouseX)*(valueGREENX-mouseX)+(valueGREENY-mouseY)*(valueGREENY-mouseY)
        objectList[8][1] = (80+370+GARO_RED-mouseX)*(80+370+GARO_RED-mouseX)+(68+400-SERO_RED-mouseY)*(68+400-SERO_RED-mouseY)
        objectList[9][1] = (80+14+GARO_GREEN-mouseX)*(80+14+GARO_GREEN-mouseX)+(68+400-SERO_GREEN-mouseY)*(68+400-SERO_GREEN-mouseY)
        objectList[10][1] = (CIRCLE_X-maxRadius-mouseX)*(CIRCLE_X-maxRadius-mouseX)+(CIRCLE_Y-mouseY)*(CIRCLE_Y-mouseY)
        objectList[11][1] = (CIRCLE_X+minRadius-mouseX)*(CIRCLE_X+minRadius-mouseX)+(CIRCLE_Y-mouseY)*(CIRCLE_Y-mouseY)

        #------------------------------------------------------------------------------------
        if mouseButtenLeft:
            selectedObject = sorted(objectList,key=itemgetter(1))[0][0] # 마우스와 최 단거리 객체
            mouseButtenToggle = not mouseButtenToggle
            mouseButtenLeft = False                                     # 원 슈트(One Shoot)

        if mouseButtenToggle:

            # Red ---------------------------------------------------------------------------
            if selectedObject=='valueRED':                # HSV Value
                v = (210+256)-mouseY
                if 0<=v and v<256:
                    HSV_valueRED = v                      # 0~255
            elif selectedObject=='saturationRED':         # HSV Saturation
                s = int(sqrt((mouseX-centerX)*(mouseX-centerX)+(mouseY-centerY)*(mouseY-centerY))) # circle 중심으로 부터 mouse 거리
                if 0<= s and s < 128:
                    saturationHalfRED = s
                    HSV_saturationRED = saturationHalfRED*2  # HSV Saturation은 0~255 까지
            elif selectedObject=='hueLeadRED':            # RED 시작 각도 객체 
                a = angle360(centerX,centerY,mouseX,mouseY)  
                if a < 60 and a > lineTailAngRED:         # Case 1: 0<L,T<60
                    lineLeadAngRED = a
                elif lineTailAngRED > 240 and a > lineTailAngRED:   # Case 2: 240<L,T<360
                    lineLeadAngRED = a
                elif a < 60 and lineTailAngRED > 240:     # Case 3: L<60, T>240
                    lineLeadAngRED = a
            elif selectedObject=='hueTailRED':            # RED 종료 각도 객체
                a = angle360(centerX,centerY,mouseX,mouseY)  
                if lineLeadAngRED < 60 and a < lineLeadAngRED:      # Case 1: 0<L,T<60
                    lineTailAngRED = a
                elif a > 240 and a < lineLeadAngRED:      # Case 2: 240<L,T<360
                    lineTailAngRED = a
                elif lineLeadAngRED < 60 and a > 240:     # Case 3: L<60, T>240
                    lineTailAngRED = a
            elif selectedObject=='BOX_RED':
                a = mouseX - (80+370)
                if 0 < a < 256: GARO_RED = a 
                a = (68+400) - mouseY
                if 0 < a < 256: SERO_RED = a

            # Green -------------------------------------------------------------------------
            elif selectedObject=='valueGREEN':                # HSV Value
                v = (210+256)-mouseY
                if 0<=v and v<256:
                    HSV_valueGREEN = v                      # 0~255
            elif selectedObject=='saturationGREEN':         # HSV Saturation
                s = int(sqrt((mouseX-centerX)*(mouseX-centerX)+(mouseY-centerY)*(mouseY-centerY))) # circle 중심으로 부터 mouse 거리
                if 0<= s and s < 128:
                    saturationHalfGREEN = s
                    HSV_saturationGREEN = saturationHalfGREEN*2  # HSV Saturation은 0~255 까지
            elif selectedObject=='hueLeadGREEN':            # 마우스의 위치(원 중심으로 부터)에따른 시작선 각도
                a = angle360(centerX,centerY,mouseX,mouseY)  
                if a < 240 and a > lineTailAngGREEN: lineLeadAngGREEN = a
            elif selectedObject=='hueTailGREEN':            # 마우스의 위치(원 중심으로 부터)에따른 종료선 각도
                a = angle360(centerX,centerY,mouseX,mouseY)  
                if a > 60 and a < lineLeadAngGREEN: lineTailAngGREEN = a
            elif selectedObject=='BOX_GREEN':
                a = mouseX - (80+14)
                if 0 < a < 256: GARO_GREEN = a 
                a = (68+400) - mouseY
                if 0 < a < 256: SERO_GREEN = a
            #--------------------------------------------------------------------------------
            elif selectedObject=='CIRCLE_MAX':
                a = CIRCLE_X - mouseX
                if minRadius < a <= MAX_RADIUS:
                    maxRadius = a

            elif selectedObject=='CIRCLE_MIN':
                a = mouseX - CIRCLE_X
                if MIN_RADIUS <= a < maxRadius:
                    minRadius = a

        # RED -------------------------------------------------------------------------------
        cv2.line(viewWin,(lineLeadSatREDX,lineLeadSatREDY),(lineLeadREDX,lineLeadREDY),BLACK,1,cv2.LINE_AA)
        cv2.line(viewWin,(lineTailSatREDX,lineTailSatREDY),(lineTailREDX,lineTailREDY),BLACK,1,cv2.LINE_AA)

        if lineLeadAngRED >= lineTailAngRED:                     # 두 각이 동일한 영역에 있을 때이며 외곽원 Green 
            centerHueRED = int((lineLeadAngRED+lineTailAngRED)/4)   # 두 각의 중간값(360도 원)각을 구하고 다시 180 원 값을 구한다.
        else:                                          # 두 각이 교차 영역에 있을 때이며 외곽원 Red
            centerHueRED = (int((lineLeadAngRED+lineTailAngRED)/4)+90)%180   # 두 각의 중간값(360도 원)각을 구하고 다시 180 원 값을 구한다.

        viewWin[210:210+256,740:740+50]=valueBox(centerHueRED)         # RED Value Box 디스프레이
        cv2.rectangle(viewWin,(740,210),(740+50,210+256),YELLOW,1)     # RED Value Box 외곽선
        cv2.line(viewWin,(740,210+256-HSV_valueRED),(740+50,210+256-HSV_valueRED),WHITE,1) # RED Value 레벨

        # RED Lead Angle 객체 위치 디스프레이 
        cv2.circle(viewWin,(lineLeadREDX,lineLeadREDY),8,RED,-1)
        # RED Tail Angle 객체 위치 디스프레이
        cv2.circle(viewWin,(lineTailREDX,lineTailREDY),8,GREEN,-1)
        # RED Saturation 객체 위치 디스프레이
        cv2.circle(viewWin,(saturationREDX,saturationREDY),8,BLACK,-1)
        # RED Value 객체 위치 디스프레이
        cv2.circle(viewWin,(valueREDX, valueREDY),8,WHITE,-1)
        # RED box 객체 위치 디스프레이
        cv2.circle(viewWin,(80+370+GARO_RED,68+400-SERO_RED),8,WHITE,-1)
        # RED 신호등 판단 BOX 디스프레이 
        cv2.rectangle(viewWin,(80+370+GARO_RED,68+400-SERO_RED),(80+370+256,68+400),RED,1) # Red 신호등 판단 
        # RED 신호등 그래프 베이스 바
        viewWin[68+402:68+404,80+370+0:80+370+256+2] = RED     # Red 베이스 바 (히스토그램 영역 표시)

        # GREEN -----------------------------------------------------------------------------
        cv2.line(viewWin,(lineLeadSatGREENX,lineLeadSatGREENY),(lineLeadGREENX,lineLeadGREENY),BLACK,1,cv2.LINE_AA)
        cv2.line(viewWin,(lineTailSatGREENX,lineTailSatGREENY),(lineTailGREENX,lineTailGREENY),BLACK,1,cv2.LINE_AA)

        centerHueGREEN = int((lineLeadAngGREEN+lineTailAngGREEN)/4)   # 두 각의 중간값(360도 원)각을 구하고 다시 180 원 값을 구한다.
        viewWin[210:210+256,10:10+50]=valueBox(centerHueGREEN)     # GREEN Value Box 디스프레이
        cv2.rectangle(viewWin,(10,210),(10+50,210+256),YELLOW,1)   # GREEN Value Box 외곽선
        cv2.line(viewWin,(10,210+256-HSV_valueGREEN),(10+50,210+256-HSV_valueGREEN),WHITE,1) # GREEN Value 레벨

        # GREEN Lead Angle 객체 위치 디스프레이 
        cv2.circle(viewWin,(lineLeadGREENX,lineLeadGREENY),8,RED,-1)
        # GREEN Tail Angle 객체 위치 디스프레이
        cv2.circle(viewWin,(lineTailGREENX,lineTailGREENY),8,GREEN,-1)
        # GREEN Saturation 객체 위치 디스프레이
        cv2.circle(viewWin,(saturationGREENX,saturationGREENY),8,BLACK,-1)
        # GREEN Value 객체 위치 디스프레이
        cv2.circle(viewWin,(valueGREENX, valueGREENY),8,WHITE,-1)
        # GREEN box 객체 위치 디스프레이
        cv2.circle(viewWin,(80+14+GARO_GREEN,68+400-SERO_GREEN),8,WHITE,-1)
        # GREEN 신호등 판단 BOX 디스프레이
        cv2.rectangle(viewWin,(80+14+GARO_GREEN,68+400-SERO_GREEN),(80+14+256,68+400),GREEN,1)  # Green 신호등 판단 
        # GREEN 신호등 그래프 베이스 바
        viewWin[68+402:68+404,80+14+0:80+14+256+2] = GREEN     # Green 베이스 바 (히스토그램 영역 표시)

        # -----------------------------------------------------------------------------------
        # 신호등 최대 원 객체 디스프레이
        cv2.circle(viewWin,(CIRCLE_X-maxRadius,CIRCLE_Y),8,MAGENTA,-1)    # 원의 왼쪽에 객체 표시
        # 신호등 최소 원 객체 디스프레이
        cv2.circle(viewWin,(CIRCLE_X+minRadius,CIRCLE_Y),8,YELLOW,-1)     # 원의 오른쪽에 객체 표시

        cv2.circle(viewWin,(CIRCLE_X,CIRCLE_Y),maxRadius,MAGENTA,1)  # 신호등 최대 크기
        cv2.circle(viewWin,(CIRCLE_X,CIRCLE_Y),minRadius,YELLOW,1)   # 신호등 최소 크기


        # RED Mask --------------------------------------------------------------------------
        if lineLeadAngRED >= lineTailAngRED:                     # 두 각이 동일한 영역에 있을 때이며 외곽원 Green 
            centerHueRED = int((lineLeadAngRED+lineTailAngRED)/4)   # 두 각의 중간값(360도 원)각을 구하고 다시 180 원 값을 구한다.
            cv2.ellipse(viewWin,(centerX,centerY),(outCirDia,outCirDia),0,-lineLeadAngRED,-lineTailAngRED,GREEN,3,cv2.LINE_AA)
            cv2.ellipse(viewWin,(centerX,centerY),(saturationHalfRED,saturationHalfRED),0,-lineLeadAngRED,-lineTailAngRED,BLACK,1,cv2.LINE_AA)

            upper_color = np.array([HSV_hueLeadRED,255,255])                   # Upper
            lower_color = np.array([HSV_hueTailRED,HSV_saturationRED,HSV_valueRED])  # Lower
            mask = cv2.inRange(hsv, lower_color, upper_color)                # 단일 구간 마스크
        else:                                          # 두 각이 교차 영역에 있을 때이며 외곽원 Red
            centerHueRED = (int((lineLeadAngRED+lineTailAngRED)/4)+90)%180   # 두 각의 중간값(360도 원)각을 구하고 다시 180 원 값을 구한다.
            cv2.ellipse(viewWin,(centerX,centerY),(outCirDia,outCirDia),0,-lineLeadAngRED,0,RED,3,cv2.LINE_AA)
            cv2.ellipse(viewWin,(centerX,centerY),(saturationHalfRED,saturationHalfRED),0,-lineLeadAngRED,0,BLACK,1,cv2.LINE_AA)

            cv2.ellipse(viewWin,(centerX,centerY),(outCirDia,outCirDia),0,-lineTailAngRED,-360,RED,3,cv2.LINE_AA)
            cv2.ellipse(viewWin,(centerX,centerY),(saturationHalfRED,saturationHalfRED),0,-lineTailAngRED,-360,BLACK,1,cv2.LINE_AA)
        
            upper_color = np.array([HSV_hueLeadRED,255,255])             
            lower_color = np.array([0,HSV_saturationRED,HSV_valueRED]) # 최소 0
            maskL = cv2.inRange(hsv, lower_color, upper_color)         # Lead Mask

            upper_color = np.array([179,255,255])                      # 최대 179
            lower_color = np.array([HSV_hueTailRED,HSV_saturationRED,HSV_valueRED])  
            maskT = cv2.inRange(hsv, lower_color, upper_color)         # Tail Mask

            mask = cv2.bitwise_or(maskL, maskT)                        # L 와 T 마스크를 OR 연산  
        # GREEN Mask 동일 영역에서 Lead 각과 Tail 각이 존재 --------------------------------------
        centerHueGREEN = int((lineLeadAngGREEN+lineTailAngGREEN)/4)   # 두 각의 중간값(360도 원)각을 구하고 다시 180 원 값을 구한다.
        cv2.ellipse(viewWin,(centerX,centerY),(outCirDia,outCirDia),0,-lineLeadAngGREEN,-lineTailAngGREEN,GREEN,3,cv2.LINE_AA)
        cv2.ellipse(viewWin,(centerX,centerY),(saturationHalfGREEN,saturationHalfGREEN),0,-lineLeadAngGREEN,-lineTailAngGREEN,BLACK,1,cv2.LINE_AA)

        upper_color = np.array([HSV_hueLeadGREEN,255,255])                   # Upper
        lower_color = np.array([HSV_hueTailGREEN,HSV_saturationGREEN,HSV_valueGREEN])  # Lower
        mask = cv2.inRange(hsv, lower_color, upper_color)                # 단일 구간 마스크
        #------------------------------------------------------------------------------------ 

        res = cv2.bitwise_and(frame,frame,mask=mask)    # 원 이미지와 마스크 이미지의 AND 처리
        maskC = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)  # 1 Layer(흙백) 마스크를 3 Layer(컬러)로 변환


        if SIZE_EQU:
            viewWin[0+0:0+200,0+0:0+266] = cv2.resize(frame, dsize=(266,200), interpolation=cv2.INTER_LINEAR) # 원본 디스프레이
            #viewWin[0+0:0+200,0+266+1:0+266+1+266] = cv2.resize(maskC, dsize=(266,200), interpolation=cv2.INTER_LINEAR) # 마스크 디스프레이
            viewWin[0+0:0+200,0+266+1+266+1+0:0+266+1+266+1+266] = cv2.resize(res, dsize=(266,200), interpolation=cv2.INTER_LINEAR) # 결과 디스프레이
            cv2.putText(viewWin,'HSV Scope',(100,290),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,MAGENTA)
            cv2.putText(viewWin,f'Hue(Lead): {HSV_hueLeadRED}/180',(100,320),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,PINK)
            cv2.putText(viewWin,f'Hue(Tail): {HSV_hueTailRED}/180',(100,340),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,PINK)
            cv2.putText(viewWin,f'Saturation: {HSV_saturationRED}/256',(100,360),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,PINK)
            cv2.putText(viewWin,f'Value: {HSV_valueRED}/256',(100,380),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,PINK)
            cv2.putText(viewWin,'[View mode] [eXit]',(100,410),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,YELLOW)

            cv2.rectangle(viewWin,(0+0,0+0),(0+266,0+200),YELLOW,1)
            cv2.rectangle(viewWin,(0+266+1,0+0),(0+266+1+266,0+200),YELLOW,1)
            cv2.rectangle(viewWin,(0+266+1+266+1+0,0+0),(0+266+1+266+1+266-1,0+200),YELLOW,1)


        #------------------------------------------------------------------------------------
        cv2.imshow('Out', viewWin)           # 이미지를 LCD에 표시
        #------------------------------------------------------------------------------------
        keyBoard = cv2.waitKey(1) & 0xFF     # 키보드 입력
        if keyBoard == ord('v') or keyBoard == ord('V'): 
            SIZE_EQU = not SIZE_EQU
        if keyBoard == 0x1B or keyBoard == 0x09 or keyBoard == ord('x') or keyBoard == ord('X'):
            break                            # ESC / TAB / 'x' 프로그램 종료

# Mouse Event -------------------------------------------------------------------------------
cv2.namedWindow('Out')                               # 윈도우 창을 생성
cv2.setMouseCallback('Out', controlMain, viewWin)    # 마우스 제어 설정
#--------------------------------------------------------------------------------------------
main()                                               # HSV 메인 프로그램 실행
#--------------------------------------------------------------------------------------------
camera.release()                                     # 카메라 자원을 반납
cv2.destroyAllWindows()                              # 열려 있는 모든 윈도우를 닫기
#############################################################################################

