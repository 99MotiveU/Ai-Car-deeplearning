#############################################################################################
# Traffic Signal Tower                                                  <tst.py>
#
# 신호등을 설정합니다. 
#
# 빨간색, 녹색, 노란색 신호등에 대하여 크기(원 지름), 형태(진원/타원), 색상값(Value), 
# 위치를 설정할 수 있습니다.
#
# 프로그램 기동시 클리어 모드로 동작합니다.
# 설정 모드로 동작하려면 마우스 오른 쪽 버튼을 클릭합니다.
# 
# 객체 기준점을 마우스 왼쪽 버튼으로 선택하면 객체가 선택되고 객체 색상이 힌색으로 변합니다.
# 마우스를 움직여 적정한 값을 설정합니다.
# 마우스 왼쪽 버튼 또는 오른쪽 버튼을 클릭하면 객체선택 해지 됩니다.
#
# [X] : Shut Down(Power Off) 합니다.
# [S] : System OS 로 돌아갑니다.
# [C] : 화면을 클리어 합니다. 마우스 오른쪽 버튼을 누르면 설정 모드로 전환됩니다.
#
# 마우스로 [X] 객체를 선택하면 Raspberry Power Off (Sut Down) 됩니다.
# 시스템 OS 로 돌아가기 원하면 'X', 또는 'ESC' 를 입력합니다.
#
#
#
#
# 2024-01-01
#
# SAMPLE Electronics co.                                        
# http://www.ArduinoPLUS.cc                                     
#                                                               
# Library Import ============================================================================
import os                   # 
import numpy as np          # 이미지 배열 생성(OpenCV 에서 사용) 라이브러리
import cv2                  # 영상처리(OpenCV) 라이브러리 
import pickle               # python 객채 압축/복원 라이브러리 pickle
import subprocess
#from time import sleep 
from operator import itemgetter
# Constant ----------------------------------------------------------------------------------
RED     =   0,  0,255       # Red
GREEN   =   0,255,  0       # Green
BLUE    = 255,  0,  0       # Blue
MAGENTA = 255,  0,255       # Magenta(Pink)
CYAN    = 255,255,  0       # Cyan(Sky Blue)
YELLOW  =   0,255,255       # Yellow
WHITE   = 255,255,255       # White
BLACK   =   0,  0,  0       # Black
GRAY    =  96, 96, 96       # Gray
#--------------------------------------------------------------------------------------------
mouseX = 0                  # 마우스 X좌표
mouseY = 0                  # 마우스 Y좌표
mouseButtenLeft = False     # 마우스 왼쪽 버튼
mouseButtenToggle = False   # 마우스 오른쪽 버튼
selectedObject = None       # 객체 선택
SET_MODE = False            # True: 설정 모드 / False: 신호등 동작 모드
POWER_OFF = False           # 프로그램 실행 정지하고 Raspberry Pi 의 동작을 멈춥니다.
#--------------------------------------------------------------------------------------------
viewWin = np.zeros((480,800,3),np.uint8)  # 표시되는 윈도우 가로, 세로, 컬러층, 8비트
#--------------------------------------------------------------------------------------------
cv2.namedWindow('Out',cv2.WND_PROP_FULLSCREEN)
cv2.setWindowProperty('Out', cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
# Mouse Callback Function -------------------------------------------------------------------
def controlMain(event,x,y,flags,param):
    '''
    마우스 이벤트 발생시 처리되는 함수 입니다.
    3 개의 마우스 버튼 Up/Down 이벤트와 X,Y 이동 이벤트를 처리합니다.
    '''
    global mouseX, mouseY, mouseButtenLeft, mouseButtenToggle, selectedObject, SET_MODE
    
    mouseX = x; mouseY = y              # 마우스 좌표값 X, Y를 전역변수 mouseX, mouseY에 저장

    if event == cv2.EVENT_LBUTTONDOWN:  # print('L-Down') # 마우스 왼쪽 버튼 이벤트 발생
        if SET_MODE:
            mouseButtenLeft = True

    if event == cv2.EVENT_RBUTTONDOWN:  # print('R-Down') # 마우스 오른쪽 버튼 이벤트 발생
        mouseButtenToggle = False
        selectedObject = None
        if not SET_MODE: 
            SET_MODE = True
#--------------------------------------------------------------------------------------------
def constrain(value, minNum, maxNum):
    '''
    Arduino 의 constrain() 함수와 같습니다.
    value 값이 minNum 보다 작으면 minMum 을 반환하고 maxNum 보다 크면 maxNum 을 반환합니다.
    value 값이 minNum 보다 크고 maxNum 보다 작으면 value 를 그대로 반환합니다.
    '''
    if value < minNum: 
        r = minNum
    elif value > maxNum:
        r = maxNum
    else:
        r = value
    return int(r)
# Main Loop =================================================================================
def main():

    global mouseButtenLeft, mouseButtenToggle, selectedObject
    global SET_MODE, POWER_OFF

    circleRadius = 200                          # Pickle[0]
    redValueX = 255                             # Pickle[1]
    redValueY = 45                              #
    redTimeX = 50                               # Pickle[2]
    redTimeY = 115                              #
    yellowValueX = 255                          # Pickle[3]
    yellowValueY = 205                          #
    yellowTimeX = 10                            # Pickle[4]
    yellowTimeY = 275                           #
    greenValueX = 255                           # Pickle[5]
    greenValueY = 365                           #
    greenTimeX = 50                             # Pickle[6]
    greenTimeY = 435                            #
    circleCenterX = 560                         # Pickle[7]
    circleCenterY = 240                         # Pickle[8]
    cirWidth = circleRadius                     # Pickle[9] 신호등 가로 길이
    cirHeight = circleRadius                    # Pickle[10] 신호등 세로 길이

    t = 'tst.pickle'                            # 가져올 pickle 파일 이름
    if os.path.exists(t):                       # pickle 파일 있으면 읽어들임
        with open(t, 'rb') as f:
            d = pickle.load(f)           
            circleRadius=d[0]; redValueX=d[1]; redTimeX=d[2]; yellowValueX=d[3]; 
            yellowTimeX=d[4]; greenValueX=d[5]; greenTimeX=d[6]; circleCenterX=d[7]; 
            circleCenterY=d[8]; cirWidth=d[9]; cirHeight=d[10]
        
    circleRigidX = circleCenterX
    circleRigidY = circleCenterY-circleRadius

    exitX = 765; exitY = 30
    saveX = 765; saveY = 85
    clearWinX = 765; clearWinY = 450

    # Object 리스트에 11 개의 객체 이름과 객체 기준점과 마우스와의 거리 정보
    objectList = [['RED_VALUE',0],           # 빨간 신호등 Value 값
                  ['RED_TIME',0],            # 빨간 신호등 지연시간
                  ['YELLOW_VALUE',0],        # 노란 신호등 Value 값
                  ['YELLOW_TIME',0],         # 노란 신호등 지연시간 
                  ['GREEN_VALUE',0],         # 녹색 신호등 Value 값
                  ['GREEN_TIME',0],          # 녹색 신호등 지연시간
                  ['CIRCLE_CENTER',0],       # 원의 중심 좌표
                  ['CIRCLE_RIGID',0],        # Rigir Circle 가로 세로 비가 1:1 을 유지 
                  ['CIRCLE_DIAGONAL',0],     # Ellipsed Circle 가로 세로 비가 X:Y 비율
                  ['SHUT_DOWN',0],           # Shut Down (Power Off)
                  ['SYSTEM',0],                # Save Parameter
                  ['CLEAR',0]]               # Exit(Without Save Parameter)

    seqNumber = 0                            # 0:노란색, 1:녹색, 2:노란색, 3:빨간색

    redTimer = redTimeX                      # 디폴트 값으로 설정
    greenTimer = greenTimeX
    yellowTimer = yellowTimeX
    #------------------------------------------------------------------------------------
    while True:
        viewWin[:,:] = BLACK                 # 스크린 클리어
        # 신호등 시간 설정 --------------------------------------------------------------------
        if (redTimer == 0) and (greenTimer == 0) and (yellowTimer == 0): 
            if seqNumber == 0:               # YELLOW Signal
                yellowTimer = yellowTimeX*8
            elif seqNumber == 1:             # GREEN Signal
                greenTimer = greenTimeX*8
            elif seqNumber == 2:             # YELLOW Signal
                yellowTimer = yellowTimeX*8
            elif seqNumber == 3:             # RED Signal
                redTimer = redTimeX*8
            seqNumber += 1
            seqNumber %= 4
        # 신호등 점등 -------------------------------------------------------------------------
        if redTimer > 0:                # 빨간색 신호등
            redTimer -= 1  
            cv2.ellipse(viewWin,(circleCenterX,circleCenterY),(cirWidth, cirHeight),0, 0, 360,(0,0,redValueX),-1,cv2.LINE_AA)
        if greenTimer > 0:              # 녹색 신호등
            greenTimer -= 1  
            cv2.ellipse(viewWin,(circleCenterX,circleCenterY),(cirWidth, cirHeight),0, 0, 360,(0,greenValueX,0),-1,cv2.LINE_AA)
        if yellowTimer > 0:             # 노란색 신호등
            yellowTimer -= 1  
            cv2.ellipse(viewWin,(circleCenterX,circleCenterY),(cirWidth, cirHeight),0, 0, 360,(0,yellowValueX,yellowValueX),-1,cv2.LINE_AA)
        # 설정 모드 --------------------------------------------------------------------------
        if SET_MODE:
            # Red Value --------------------------------------------------------------------
            cv2.rectangle(viewWin,(20+0, 15+0),(20+256,  15+60),RED,1)     # Value Box 외곽선 45
            cv2.putText(viewWin,'Value',(20+80,15+40),cv2.FONT_HERSHEY_COMPLEX_SMALL,1.5,RED)
            cv2.putText(viewWin,f'{redValueX}',(290,45),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,RED)
            if selectedObject == 'RED_VALUE': C = WHITE
            else: C = RED
            cv2.circle(viewWin,(redValueX+20,redValueY),10,C,-1,cv2.LINE_AA)
            # Red Time ---------------------------------------------------------------------
            cv2.rectangle(viewWin,(20+0, 85+0),(20+256,  85+60),RED,1)     # Value Box 외곽선 115
            cv2.putText(viewWin,'Time',(20+80,85+40),cv2.FONT_HERSHEY_COMPLEX_SMALL,1.5,RED)
            cv2.putText(viewWin,f'{redTimeX/10:.1f}',(290,115),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,RED)
            if selectedObject == 'RED_TIME': C = WHITE
            else: C = RED
            cv2.circle(viewWin,(redTimeX+20,redTimeY),10,C,-1,cv2.LINE_AA)
            # Yellow Value ----------------------------------------------------------------
            cv2.rectangle(viewWin,(20+0,175+0),(20+256, 175+60),YELLOW,1)  # Value Box 외곽선 205
            cv2.putText(viewWin,'Value',(20+80,175+40),cv2.FONT_HERSHEY_COMPLEX_SMALL,1.5,YELLOW)
            cv2.putText(viewWin,f'{yellowValueX}',(290,205),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,YELLOW)
            if selectedObject == 'YELLOW_VALUE': C = WHITE
            else: C = YELLOW
            cv2.circle(viewWin,(yellowValueX+20,yellowValueY),10,C,-1,cv2.LINE_AA)
            # Yellow Time -----------------------------------------------------------------
            cv2.rectangle(viewWin,(20+0,245+0),(20+256, 245+60),YELLOW,1)  # Value Box 외곽선 275
            cv2.putText(viewWin,'Time',(20+80,245+40),cv2.FONT_HERSHEY_COMPLEX_SMALL,1.5,YELLOW)
            cv2.putText(viewWin,f'{yellowTimeX/10:.1f}',(290,275),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,YELLOW)
            if selectedObject == 'YELLOW_TIME': C = WHITE
            else: C = YELLOW
            cv2.circle(viewWin,(yellowTimeX+20,yellowTimeY),10,C,-1,cv2.LINE_AA)
            # Green Value -----------------------------------------------------------------
            cv2.rectangle(viewWin,(20+0,335+0),(20+256, 335+60),GREEN,1)   # Value Box 외곽선 365
            cv2.putText(viewWin,'Value',(20+80,335+40),cv2.FONT_HERSHEY_COMPLEX_SMALL,1.5,GREEN)
            cv2.putText(viewWin,f'{greenValueX}',(290,365),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,GREEN)
            if selectedObject == 'GREEN_VALUE': C = WHITE
            else: C = GREEN
            cv2.circle(viewWin,(greenValueX+20,greenValueY),10,C,-1,cv2.LINE_AA)
            # Green Time ------------------------------------------------------------------
            cv2.rectangle(viewWin,(20+0,405+0),(20+256, 405+60),GREEN,1)   # Value Box 외곽선 435
            cv2.putText(viewWin,'Time',(20+80,405+40),cv2.FONT_HERSHEY_COMPLEX_SMALL,1.5,GREEN)
            cv2.putText(viewWin,f'{greenTimeX/10:.1f}',(290,435),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,GREEN)
            if selectedObject == 'GREEN_TIME': C = WHITE
            else: C = GREEN
            cv2.circle(viewWin,(greenTimeX+20,greenTimeY),10,C,-1,cv2.LINE_AA)
            # Exit --------------------------------------------------------------------------
            cv2.rectangle(viewWin,(750,15),(750+30,15+30),GRAY,-1)            # Exit  (765,30)
            cv2.putText(viewWin,'X',(750+3,45-5),cv2.FONT_HERSHEY_COMPLEX_SMALL,1.5,WHITE)
            # Save Parameter ----------------------------------------------------------------
            cv2.rectangle(viewWin,(750,70),(750+30,70+30),GRAY,-1)            # Save  (765,85)
            cv2.putText(viewWin,'S',(750+3,100-5),cv2.FONT_HERSHEY_COMPLEX_SMALL,1.5,WHITE)
            # Clear -------------------------------------------------------------------------
            cv2.rectangle(viewWin,(750,435),(750+30,435+30),GRAY,-1)          # Clear (765,450)
            cv2.putText(viewWin,'C',(750+3,465-5),cv2.FONT_HERSHEY_COMPLEX_SMALL,1.5,WHITE)
            # Circle(Ellipse) Center --------------------------------------------------------
            if selectedObject == 'CIRCLE_CENTER': C = WHITE
            else: C = GRAY                                     # Circle(Ellipse) Center
            cv2.circle(viewWin,(circleCenterX,circleCenterY),10,C,-1,cv2.LINE_AA) # 선택된 객체 기준원을 힌색으로 표시
            cv2.putText(viewWin,f'X:{circleCenterX}',(circleCenterX+15,circleCenterY-5),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,WHITE)
            cv2.putText(viewWin,f'Y:{circleCenterY}',(circleCenterX+15,circleCenterY+15),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,WHITE)
            # Circle (Rigid) ----------------------------------------------------------------
            if selectedObject == 'CIRCLE_RIGID': C = WHITE
            else: C = BLUE                                     # Circle
            cv2.circle(viewWin,(circleCenterX,circleCenterY-circleRadius),10,C,-1,cv2.LINE_AA)
            cv2.putText(viewWin,f'R:{circleRadius}',(circleCenterX+15,circleCenterY-circleRadius+7),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,WHITE)
            # Ellipse -----------------------------------------------------------------------
            if selectedObject == 'CIRCLE_DIAGONAL': C = WHITE
            else: C = CYAN                                     # Ellipse
            cv2.circle(viewWin,(circleCenterX-cirWidth,circleCenterY+cirHeight),10,C,-1,cv2.LINE_AA)
            cv2.putText(viewWin,f'W:{cirWidth} H:{cirHeight}',(circleCenterX-cirWidth+15,circleCenterY+cirHeight+7),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,WHITE)
            # 객체 기준점과 마우스와의 거리 계산 (거리의 상대적인 크기 비교 sqart 연산하지 않음) --------
            objectList[0][1]  = (redValueX-mouseX)**2+(redValueY-mouseY)**2
            objectList[1][1]  = (redTimeX-mouseX)**2+(redTimeY-mouseY)**2
            objectList[2][1]  = (yellowValueX-mouseX)**2+(yellowValueY-mouseY)**2
            objectList[3][1]  = (yellowTimeX-mouseX)**2+(yellowTimeY-mouseY)**2
            objectList[4][1]  = (greenValueX-mouseX)**2+(greenValueY-mouseY)**2
            objectList[5][1]  = (greenTimeX-mouseX)**2+(greenTimeY-mouseY)**2
            objectList[6][1]  = (circleCenterX-mouseX)**2+(circleCenterY-mouseY)**2
            objectList[7][1]  = (circleCenterX-mouseX)**2+(circleCenterY-circleRadius-mouseY)**2
            objectList[8][1]  = (circleCenterX-cirWidth-mouseX)**2+(circleCenterY+cirHeight-mouseY)**2
            objectList[9][1]  = (exitX-mouseX)**2+(exitY-mouseY)**2
            objectList[10][1] = (saveX-mouseX)**2+(saveY-mouseY)**2
            objectList[11][1] = (clearWinX-mouseX)**2+(clearWinY-mouseY)**2
            # 객체 선택 ----------------------------------------------------------------------
            if mouseButtenLeft:
                selectedObject = sorted(objectList,key=itemgetter(1))[0][0] # 마우스와 최 단거리 객체
                mouseButtenToggle = not mouseButtenToggle
                mouseButtenLeft = False                                     # 원 슈트(One Shoot)
            # 선택된 객체 처리 ----------------------------------------------------------------
            if mouseButtenToggle:
                if selectedObject == 'RED_VALUE':
                    if 15 <= mouseX <286:
                        redValueX = constrain(mouseX-20, 0, 255)
                if selectedObject == 'RED_TIME':
                    if 15 <= mouseX <286:
                        redTimeX = constrain(mouseX-20, 0, 255)
                if selectedObject == 'YELLOW_VALUE':
                    if 15 <= mouseX <286:
                        yellowValueX = constrain(mouseX-20, 0, 255)
                if selectedObject == 'YELLOW_TIME':
                    if 15 <= mouseX <286:
                        yellowTimeX = constrain(mouseX-20, 0, 255)
                if selectedObject == 'GREEN_VALUE':
                    if 15 <= mouseX <286:
                        greenValueX = constrain(mouseX-20, 0, 255)
                if selectedObject == 'GREEN_TIME':
                    if 15 <= mouseX <286:
                        greenTimeX = constrain(mouseX-20, 0, 255)
                if selectedObject == 'CIRCLE_CENTER':
                    if 50 <= mouseX < 730:
                        circleCenterX = mouseX
                    if 20 <= mouseY < 460:
                        circleCenterY = mouseY
                if selectedObject == 'CIRCLE_RIGID':
                    circleRadius = abs(circleCenterY - mouseY)
                    cirWidth = circleRadius              # 신호등 가로 길이
                    cirHeight = circleRadius             # 신호등 세로 길이
                if selectedObject == 'CIRCLE_DIAGONAL':
                    cirWidth =abs(circleCenterX - mouseX)
                    cirHeight = abs(circleCenterY - mouseY)
                if selectedObject == 'SHUT_DOWN':
                    POWER_OFF = True
                    break
                if selectedObject == 'SYSTEM':
                    break
                if selectedObject == 'CLEAR':
                    mouseButtenToggle = False
                    SET_MODE = False
            else:
                selectedObject = None
        #------------------------------------------------------------------------------------
        cv2.imshow('Out', viewWin)           # 이미지를 LCD에 표시
        #------------------------------------------------------------------------------------
        keyBoard = cv2.waitKey(1) & 0xFF     # 키보드 입력
        if keyBoard == 0x1B or keyBoard == 0x09 or keyBoard == ord('x') or keyBoard == ord('X'):
            break                            # ESC / TAB / 'x' 프로그램 종료
        if keyBoard == ord('c') or keyBoard == ord('C'):
            SET_MODE = not SET_MODE
    #---------------------------------------------------------------------------------------
    d = [circleRadius, redValueX, redTimeX, yellowValueX, yellowTimeX,
         greenValueX, greenTimeX, circleCenterX, circleCenterY, cirWidth, cirHeight]
    fileName = 'tst.pickle'
    with open(fileName, 'wb') as f:
        pickle.dump(d, f)                            #
    cv2.destroyAllWindows()                          # 열려 있는 모든 윈도우를 닫기
# Mouse Event -------------------------------------------------------------------------------
cv2.namedWindow('Out')                               # 윈도우 창을 생성
cv2.setMouseCallback('Out', controlMain, viewWin)    # 마우스 제어 설정
#--------------------------------------------------------------------------------------------
main()                                               # 신호등 메인 프로그램 실행
#--------------------------------------------------------------------------------------------
if POWER_OFF:
    subprocess.call(['sudo', 'poweroff'])            # Raspberry Pi 를 Power Off 
#############################################################################################



