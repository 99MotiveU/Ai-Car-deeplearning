# Block Image -1                            <v07.py>
#
# Numpy 배열에 Blue, Green, Red 색상을 추가하거나 제거 합니다.
#
import numpy as np
import cv2 

image = np.zeros((480,600,3), np.uint8)  # Height, Width 세로, 가로

image[100:200,30:240,0] = 255   # [Y시점:Y종점,X시점:X종점]  Blue 추가
print('1: Blue 층(0 번)에만 색상을 추가 합니다.')
cv2.imshow('Press Any Key to Next',image)
cv2.waitKey(0)

image[50:290,60:120,1] = 255 # [Y시점:Y종점,X시점:X종점] Green 추가
print('2: Green 층(1 번)에만 색상을 추가 합니다.')
cv2.imshow('Press Any Key to Next',image)
cv2.waitKey(0)

image[40:270,90:210,2] = 255 # [Y시점:Y종점,X시점:X종점] Red 추가
print('3: Red 층(1 번)에만 색상을 추가 합니다.')
cv2.imshow('Press Any Key to Next',image)
cv2.waitKey(0)

image[:,:] = 255,255,255     # image 전체 화면에 White 색상
print('4: 전체 화면을 White 로 만듭니다.')
cv2.imshow('Press Any Key to Next',image)
cv2.waitKey(0)

image[100:200,30:240,0] = 0  # [Y시점:Y종점,X시점:X종점] Blue 제거
print('5: Blue 층(0 번)을 제거 합니다.')
cv2.imshow('Press Any Key to Next',image)
cv2.waitKey(0)

image[50:290,60:120,1] = 0   # [Y시점:Y종점,X시점:X종점] Green 제거
print('6: Green 층(1 번)을 제거 합니다.')
cv2.imshow('Press Any Key to Next',image)
cv2.waitKey(0)

image[40:270,90:210,2] = 0   # [Y시점:Y종점,X시점:X종점] Red 제거
print('7: Red 층(2 번)을 제거 합니다.')
cv2.imshow('Press Any Key to Next',image)
cv2.waitKey(0)

cv2.destroyAllWindows()      # 열려 있는 모든 창 닫기
##########################################################################
