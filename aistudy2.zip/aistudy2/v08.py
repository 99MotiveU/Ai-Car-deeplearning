#### Block Image                            <v08.py>

import cv2
import numpy as np

img0 = np.full((300, 480, 3), (0,0,0), np.uint8) # B,G,R
#img0 = np.zeros((300, 480,3), dtype=np.uint8) # X:480 Y:240 Image 0
img1 = np.zeros((70,  220,3), dtype=np.uint8) # X:220 Y:70 Image 1
img2 = np.zeros((70,  220,3), dtype=np.uint8) # X:220 Y:70 Image 2
img3 = np.zeros((70,  220,3), dtype=np.uint8) # X:220 Y:70 Image 3
img4 = np.zeros((70,  220,3), dtype=np.uint8) # X:220 Y:70 Image 4

img0[20:40, :] = [255,0,0]                    #  1 Blue 수평  리스트 Ok
img0[50:70:2, :] = (255,0,0)                  #  2 Blue 수평  튜플 Ok
img0[80:100:, ::2] = 255,0,0                  #  3 Blue 수평
img0[110:130:2, ::2] = 255,0,0                #  4 Blue 수평

img0[: ,250:290] = 0,0,255                    #  5 Red  수직 
img0[: ,310:350:4] = 0,0,255                  #  6 Red  수직 
img0[::2 ,370:410] = 0,0,255                  #  7 Red  수직 
img0[::2 ,430:470:2] = 0,0,255                #  8 Red  수직 

img0[150:170, 20:100] = 0, 255, 0             #  9 Green Box
img0[180:200:, 60:140:2] = 0, 255, 0          # 10 Green Box
img0[210:230:3, 100:180:] = 0, 255, 0         # 11 Green Box
img0[240:260:2, 140:240:2] = 0, 255, 0        # 12 Green Box

img1[::4,::4] = 255,255,255                   # 13 White
img2[::4,:] = 255,255,255                     # 14 White
img3[:,::4] = 255,255,255                     # 15 White
img4[:,:] = 255,255,255                       # 16 White

cv2.imshow('Img0', img0)                      # Image 0
cv2.imshow('Img1', img1)                      # Image 1
cv2.imshow('Img2', img2)                      # Image 2
cv2.imshow('Img3', img3)                      # Image 3
cv2.imshow('Img4', img4)                      # Image 4

cv2.waitKey(0)
cv2.destroyAllWindows()
##########################################################################
