# 로고 배경이 투명한 로고 이미지를 카메라 영상에 덥어 쓰는 방법입니다.           <v16.py>
# 로고 크기는 스크린 크기보다 작고 가로와 세로 픽쎌이 짝수

import cv2
import numpy as np

cam = cv2.VideoCapture(0,cv2.CAP_V4L)
cam.set(3,640)                    # VGA 기본 이미지 크기
cam.set(4,480)

logo = cv2.imread("hcir.png",cv2.IMREAD_UNCHANGED)    # BGR + 알파층 까지 읽는다.

mask = logo[:,:,3]                # 알파층 1개 를 마스크 층으로 사용(1 개 층 이미지) logo[:,:,-1]
logo = logo[:,:,0:3]              # 0,1,2번 층을 가져온 것이다.(알파층 빼고, 3 개층 이미지가 된다)
height, width = logo.shape[:2]    # 이미지 크기
h=int(height/2); w=int(width/2)

#---------------------------------------------------------------------------------------------
while True:
    ret2, frame = cam.read()      # 카메라 이미지 가져오기

    crop = frame[240-h:240+h, 320-w:320+w]
    cv2.copyTo(logo, mask, crop)  #crop[mask > 0] = logo[mask > 0]  # 같은 동작 

    cv2.imshow('Out', frame)
    key = cv2.waitKey(1)
    if key == ord('x') or key == ord('X') or key == ord(' ') or key == 27: break
#---------------------------------------------------------------------------------------------
cam.release()                     # 카메라 자원을 반납
cv2.destroyAllWindows()           # 열려 있는 모든 윈도우를 닫기
##############################################################################################
