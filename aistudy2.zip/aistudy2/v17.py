# RGB Bar                                <v17.py>

import numpy as np
import cv2 as cv

image = np.zeros((480,450,3), np.uint8)  # 세로, 가로

image[:,:] = 255,255,255                 # image 전체 화면에 White 색상

for i in range(256):

    cv.line(image,(100+i, 50),(100+i,150),(0,0,i),1) # 빨간색
    cv.line(image,(100+i,170),(100+i,270),(0,i,0),1) # 녹색
    cv.line(image,(100+i,290),(100+i,390),(i,0,0),1) # 파란색

cv.putText(image,'0        128       255',(100,40),cv.FONT_HERSHEY_COMPLEX_SMALL,1,0)
cv.imshow('Press any key to exit',image)
cv.waitKey(0)
