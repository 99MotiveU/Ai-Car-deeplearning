# 퍼셉트론 NAND Gate
def nand_gate(x1, x2):
    # 입력값 x1에 대한 가중치 w1, x2에 대한 가중치 w2
    w1, w2 = 0.6, 0.6

    # bias 편향값
    b = -0.7
    # 연산 결과
    s = x1*w1 + x2*w2 + b

    # 결과가 0보다 작거나 같으면 1, 0보다 크면 0을 반환합니다.

    if s>0:
        r = 0
    else:
        r = 1
    return r, s

# 입력값 목록을 튜플 리스트로 만듭니다.
print("퍼셉트론 NAND Gate")
input_list = [(0, 0), (0, 1), (1, 0), (1, 1)]


# 반복문을 순회하면서 입력값을 가져옵니다.
for x1, x2 in input_list:
    # nand gate의 결과를 저장하고
    r, s = nand_gate(x1, x2)

    # 출력합니다.
    print(f"입력값: {x1} {x2} - 결과: {r} {s}")
